package com.nielsen.retailer.config.api.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.nielsen.retailer.config.api.dao.LanguageRepository;
import com.nielsen.retailer.config.api.domain.Language;

@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class LanguageServiceTest extends BaseServiceTest {

	@Mock
	private LanguageRepository languageRepository;
	@InjectMocks
	private LanguageService languageService;

	List<Language> listLanguage;

	@Before
	public void setup() {
		super.setup();
		this.mySetUp();

	}

	@Test
	public void getAllLanguage() {

		when(languageRepository.selectAll()).thenReturn(listLanguage);

		List<Language> result = languageService.getAllLanguage();

		assertEquals(listLanguage, result);

	}

	private void mySetUp() {
		Language l1 = new Language();
		l1.setLanguageId(1);
		l1.setCode("l1");
		l1.setLanguageNm("l1");

		Language l2 = new Language();
		l2.setLanguageId(2);
		l2.setCode("l2");
		l2.setLanguageNm("l2");

		Language l3 = new Language();
		l3.setLanguageId(3);
		l3.setCode("l3");
		l3.setLanguageNm("l3");

		listLanguage = new ArrayList<Language>();
		listLanguage.add(l1);
		listLanguage.add(l2);
		listLanguage.add(l3);
	}

}
