package com.nielsen.retailer.config.api.dao;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.when;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.nielsen.retailer.config.api.domain.User;

@RunWith(SpringRunner.class)
@SpringBootTest
@ConfigurationProperties("classpath:application-test.properties")
public class UserDaoTest extends BaseDaoTest{

	private static Log log = LogFactory.getLog(UserDaoTest.class);

	@Autowired
	private UserDao userDao;

	@Test
	public void findAll() throws Exception {

		//when(userDao.findAll()).thenReturn(super.users);
		List<User> result = userDao.findAll();
		assertEquals(2, result.size());

	}
	
	@Test
	public void findById() throws Exception {

		//when(userDao.findById(isA(Integer.class))).thenReturn(super.user);
		User result = userDao.findById(new Integer(2));
		log.debug("Resultado: " + result.getUserId());
		//assertEquals(1, result);

	}
	
	@Test
	public void findByEmail() throws Exception {

		final String email = "gerardorodriguez@nielsen.com";
		//when(userDao.findByEmail(isA(String.class))).thenReturn(super.user);
		User result = userDao.findByEmail(new String(email));
		log.debug("Resultado: " + result.getUserId());
		//assertEquals(1, result);

	}
	
	@Test
	public void update() throws Exception {

		final User u = new User();
		u.setUserId(2);
		
		//when(userDao.update(isA(User.class))).thenReturn(super.user.getUserId());
		int result = userDao.update(u);
		//assertEquals(1, result);

	}
	
	@Test
	public void create() throws Exception {

		final User u = new User();
		u.setUserId(2);
		
		//when(userDao.create(isA(User.class))).thenReturn(super.user.getUserId());
		int result = userDao.create(u);
		
		//assertEquals(1, result);

	}

	@Test
	public void delete() throws Exception {

		final User u = new User();
		u.setUserId(2);
		
		//when(userDao.delete(isA(User.class))).thenReturn(super.user.getUserId());
		int result = userDao.delete(u);
		
		//assertEquals(1, result);

	}
	
}
