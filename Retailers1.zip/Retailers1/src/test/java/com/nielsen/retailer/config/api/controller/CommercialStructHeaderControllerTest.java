package com.nielsen.retailer.config.api.controller;

import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.nielsen.retailer.commons.api.utils.JacksonUtil;
import com.nielsen.retailer.config.api.domain.CommercialStructHeader;
import com.nielsen.retailer.config.api.service.CommercialStructHeaderService;

@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CommercialStructHeaderControllerTest extends BaseControllerTest {
	
	@MockBean
	private CommercialStructHeaderService commercialStructHeaderService;
	private CommercialStructHeader c;

	@Before
	public void setup() {
		super.setup();
		this.mySetUp();
	}
	public void mySetUp(){
		c = new CommercialStructHeader();
		c.setCommercialStructId(1);
	}
	
	@Test
	public void getCommercialStructHeaderById() throws Exception{
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("commercial-struct-header")
				.append("/").append("{commercialStructId}")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		
		when(commercialStructHeaderService.getById(isA(Integer.class))).thenReturn(c);
		
		final RequestBuilder request = MockMvcRequestBuilders
				.get(url, super.commercialStruct.getCommercialStructId())
				.accept(contentType)
				.contentType(contentType);
		
        super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody.commercialStructId").value(super.commercialStruct.getCommercialStructId()))
		.andDo(print())
		.andReturn();
	}
	
	@Test
	public void getCommercialStructHeaderByRetailerId() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("commercial-struct-header-by_retailer")
				.append("/").append("{retailerId}")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(commercialStructHeaderService.getById(isA(Integer.class))).thenReturn(c);
		
		final RequestBuilder request = MockMvcRequestBuilders
				.get(url, super.commercialStruct.getCommercialStructId())
				.accept(contentType)
				.contentType(contentType);
		
        super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody.commercialStructId").value(super.commercialStruct.getCommercialStructId()))
		.andDo(print())
		.andReturn();
	}
	@Test
	public void updateCommercialStruct() throws Exception{
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("commercial-struct-header")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(commercialStructHeaderService.update(isA(CommercialStructHeader.class))).thenReturn(1);
		
		
		final RequestBuilder request = MockMvcRequestBuilders.put(url)
				.contentType(contentType)
				.content(JacksonUtil.toString(c))
				.accept(contentType);
		
		super.mockMvc.perform(request)
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody").value(1))
		.andDo(print());
	}
	
}
