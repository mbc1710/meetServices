package com.nielsen.retailer.config.api.controller;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.sql.Timestamp;
import java.util.Date;

import static org.mockito.BDDMockito.*;

import com.nielsen.retailer.commons.api.utils.JacksonUtil;
import com.nielsen.retailer.config.api.domain.Country;
import com.nielsen.retailer.config.api.service.CountryServices;

@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CountryControllerTest extends BaseControllerTest {
	
	@MockBean
	private CountryServices countryServices; 

	@Before
	public void setup() {
		super.setup();
	}

	@Test
	public void createCountry() throws Exception {

		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("country")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(countryServices.createCountry(isA(Country.class))).thenReturn(1);
		
		final RequestBuilder request = MockMvcRequestBuilders.post(url)
				.contentType(contentType)
				.content(JacksonUtil.toString(super.country))
				.accept(contentType);
		
		super.mockMvc.perform(request)
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody").value(1))
		.andDo(print());

	}
	
	@Test
	public void updateCountry() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("country")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		final Date currentDt = new Date();
		final Country c = new Country();
		c.setCountryId(super.country.getCountryId());
		c.setCountryNm("México-Update");
		c.setActive(super.country.isActive());
		c.setCodeIso(super.country.getCodeIso());
		c.setShortNm(super.country.getShortNm());
		c.setCreateDt(super.country.getCreateDt());
		c.setUpdateDt(new Timestamp(currentDt.getTime()));

		when(countryServices.updateCountry(isA(Country.class))).thenReturn(1);
		
		final RequestBuilder request = MockMvcRequestBuilders.put(url)
				.contentType(contentType)
				.content(JacksonUtil.toString(c))
				.accept(contentType);
		
		super.mockMvc.perform(request)
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody").value(1))
		.andDo(print());

	}

	@Test
	public void getCountries() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("country")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(countryServices.getCountries()).thenReturn(super.countries);
		
		final RequestBuilder request = MockMvcRequestBuilders.get(url)
				.contentType(contentType);
		
		super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody.[0].countryId").value(super.country.getCountryId()))
		.andDo(print())
		.andReturn();
	}

	@Test
	public void getCountryById() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("country")
				.append("/").append("{countryId}")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(countryServices.getCountryById(isA(Integer.class))).thenReturn(super.country);
		
		final RequestBuilder request = MockMvcRequestBuilders
				.get(url,super.country.getCountryId())
				.accept(contentType)
				.contentType(contentType);
		
        super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody.countryId").value(super.country.getCountryId()))
		.andDo(print())
		.andReturn();
	}
	
	@Test
	public void getCountryByUser() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("/country_by_user")
				.append("/").append("{userId}")
				.append("/").append("{reportId}")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(countryServices.getCountriesByUser(isA(Integer.class),isA(Integer.class)))
		.thenReturn(super.countries);
		
		
		final RequestBuilder request = MockMvcRequestBuilders
				.get(url,super.user.getUserId(),super.report.getReportId())
				.accept(contentType)
				.contentType(contentType);
		
        super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody.[0].countryId").value(super.country.getCountryId()))
		.andDo(print())
		.andReturn();
	}
	@Test
	public void getCountriesIsActive() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("country_is_active")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(countryServices.getCountriesIsActive())
		.thenReturn(super.countries);
		
		
		final RequestBuilder request = MockMvcRequestBuilders
				.get(url)
				.accept(contentType)
				.contentType(contentType);
		
        super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody.[0].countryId").value(super.country.getCountryId()))
		.andDo(print())
		.andReturn();
	}
	@Test
	public void deleteCountries() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("country")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(countryServices.deleteCountry(isA(Country.class)))
		.thenReturn(1);
		final Date currentDt = new Date();
		final Country c = new Country();
		c.setCountryId(super.country.getCountryId());
		c.setCountryNm("México-Update");
		c.setActive(super.country.isActive());
		c.setCodeIso(super.country.getCodeIso());
		c.setShortNm(super.country.getShortNm());
		c.setCreateDt(super.country.getCreateDt());
		c.setUpdateDt(new Timestamp(currentDt.getTime()));
		
		final RequestBuilder request = MockMvcRequestBuilders
				.delete(url)
				.accept(contentType)
				.content(JacksonUtil.toString(c))
				.contentType(contentType);
		
        super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody").value(1))
		.andDo(print())
		.andReturn();
	}
}
