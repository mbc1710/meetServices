package com.nielsen.retailer.config.api.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import com.nielsen.retailer.config.api.dao.CommercialStructDetailDao;
import com.nielsen.retailer.config.api.dao.CommercialStructDetailRepository;
import com.nielsen.retailer.config.api.domain.CommercialStructDetail;

@RunWith(SpringRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CommercialStructDetailServiceTest extends BaseServiceTest {

	@Mock
	private CommercialStructDetailDao commercialStructDetailDao;
	@Mock
	private CommercialStructDetailRepository commercialStructDetailRepository;
	@InjectMocks
	private CommercialStructDetailService commercialStructDetailService;

	List<CommercialStructDetail> listCommercialStructDetail = new ArrayList<CommercialStructDetail>();

	CommercialStructDetail c;

	@Before
	public void setup() {
		super.setup();
		this.setMemoryCommercialStruct();
	}

	@Test
	public void updateCommercialStructDetail() throws Exception {

		when(commercialStructDetailDao.update(isA(CommercialStructDetail.class))).thenReturn(1);

		int result = commercialStructDetailService.updateCommercialStructDetail(c);
		assertEquals(1, result);
	}

	@Test
	public void updateCommercialStructDetail2() {
		
		when(commercialStructDetailDao.updateAllByCommercialStructId(isA(Integer.class))).thenReturn(1);
		
		when(commercialStructDetailDao.findByCommercialStructIdAndFormatId(c.getCommercialStructId(), c.getFormatId())).thenReturn(c);
		
		when(commercialStructDetailRepository.save(listCommercialStructDetail)).thenReturn(listCommercialStructDetail);
		
		int result = commercialStructDetailService.updateCommercialStructDetail(c.getCommercialStructId(), listCommercialStructDetail);
		
		assertEquals(1, result);
	}

	@Test
	public void getCommercialStructDetails() {
		when(commercialStructDetailDao.findByCommercialStructId(isA(Integer.class)))
				.thenReturn(listCommercialStructDetail);

		List<CommercialStructDetail> result = commercialStructDetailService
				.getCommercialStructDetails(c.getCommercialStructId());

		assertEquals(listCommercialStructDetail, result);

	}

	@Test
	public void getCommercialStructDetailsByRetailers() {
		int[] retailerIds = { 1, 2 };
		when(commercialStructDetailRepository.findByRetailersId(retailerIds)).thenReturn(listCommercialStructDetail);

		List<CommercialStructDetail> result = commercialStructDetailService
				.getCommercialStructDetailsByRetailers(retailerIds);
		assertEquals(listCommercialStructDetail, result);
	}

	@Test
	public void createCommertialStructDetail() {
		when(commercialStructDetailDao.create(c)).thenReturn(1);
		int result = commercialStructDetailService.createCommertialStructDetail(c);
		assertEquals(1, result);
	}

	private void setMemoryCommercialStruct() {

		c = new CommercialStructDetail();
		c.setCommercialStructId(1);
		c.setFormatId(1);
		c.setActive(true);

		CommercialStructDetail c2 = new CommercialStructDetail();
		c2.setCommercialStructId(1);
		c2.setFormatId(1);
		c2.setActive(true);

		this.listCommercialStructDetail.add(c);
		this.listCommercialStructDetail.add(c2);
	}

}
