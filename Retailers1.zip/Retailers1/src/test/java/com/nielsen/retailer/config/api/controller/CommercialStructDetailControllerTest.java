package com.nielsen.retailer.config.api.controller;

import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.nielsen.retailer.config.api.service.CommercialStructDetailService;
import com.nielsen.retailer.commons.api.utils.JacksonUtil;
import com.nielsen.retailer.config.api.domain.CommercialStructDetail;

@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CommercialStructDetailControllerTest extends BaseControllerTest {
	
	@MockBean
	private CommercialStructDetailService commercialStructDetailService;
	List<CommercialStructDetail> listCommercialStructDetail = new ArrayList<CommercialStructDetail>();
	
	@Before
	public void setup() {
		super.setup();
		this.setMemoryCommercialStruct();
	}
	@Test
	public void getCommercialStructDetailById() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("commercial-struct-detail")
				.append("/").append("{commercialStructId}")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(commercialStructDetailService.getCommercialStructDetails(isA(Integer.class))).thenReturn(listCommercialStructDetail);
		
		final RequestBuilder request = MockMvcRequestBuilders
				.get(url, super.commercialStruct.getCommercialStructId())
				.accept(contentType)
				.contentType(contentType);
		
        super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody.[0].commercialStructId").value(super.commercialStruct.getCommercialStructId()))
		.andDo(print())
		.andReturn();
	}
	@Test
	public void updateCommercialStructDetail() throws Exception{
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("commercial-struct-detail")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(commercialStructDetailService.updateCommercialStructDetail(isA(CommercialStructDetail.class))).thenReturn(1);
		
		CommercialStructDetail c = new CommercialStructDetail();
		c.setCommercialStructId(1);
		c.setActive(true);
		
		final RequestBuilder request = MockMvcRequestBuilders.put(url)
				.contentType(contentType)
				.content(JacksonUtil.toString(c))
				.accept(contentType);
		
		super.mockMvc.perform(request)
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody").value(1))
		.andDo(print());
	}
	
	@Test
	public void getCommercialStructDetailByRetailer() throws Exception{
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("commercial-struct-detail-by-retailers")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();

		int[] retailerIds = {1, 2};
		
		when(commercialStructDetailService.getCommercialStructDetailsByRetailers(retailerIds)).thenReturn(listCommercialStructDetail);
		
		final RequestBuilder request = MockMvcRequestBuilders
				.post(url)
				.accept(contentType)
				.content(JacksonUtil.toString(retailerIds))
				.contentType(contentType);
		
        super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody.[0].commercialStructId").value(super.commercialStruct.getCommercialStructId()))
		.andDo(print())
		.andReturn();
	}
	@Test
	public void updateCommercialStructDetail2() throws Exception{
		//commercial-struct-detail
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("commercial-struct-detail")
				.append("/").append("{commercialStructId}")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(commercialStructDetailService.updateCommercialStructDetail(isA(Integer.class), isA(ArrayList.class))).thenReturn(1);
		
		final RequestBuilder request = MockMvcRequestBuilders.put(url, 1)
				.contentType(contentType)
				.content(JacksonUtil.toString(listCommercialStructDetail))
				.accept(contentType);
		
		super.mockMvc.perform(request)
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody").value(1))
		.andDo(print());
	}
	@Test
	public void createCommercialStructDetail() throws Exception{
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("commercial-struct-detail/")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		CommercialStructDetail c1 = new CommercialStructDetail();
		c1.setCommercialStructId(1);
		c1.setFormatId(1);
		c1.setActive(true);
		
		when(commercialStructDetailService.updateCommercialStructDetail(isA(CommercialStructDetail.class))).thenReturn(1);
		
		final RequestBuilder request = MockMvcRequestBuilders.post(url)
				.contentType(contentType)
				.content(JacksonUtil.toString(c1))
				.accept(contentType);
		
		super.mockMvc.perform(request)
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody").value(1))
		.andDo(print());
	}
	private  void setMemoryCommercialStruct(){
		
		CommercialStructDetail c1 = new CommercialStructDetail();
		c1.setCommercialStructId(1);
		c1.setFormatId(1);
		c1.setActive(true);
		
		CommercialStructDetail c2 = new CommercialStructDetail();
		c2.setCommercialStructId(1);
		c2.setFormatId(1);
		c2.setActive(true);
		
		this.listCommercialStructDetail.add(c1);
		this.listCommercialStructDetail.add(c2);
	}

}
