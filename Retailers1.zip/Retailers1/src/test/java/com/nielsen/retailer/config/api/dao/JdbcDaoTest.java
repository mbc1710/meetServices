package com.nielsen.retailer.config.api.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.nielsen.retailer.config.api.dao.impl.JdbcDaoImpl;
import com.nielsen.retailer.config.api.domain.CommercialStructDetail;

@RunWith(SpringRunner.class)
@SpringBootTest
@ConfigurationProperties("classpath:application-test.properties")
public class JdbcDaoTest extends BaseDaoTest{

	private static Log log = LogFactory.getLog(JdbcDaoTest.class);
	
	@Autowired
	private JdbcDaoImpl jdbcDaoImpl;
	
	@Test
	public void insertCommercialStrucDetail() throws Exception {

		CommercialStructDetail c = new CommercialStructDetail();
		Integer result = jdbcDaoImpl.InsertCommercialStrucDetail(c);
		//assertEquals(0, result.size());
	}
	
	@Test
	public void insertCommercialStrucDetailList() throws Exception {

		List<CommercialStructDetail> list = new ArrayList<CommercialStructDetail>();
		CommercialStructDetail c = new CommercialStructDetail();
		//jdbcDaoImpl.InsertCommercialStrucDetail(list);

	}
}
