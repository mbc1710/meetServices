package com.nielsen.retailer.config.api.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import com.nielsen.retailer.config.api.domain.CommercialStruct;
import com.nielsen.retailer.config.api.domain.CommercialStructDetail;
import com.nielsen.retailer.config.api.domain.CommercialStructHeader;
import com.nielsen.retailer.config.api.domain.Retailer;

@RunWith(SpringRunner.class)
@SpringBootTest
@ConfigurationProperties("classpath:application-test.properties")
@ActiveProfiles("test")
public class CommercialStructDaoTest extends BaseDaoTest{
	
	private static Log log = LogFactory.getLog(CommercialStructDaoTest.class);
	
	@Autowired
	CommercialStructDao commercialStructDao;
	
	@Before
	public void setup() {
		super.setup();
	}
	
	@Test
	public void findByService() throws Exception{
		
		Integer serviceId = 1;
		List<CommercialStruct> result= commercialStructDao.findByService(serviceId);
		//assertEquals(0, result.size());
	}
	
	@Test
	public void findById() throws Exception{
		
		Integer id = 1;
		CommercialStruct result= commercialStructDao.findById(id);
		//assertEquals(null, result);
	}
	
	@Test
	public void findByRetailerId() throws Exception{
		
		Integer retailerId = 1;
		CommercialStruct result = commercialStructDao.findByRetailerId(retailerId);
		//assertEquals(null, result);
	}
	
	@Test
	public void update() throws Exception{
		
		final Date currentDt = new Date();
		CommercialStruct c = new CommercialStruct();
		CommercialStructDetail s = new CommercialStructDetail();
		List<CommercialStructDetail> details = new ArrayList<CommercialStructDetail>();
		details.add(s);
		
		c.setActive(true);
		c.setCommercialStructId(1);
		c.setCommercialStructNm("Mexico");
		c.setCreateDt(new Timestamp(currentDt.getTime()));
		c.setDetails(details);
		c.setHeader(new CommercialStructHeader());
		c.setRetailer(new Retailer());
		c.setUpdateDt(new Timestamp(currentDt.getTime()));
		
		Integer result = commercialStructDao.update(c);
		//assertEquals(new Integer(1), result);
	}
	
	@Test
	public void create() throws Exception{
		
		final Date currentDt = new Date();
		CommercialStructDetail s = new CommercialStructDetail();
		List<CommercialStructDetail> details = new ArrayList<CommercialStructDetail>();
		details.add(s);
		
		CommercialStruct c = new CommercialStruct();
		c.setActive(true);
		c.setCommercialStructId(1);
		c.setCommercialStructNm("Peru");
		c.setCreateDt(new Timestamp(currentDt.getTime()));
		c.setDetails(details);
		c.setHeader(new CommercialStructHeader());
		c.setRetailer(retailer);
		c.setUpdateDt(new Timestamp(currentDt.getTime()));
		
		Integer result = commercialStructDao.create(c);
		//assertEquals(1, 1);
	}
	
}
