package com.nielsen.retailer.config.api.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.test.context.junit4.SpringRunner;

import com.nielsen.retailer.config.api.domain.User;

@RunWith(SpringRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class UserServiceTest extends BaseServiceTest {
	
	@Before
	public void setup() {
		super.setup();
	}
	
	@Test
	public void getUsers() throws Exception {

		when(userDao.findAll()).thenReturn(super.users);

		List<User> result = userService.getUsers();
		assertEquals(2, result.size());

	}
	
	@Test
	public void getUserById() throws Exception {

		when(userDao.findById(1)).thenReturn(super.user);

		User result = userService.getUserById(1);
		
		if (result != null) {
			result.setProfiles(profileDao.findByUserId(1));
		}
		
		assertEquals(super.user, result);

	}
	
	@Test
	public void createUser() throws Exception {

		when(userDao.create(isA(User.class))).thenReturn(1);

		int result = userService.createUser(super.user);
		assertEquals(1, result);

	}
	
	@Test
	public void updateUser() throws Exception {

		final Date currentDt = new Date();
		final User u = new User();
		u.setUserId(super.user.getUserId());
		u.setUserNm("México-Update");
		u.setActive(super.user.isActive());
		u.setEmail(super.user.getEmail());
		u.setInternal(super.user.isInternal());
		u.setLanguageId(super.user.getLanguageId());
		u.setCreateDt(super.user.getCreateDt());
		u.setUpdateDt(new Timestamp(currentDt.getTime()));

		when(userDao.update(isA(User.class))).thenReturn(1);

		int result = userService.updateUser(u);
		assertEquals(1, result);

	}
	
	@Test
	public void deleteUser() throws Exception {
		
		when(userDao.delete(isA(User.class))).thenReturn(1);

		int result = userService.deleteUser(super.user);
		assertEquals(1, result);
		
	}
	
	@Test
	public void getUserByEmail() throws Exception {

		when(userDao.findByEmail("prueba@gmail.com")).thenReturn(super.user);

		User result = userService.getUserByEmail("prueba@gmail.com");
		
		if (result != null) {
			result.setProfiles(profileDao.findByUserId(1));
		}
		
		assertEquals(super.user, result);

	}

}
