package com.nielsen.retailer.config.api.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.test.context.junit4.SpringRunner;

import com.nielsen.retailer.config.api.domain.Report;

@RunWith(SpringRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ReportServiceTest extends BaseServiceTest {
	
	@Before
	public void setup() {
		super.setup();
	}
	
	@Test
	public void getReport() throws Exception {

		when(reportDao.findAll()).thenReturn(super.reports);

		List<Report> result = reportService.getReport();
		assertEquals(2, result.size());

	}
	
	@Test
	public void getReportIsActive() throws Exception {

		when(reportDao.findAllIsActive()).thenReturn(super.reports);

		List<Report> result = reportService.getReportIsActive();
		assertEquals(2, result.size());

	}
	
	@Test
	public void getReportById() throws Exception {
		
		when(reportDao.findById(1)).thenReturn(super.report);
		
		Report result = reportService.getReportById(1);
		assertEquals(super.report, result);

	}
	
	@Test
	public void createReport() throws Exception {

		when(reportDao.create(isA(Report.class))).thenReturn(1);

		int result = reportService.createReport(super.report);
		assertEquals(1, result);

	}
	
	@Test
	public void updateReport() throws Exception {

		final Date currentDt = new Date();
		final Report r = new Report();
		r.setReportId(super.report.getReportId());
		r.setReportNm("México-Update");
		r.setActive(super.report.isActive());
		r.setUrl(super.report.getUrl());
		r.setParent(super.report.isParent());
		r.setParentReportId(super.report.getParentReportId());
		r.setCreateDt(super.report.getCreateDt());
		r.setUpdateDt(new Timestamp(currentDt.getTime()));

		when(reportDao.update(isA(Report.class))).thenReturn(1);

		int result = reportService.updateReport(r);
		assertEquals(1, result);

	}
	
	@Test
	public void deleteReport() throws Exception {
		
		when(reportDao.delete(isA(Report.class))).thenReturn(1);

		int result = reportService.deleteReport(super.report);
		assertEquals(1, result);
		
	}
	
	@Test
	public void getReportByService() throws Exception {

		when(reportDao.findByService(isA(Integer.class))).thenReturn(super.reports);

		List<Report> result = reportService.getReportByService(2);
		assertEquals(2, result.size());

	}
	
	@Test
	public void getReportsByUserId() throws Exception {

		when(reportDao.findByUser(isA(Integer.class))).thenReturn(super.reports);

		List<Report> result = reportService.getReportsByUserId(super.user.getUserId());
		assertEquals(2, result.size());

	}

}
