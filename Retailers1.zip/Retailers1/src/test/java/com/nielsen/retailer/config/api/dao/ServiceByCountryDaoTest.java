package com.nielsen.retailer.config.api.dao;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.nielsen.retailer.config.api.domain.ServiceByCountry;

@RunWith(SpringRunner.class)
@SpringBootTest
@ConfigurationProperties("classpath:application-test.properties")
public class ServiceByCountryDaoTest extends BaseDaoTest {
	
	@Autowired
	private ServiceByCountryDao serviceByCountryDao;

	@Test
	public void findAll() throws Exception {

		when(serviceByCountryDao.findAll()).thenReturn(super.serviceByCountrys);

		List<ServiceByCountry> result = serviceByCountryDao.findAll();
		assertEquals(2, result.size());

	}

	@Test
	public void findAllIsActive() throws Exception {

		when(serviceByCountryDao.findAllIsActive()).thenReturn(super.serviceByCountrys);

		List<ServiceByCountry> result = serviceByCountryDao.findAllIsActive();
		assertEquals(2, result.size());

	}

	@Test
	public void findByCountry() throws Exception {

		when(serviceByCountryDao.findByCountry(isA(Integer.class))).thenReturn(super.serviceByCountrys);

		List<ServiceByCountry> result = serviceByCountryDao.findByCountry(2);
		assertEquals(2, result.size());

	}

	@Test
	public void findById() throws Exception {

		when(serviceByCountryDao.findById(isA(Integer.class))).thenReturn(super.serviceByCountry);

		ServiceByCountry result = serviceByCountryDao.findById(1);
		assertEquals(super.serviceByCountry, result);

	}

	@Test
	public void create() throws Exception {

		when(serviceByCountryDao.create(isA(ServiceByCountry.class))).thenReturn(1);

		int result = serviceByCountryDao.create(super.serviceByCountry);
		assertEquals(1, result);

	}

	@Test
	public void update() throws Exception {

		final Date currentDt = new Date();
		final ServiceByCountry s = new ServiceByCountry();
		s.setServiceId(super.serviceByCountry.getServiceId());
		s.setCountry(super.serviceByCountry.getCountry());
		s.setActive(super.serviceByCountry.isActive());
		s.setServiceNm("México-Update");
		s.setCreateDt(super.serviceByCountry.getCreateDt());
		s.setUpdateDt(new Timestamp(currentDt.getTime()));

		when(serviceByCountryDao.update(isA(ServiceByCountry.class))).thenReturn(1);

		int result = serviceByCountryDao.update(s);
		assertEquals(1, result);

	}

	@Test
	public void delete() throws Exception {

		when(serviceByCountryDao.delete(isA(ServiceByCountry.class))).thenReturn(1);

		int result = serviceByCountryDao.delete(super.serviceByCountry);
		assertEquals(1, result);

	}

	@Test
	public void findByCountriesId() throws Exception {

		when(serviceByCountryRepository.findByCountriesId(isA(Integer.class))).thenReturn(super.serviceByCountrys);

		List<ServiceByCountry> result = serviceByCountryRepository.findByCountriesId(1);
		assertEquals(super.serviceByCountrys, result);

	}


}
