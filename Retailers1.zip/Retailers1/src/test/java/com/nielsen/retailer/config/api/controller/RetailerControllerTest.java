package com.nielsen.retailer.config.api.controller;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;

import static org.mockito.BDDMockito.*;
import static org.mockito.Mockito.when;

import com.nielsen.retailer.commons.api.utils.JacksonUtil;
import com.nielsen.retailer.config.api.domain.FileRetailer;
import com.nielsen.retailer.config.api.domain.Retailer;
import com.nielsen.retailer.config.api.service.RetailerService;

@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RetailerControllerTest extends BaseControllerTest {
	
	@MockBean
	private RetailerService retailerService; 

	@Before
	public void setup() {
		super.setup();
	}

	@Test
	public void createRetailer() throws Exception {

		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("retailer")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(retailerService.createRetailer(isA(Retailer.class))).thenReturn(1);
		
		final RequestBuilder request = MockMvcRequestBuilders.post(url)
				.contentType(contentType)
				.content(JacksonUtil.toString(super.retailer))
				.accept(contentType);
		
		super.mockMvc.perform(request)
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody").value(1))
		.andDo(print());

	}
	
	@Test
	public void updateRetailerById() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("retailer")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		final Retailer r = new Retailer();
		r.setRetailerId(1);
		r.setRetailerNm("farmacon");
		r.setActive(false);
		r.setServiceId(1);
		r.setRetailerExternalId(155);
		
		when(retailerService.updateRetailerById(isA(Retailer.class))).thenReturn(1);
		
		final RequestBuilder request = MockMvcRequestBuilders.put(url)
				.contentType(contentType)
				.content(JacksonUtil.toString(r))
				.accept(contentType);
		
		super.mockMvc.perform(request)
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody").value(1))
		.andDo(print());

	}

	@Test
	public void getRetailer() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("retailer-by-service")
				.append("/").append("{serviceId}")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(retailerService.getRetailer(isA(Integer.class))).thenReturn(super.retailers);
		
		final RequestBuilder request = MockMvcRequestBuilders
				.get(url,super.serviceByCountry.getServiceId())
				.accept(contentType)
				.contentType(contentType);
		
        super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody.[0].retailerId").value(super.retailer.getRetailerId()))
		.andDo(print())
		.andReturn();
	}
	
	
	@Test
	public void getRetailerIsActive() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("retailer-by-service-is-active")
				.append("/").append("{serviceId}")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(retailerService.getRetailerIsActive(isA(Integer.class))).thenReturn(super.retailers);
		
		final RequestBuilder request = MockMvcRequestBuilders
				.get(url,super.serviceByCountry.getServiceId())
				.accept(contentType)
				.contentType(contentType);
		
        super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody.[0]retailerId").value(super.retailer.getRetailerId()))
		.andDo(print())
		.andReturn();
	}
	
	
	@Test
	public void getRetailerById() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("retailer")
				.append("/").append("{retailerId}")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(retailerService.getRetailerById(isA(Integer.class))).thenReturn(super.retailers);
		
		final RequestBuilder request = MockMvcRequestBuilders
				.get(url,super.retailer.getRetailerId())
				.accept(contentType)
				.contentType(contentType);
		
        super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody.[0]retailerId").value(super.retailer.getRetailerId()))
		.andDo(print())
		.andReturn();
	}
	
	@Test
	public void retailerByMarkets() throws Exception {
		
		int [] value = {1};
		
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("retailer-markets")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(retailerService.findByMarkets(value)).thenReturn(super.retailers);
		
		final RequestBuilder request = MockMvcRequestBuilders.post(url)
				.contentType(contentType)
				.content(JacksonUtil.toString(value))
				.accept(contentType);
		
        super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody[0].retailerId").value(super.retailer.getRetailerId()))
		.andDo(print())
		.andReturn();
        	
	} 
		
	@Test
	public void createRetailers() throws Exception {
		
		//List<FileRetailer> listFileRetailers = new ArrayList<>();
		
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("retailer-batch")
				.append("/").append("{serviceId}")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(retailerService.createRetailers(isA(Integer.class), isA(ArrayList.class))).thenReturn(1);
		
		final RequestBuilder request = MockMvcRequestBuilders.post(url, 1)
				.contentType(contentType)
				.content(JacksonUtil.toString(super.fileRetailers))
				.accept(contentType);
		
		super.mockMvc.perform(request)
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody").value(1))
		.andDo(print());

	}
	
	
	@Test
	public void getRetailerByUserId() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("retailer-by-user")
				.append("/").append("{userId}")
				.append("/").append("{countryId}")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(retailerService.getRetailerByUserId(isA(Integer.class), isA(Integer.class))).thenReturn(super.retailers);
		
		final RequestBuilder request = MockMvcRequestBuilders
				.get(url,1,2)
				.accept(contentType)
				.contentType(contentType);
		
        super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody.[0]retailerId").value(super.retailer.getRetailerId()))
		.andDo(print())
		.andReturn();
	}
	
	
	
	
	
}
