package com.nielsen.retailer.config.api.service;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.nielsen.retailer.config.api.BaseTest;
import com.nielsen.retailer.config.api.dao.CommercialStructDetailRepository;
import com.nielsen.retailer.config.api.dao.CountryDao;
import com.nielsen.retailer.config.api.dao.MarketResolutionDao;
import com.nielsen.retailer.config.api.dao.MarketResolutionDetailDao;
import com.nielsen.retailer.config.api.dao.ProfileDao;
import com.nielsen.retailer.config.api.dao.ProfileRepository;
import com.nielsen.retailer.config.api.dao.ReportDao;
import com.nielsen.retailer.config.api.dao.RetailerDao;
import com.nielsen.retailer.config.api.dao.RetailerRepository;
import com.nielsen.retailer.config.api.dao.ServiceByCountryDao;
import com.nielsen.retailer.config.api.dao.ServiceByCountryRepository;
import com.nielsen.retailer.config.api.dao.UserDao;

public abstract class BaseServiceTest extends BaseTest {
	
	@Mock
	protected CountryDao countryDao;
	
	@Mock
	protected ReportDao reportDao;
	
	@Mock
	protected ServiceByCountryDao serviceByCountryDao;
	
	@Mock
	protected UserDao userDao;
	
	@Mock
	protected ProfileDao profileDao;
	
	@Mock
	protected RetailerDao retailerDao;
	
	@Mock
	protected MarketResolutionDetailDao marketResolutionDetailDao;

	@Mock
	protected MarketResolutionDao marketResolutionDao;
	
	@Mock
	protected CommercialStructDetailRepository commercialStructDetailRepository;
	
	@Mock
	protected RetailerRepository retailerRepository;
	
	@Mock
	protected ProfileRepository profileRepository;
	
	@Mock
	protected ServiceByCountryRepository serviceByCountryRepository;
	
	@InjectMocks
	protected CountryServices countryServices;
	
	@InjectMocks
	protected ReportService reportService;
	
	@InjectMocks
	protected ServiceByCountryService serviceByCountryService;
	
	@InjectMocks
	protected UserService userService;
	
	@InjectMocks
	protected ProfileService profileService;
	
	@InjectMocks
	protected RetailerService retailerService;
	
	protected void setup() {
		super.setup();
		MockitoAnnotations.initMocks(this);
	}

}
