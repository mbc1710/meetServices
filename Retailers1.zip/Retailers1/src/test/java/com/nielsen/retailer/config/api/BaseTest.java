package com.nielsen.retailer.config.api;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nielsen.retailer.config.api.domain.CommercialStruct;
import com.nielsen.retailer.config.api.domain.Country;
import com.nielsen.retailer.config.api.domain.FileRetailer;
import com.nielsen.retailer.config.api.domain.MarketResolutionDetail;
import com.nielsen.retailer.config.api.domain.Profile;
import com.nielsen.retailer.config.api.domain.RelUserProfiles;
import com.nielsen.retailer.config.api.domain.Report;
import com.nielsen.retailer.config.api.domain.Retailer;
import com.nielsen.retailer.config.api.domain.ServiceByCountry;
import com.nielsen.retailer.config.api.domain.User;

import ch.qos.logback.classic.BasicConfigurator;

public abstract class BaseTest {

	protected final static Logger LOGGER = LoggerFactory.getLogger(BasicConfigurator.class);

	protected Country country = new Country();
	protected List<Country> countries = new ArrayList<>();
	
	protected Profile profile = new Profile();
	protected List<Profile> profiles = new ArrayList<>();

	protected User user = new User();
	protected List<User> users = new ArrayList<>();

	protected MarketResolutionDetail marketResolutionDetail = new MarketResolutionDetail();
	protected List<MarketResolutionDetail> marketResolutionDetails = new ArrayList<>();
	
	protected Retailer retailer = new Retailer();
	protected FileRetailer fileRetailer = new FileRetailer();
	protected List<Retailer> retailers = new ArrayList<>();
	protected List<FileRetailer> fileRetailers = new ArrayList<>();

	protected Report report = new Report();
	protected List<Report> reports = new ArrayList<>();
	
	protected ServiceByCountry serviceByCountry = new ServiceByCountry();
	protected List<ServiceByCountry> serviceByCountrys = new ArrayList<>();
	
	protected CommercialStruct commercialStruct = new CommercialStruct();
	protected List<CommercialStruct> commercialStructs = new ArrayList<>();
	
	protected RelUserProfiles relUserProfile = new RelUserProfiles();
	protected List<RelUserProfiles> relUserProfiles = new ArrayList<>();
	
	
	protected void setup() {
		this.setMemoryCountry();
		this.setMemoryRetailer();
		this.setMemoryFileRetailer();
		this.setMemoryMarketResolutionDetail();
		this.setMemoryUser();
		this.setMemoryReport();
		this.setMemoryServiceByCountry();
		this.setMemoryCommercialStruct();
		this.setMemoryProfile();
		this.setMemoryRelUserProfiles();
		
	}

	private void setMemoryCountry() {
		final Date currentDt = new Date();

		Country c1 = new Country();
		c1.setCountryId(1);
		c1.setCountryNm("Mexico");
		c1.setActive(true);
		c1.setCodeIso("ISO");
		c1.setShortNm("MX");
		c1.setCreateDt(new Timestamp(currentDt.getTime()));
		c1.setUpdateDt(new Timestamp(currentDt.getTime()));

		Country c2 = new Country();
		c2.setCountryId(1);
		c2.setCountryNm("Argentina");
		c2.setActive(true);
		c2.setCodeIso("ISO");
		c2.setShortNm("MX");
		c2.setCreateDt(new Timestamp(currentDt.getTime()));
		c2.setUpdateDt(new Timestamp(currentDt.getTime()));

		this.country = c1;
		this.countries.add(c1);
		this.countries.add(c2);

	}

	private void setMemoryUser() {
		final Date currentDt = new Date();

		User u1 = new User();
		u1.setUserId(1);
		u1.setUserNm("Francisco Zarazua");
		u1.setActive(true);
		u1.setEmail("franciscozarazua@nielsen");
		u1.setLanguageId(1);
		u1.setCreateDt(new Timestamp(currentDt.getTime()));
		u1.setUpdateDt(new Timestamp(currentDt.getTime()));
		u1.setInternal(true);

		User u2 = new User();
		u2.setUserId(2);
		u2.setUserNm("Gerardo rodriguez");
		u2.setActive(true);
		u2.setEmail("gerardorodriguez@nielsen");
		u2.setLanguageId(1);
		u2.setCreateDt(new Timestamp(currentDt.getTime()));
		u2.setUpdateDt(new Timestamp(currentDt.getTime()));
		u2.setInternal(true);

		this.user = u1;
		this.users.add(u1);
		this.users.add(u2);
	}

	private void setMemoryMarketResolutionDetail() {

		MarketResolutionDetail mrd1 = new MarketResolutionDetail();
		mrd1.setMarketId(1);
		mrd1.setMarketNm("Total Mexico");
//		mrd1.setMarketTagId("620");
		mrd1.setMarketParentId(0);
		mrd1.setLevelId(1);
//		mrd1.setMarketParentTagId("");
		mrd1.setActive(true);
		mrd1.setResolutionId(1);

		MarketResolutionDetail mrd2 = new MarketResolutionDetail();
		mrd2.setMarketId(2);
		mrd2.setMarketNm("Total Acapulco");
//		mrd2.setMarketTagId("621");
		mrd2.setMarketParentId(0);
		mrd2.setLevelId(1);
//		mrd2.setMarketParentTagId("");
		mrd2.setActive(true);
		mrd2.setResolutionId(1);

		this.marketResolutionDetail = mrd1;
		this.marketResolutionDetails.add(mrd1);
		this.marketResolutionDetails.add(mrd2);
	}

	private void setMemoryRetailer() {

		Retailer r1 = new Retailer();
		r1.setRetailerId(1);
		r1.setRetailerNm("");
		r1.setActive(true);
		r1.setRetailerExternalId(0);

		Retailer r2 = new Retailer();
		r2.setRetailerId(1);
		r2.setRetailerNm("");
		r2.setActive(true);
		r2.setRetailerExternalId(21);
		
		this.retailer = r1;
		this.retailers.add(r1);
		this.retailers.add(r2);

	}
	
	private void setMemoryFileRetailer() {

		FileRetailer fr1 = new FileRetailer();
		fr1.setRetailerNm("");
		fr1.setRetailerExternalId(21);

		FileRetailer fr2 = new FileRetailer();
		fr2.setRetailerNm("");
		fr2.setRetailerExternalId(21);
		
		this.fileRetailer = fr1;
		this.fileRetailers.add(fr1);
		this.fileRetailers.add(fr2);

	}
	
	private void setMemoryProfile() {

		Profile p1 = new Profile();
		p1.setProfileId(1);
		p1.setProfileNm("");
		p1.setActive(true);
		
		Profile p2 = new Profile();
		p2.setProfileId(1);
		p2.setProfileNm("");
		p2.setActive(true);
		
		this.profile = p1;
		this.profiles.add(p1);
		this.profiles.add(p2);

	}
	
	private void setMemoryReport() {
		final Date currentDt = new Date();
		
		Report r1 = new Report();
		r1.setReportId(1);
		r1.setReportNm("Performance Review");
		r1.setParentReportId(0);
		r1.setUrl("/promp_01");
		r1.setActive(true);
		r1.setParent(true);
		r1.setCreateDt(new Timestamp(currentDt.getTime()));
		r1.setUpdateDt(new Timestamp(currentDt.getTime()));

		Report r2 = new Report();
		r2.setReportId(1);
		r2.setReportNm("Performance Review");
		r2.setParentReportId(0);
		r2.setUrl("/promp_01");
		r2.setActive(true);
		r2.setParent(true);
		r2.setCreateDt(new Timestamp(currentDt.getTime()));
		r2.setUpdateDt(new Timestamp(currentDt.getTime()));
		
		this.report = r1;
		this.reports.add(r1);
		this.reports.add(r2);

	}
	
	private  void setMemoryServiceByCountry(){
		final Date currentDt = new Date();
		
		ServiceByCountry s1 = new ServiceByCountry();
		s1.setServiceId(1);
		s1.setServiceNm("Scantrack");
		s1.setCountry(country);
		s1.setCreateDt(new Timestamp(currentDt.getTime()));
		s1.setUpdateDt(new Timestamp(currentDt.getTime()));
		s1.setActive(true);
		
		ServiceByCountry s2 = new ServiceByCountry();
		s2.setServiceId(2);
		s2.setServiceNm("Scantrack 2");
		s2.setCountry(country);
		s2.setCreateDt(new Timestamp(currentDt.getTime()));
		s2.setUpdateDt(new Timestamp(currentDt.getTime()));
		s2.setActive(false);
		
		this.serviceByCountry = s1;
		this.serviceByCountrys.add(s1);
		this.serviceByCountrys.add(s2);
	}

	private  void setMemoryCommercialStruct() {
		final Date currentDt = new Date();
		
		CommercialStruct c1 = new CommercialStruct();
		c1.setRetailer(retailer);
		c1.setCommercialStructId(1);
		c1.setCommercialStructNm("E-C Wallmart");
		c1.setActive(true);
		c1.setCreateDt(new Timestamp(currentDt.getTime()));
		c1.setUpdateDt(new Timestamp(currentDt.getTime()));
		
		CommercialStruct c2 = new CommercialStruct();
		c2.setRetailer(retailer);
		c2.setCommercialStructId(1);
		c2.setCommercialStructNm("E-C Wallmart");
		c2.setActive(true);
		c2.setCreateDt(new Timestamp(currentDt.getTime()));
		c2.setUpdateDt(new Timestamp(currentDt.getTime()));
		
		this.commercialStruct = c1;
		this.commercialStructs.add(c1);
		this.commercialStructs.add(c2);
	}
	
	private void setMemoryRelUserProfiles () {
		
		RelUserProfiles r1 = new RelUserProfiles();
		r1.setUserId(1);
		
		RelUserProfiles r2 = new RelUserProfiles();
		r2.setUserId(2);
		
		this.relUserProfile = r1;
		this.relUserProfiles.add(r1);
		this.relUserProfiles.add(r2);
	}
	
	
}
