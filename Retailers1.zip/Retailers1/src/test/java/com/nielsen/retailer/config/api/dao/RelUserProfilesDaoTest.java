package com.nielsen.retailer.config.api.dao;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.nielsen.retailer.config.api.domain.RelUserProfiles;

@RunWith(SpringRunner.class)
@SpringBootTest
@ConfigurationProperties("classpath:application-test.properties")
public class RelUserProfilesDaoTest extends BaseDaoTest {
	
	@Autowired
	private RelUserProfilesDao relUserProfilesDao;
	
	@Test
	public void findAllByUser() throws Exception {

		when(relUserProfilesDao.findAllByUser(isA(Integer.class))).thenReturn(super.relUserProfiles);
		
		List<RelUserProfiles> result = relUserProfilesDao.findAllByUser(1);
		assertEquals(2, result.size());

	}
	
	@Test
	public void findById() throws Exception {

		when(relUserProfilesDao.findById(isA(Integer.class), isA(Integer.class))).thenReturn(super.relUserProfile);
		
		RelUserProfiles result = relUserProfilesDao.findById(1,1);
		assertEquals(super.relUserProfile, result);

	}
	
	@Test
	public void create() throws Exception {

		when(relUserProfilesDao.create(isA(RelUserProfiles.class))).thenReturn(1);

		int result = relUserProfilesDao.create(super.relUserProfile);
		assertEquals(1, result);

	}
	
	@Test
	public void delete() throws Exception {
		
		when(relUserProfilesDao.delete(isA(RelUserProfiles.class))).thenReturn(1);

		int result = relUserProfilesDao.delete(super.relUserProfile);
		assertEquals(1, result);
		
	}
	
	@Test
	public void deleteAllByUser() throws Exception {
		
		when(relUserProfilesDao.deleteAllByUser(isA(Integer.class))).thenReturn(1);

		int result = relUserProfilesDao.deleteAllByUser(1);
		assertEquals(1, result);
		
	}

}
