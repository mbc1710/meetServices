package com.nielsen.retailer.config.api.dao;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.nielsen.retailer.config.api.domain.FileRetailer;
import com.nielsen.retailer.config.api.domain.Retailer;

@RunWith(SpringRunner.class)
@SpringBootTest
@ConfigurationProperties("classpath:application-test.properties")
public class RetailerDaoTest extends BaseDaoTest {
	
	@Autowired
	private RetailerDao retailerDao;

	@Test
	public void findByService() throws Exception {

		when(retailerDao.findByService(isA(Integer.class))).thenReturn(super.retailers);

		List<Retailer> result = retailerDao.findByService(2);
		assertEquals(2, result.size());

	}

	@Test
	public void findByServiceIsActive() throws Exception {

		when(retailerDao.findByServiceIsActive(isA(Integer.class))).thenReturn(super.retailers);

		List<Retailer> result = retailerDao.findByServiceIsActive(1);
		assertEquals(2, result.size());

	}

	@Test
	public void save() throws Exception {

		Retailer retailer = new Retailer();
		retailer.setRetailerId(1);

		when(retailerRepository.save(isA(Retailer.class))).thenReturn(retailer);

		Retailer result = retailerRepository.save(super.retailer);
		assertEquals(super.retailer, result);

	}
	
	@Test
	public void saveRetailers() throws Exception {
		
		Retailer objRetailer = new Retailer();
		objRetailer.setRetailerId(1);
		
		List<Retailer> listRetailer = new ArrayList<>();
		listRetailer.add(objRetailer);
		
		Set<Retailer> setRetailers = new HashSet<>(1);
		when(retailerDao.updateAllByService(1)).thenReturn(1);
		
		for (FileRetailer record : super.fileRetailers) {
			Retailer retailer = null;
			retailer = retailerDao.findByExternalId(1, record.getRetailerExternalId());
			if (retailer != null) {
				retailer.setRetailerNm(record.getRetailerNm());
				retailer.setActive(true);
			} else {
				retailer = new Retailer();
				retailer.setRetailerNm(record.getRetailerNm());
				retailer.setActive(true);
				retailer.setRetailerExternalId(record.getRetailerExternalId());
				retailer.setServiceId(1);
			}
			setRetailers.add(retailer);
		}
		
		if (setRetailers.size() > 0) {
			when(retailerRepository.save(setRetailers)).thenReturn(listRetailer);
		}

		List<Retailer> result = retailerRepository.save(setRetailers);
		assertEquals(1, result.size());
		
	}


	@Test
	public void findRetailerById() throws Exception {

		when(retailerRepository.findRetailerById(1)).thenReturn(super.retailers);

		List<Retailer> result = retailerRepository.findRetailerById(1);
		assertEquals(super.retailers, result);

	}

	@Test
	public void update() throws Exception {

		final Retailer r = new Retailer();
		r.setRetailerId(super.retailer.getRetailerId());
		r.setRetailerNm("México-Update");
		r.setActive(super.retailer.isActive());
		r.setMarkets(super.retailer.getMarkets());
		r.setRetailerExternalId(super.retailer.getRetailerExternalId());
		r.setServiceId(super.retailer.getServiceId());

		when(retailerDao.update(isA(Retailer.class))).thenReturn(1);

		int result = retailerDao.update(r);
		assertEquals(1, result);

	}
	
	@Test
	public void findByUser() throws Exception {

		when(retailerDao.findByUser(1, 3)).thenReturn(super.retailers);

		List<Retailer> result = retailerDao.findByUser(1, 3);
		assertEquals(super.retailers, result);

	}
	
	@Test
	public void findRetailerByMarket() throws Exception {
	
		when(retailerRepository.findRetailerByMarket(1, 3, 4)).thenReturn(super.retailers);

		List<Retailer> result = retailerRepository.findRetailerByMarket(1, 3, 4);
		assertEquals(super.retailers, result);
		
	}

}
