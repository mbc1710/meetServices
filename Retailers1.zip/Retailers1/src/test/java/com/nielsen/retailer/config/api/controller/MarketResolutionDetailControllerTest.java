package com.nielsen.retailer.config.api.controller;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import static org.mockito.BDDMockito.*;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.when;

import com.nielsen.retailer.commons.api.utils.JacksonUtil;
import com.nielsen.retailer.config.api.service.MarketResolutionDetailService;

@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class MarketResolutionDetailControllerTest extends BaseControllerTest {

	@MockBean
	private MarketResolutionDetailService marketResolutionDetailService;

	@Before
	public void setup() {
		super.setup();
	}

	@Test
	public void getMarketByResolutionId() throws Exception {

		final String url = new StringBuilder().append(CountryController.CONTRACT_BASE_URI).append("/")
				.append("market-resolution-detail").append("/").append("{resolutionId}").append("?")
				.append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();

		when(marketResolutionDetailService.getMarketByResolutionId(isA(Integer.class)))
				.thenReturn(super.marketResolutionDetails);

		final RequestBuilder request = MockMvcRequestBuilders.get(url, super.marketResolutionDetail.getResolutionId())
				.accept(contentType).contentType(contentType);

		super.mockMvc.perform(request).andExpect(status().isOk()).andExpect(jsonPath("$.status").value(200))
				.andExpect(jsonPath("$.responseBody.[0].marketId").value(1)).andDo(print());

	}

	@Test
	public void getMarketByResolutionIdIsActive() throws Exception {

		final String url = new StringBuilder().append(CountryController.CONTRACT_BASE_URI).append("/")
				.append("market-resolution-detail-is-active").append("/").append("{resolutionId}").append("?")
				.append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();

		when(marketResolutionDetailService.getMarketByResolutionIdIsActive(isA(Integer.class)))
				.thenReturn(super.marketResolutionDetails);

		final RequestBuilder request = MockMvcRequestBuilders.get(url, super.marketResolutionDetail.getResolutionId())
				.accept(contentType).contentType(contentType);

		super.mockMvc.perform(request).andExpect(status().isOk()).andExpect(jsonPath("$.status").value(200))
				.andExpect(jsonPath("$.responseBody.[0].marketId").value(1)).andDo(print());
	}

	@Test
	public void getMarketByUserProfileIdNoTotal() throws Exception {

		final String url = new StringBuilder().append(CountryController.CONTRACT_BASE_URI).append("/")
				.append("resolution-detail-by-user-profile-no-total").append("/").append("{userId}").append("/")
				.append("{retailerId}").append("/").append("{countryId}").append("?").append(LOCALE.getCountry())
				.append("_").append(LOCALE.getLanguage()).toString();

		when(marketResolutionDetailService.getMarketByUserProfileIdNoTotal(isA(Integer.class), isA(Integer.class),
				isA(Integer.class))).thenReturn(super.marketResolutionDetails);

		final RequestBuilder request = MockMvcRequestBuilders
				.get(url, super.user.getUserId(), 1, super.country.getCountryId()).accept(contentType)
				.contentType(contentType);

		super.mockMvc.perform(request).andExpect(status().isOk()).andExpect(jsonPath("$.status").value(200))
				.andExpect(jsonPath("$.responseBody.[0].marketId").value(1)).andDo(print());
	}

	@Test
	public void getMarketByUserProfileIdIsTotal() throws Exception {

		final String url = new StringBuilder().append(CountryController.CONTRACT_BASE_URI).append("/")
				.append("resolution-detail-by-user-profile-is-total").append("/").append("{userId}").append("/")
				.append("{countryId}").append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage())
				.toString();

		when(marketResolutionDetailService.getMarketByUserProfileIdIsTotal(isA(Integer.class), isA(Integer.class),
				isA(Integer.class))).thenReturn(super.marketResolutionDetails);

		final RequestBuilder request = MockMvcRequestBuilders
				.get(url, super.user.getUserId(), super.country.getCountryId()).accept(contentType)
				.contentType(contentType);

		super.mockMvc.perform(request).andExpect(status().isOk()).andExpect(jsonPath("$.status").value(200))
				.andExpect(jsonPath("$.responseBody.[0].marketId").value(1)).andDo(print());
	}

	@Test
	public void getMarketsResolutionsDetails() throws Exception {

		final String url = new StringBuilder().append(CountryController.CONTRACT_BASE_URI).append("/")
				.append("market-resolution-details").append("?").append(LOCALE.getCountry()).append("_")
				.append(LOCALE.getLanguage()).toString();

		int[] resolutionId = { isA(Integer.class), isA(Integer.class) };

		when(marketResolutionDetailService.getMarketByResolutionId(resolutionId))
				.thenReturn(super.marketResolutionDetails);

		final RequestBuilder request = MockMvcRequestBuilders.post(url).accept(contentType)
				.content(JacksonUtil.toString(resolutionId)).contentType(contentType);

		super.mockMvc.perform(request).andExpect(status().isOk()).andExpect(jsonPath("$.status").value(200))
				.andExpect(jsonPath("$.responseBody.[0].marketId").value(1)).andDo(print());
	}

}
