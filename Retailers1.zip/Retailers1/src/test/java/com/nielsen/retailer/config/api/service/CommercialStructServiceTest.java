package com.nielsen.retailer.config.api.service;

import static org.mockito.Mockito.when;
import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.isA;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import com.nielsen.retailer.config.api.dao.CommercialStructDao;
import com.nielsen.retailer.config.api.dao.CommercialStructHeaderRepository;
import com.nielsen.retailer.config.api.dao.CommercialStructRepository;
import com.nielsen.retailer.config.api.dao.impl.CommercialStructDetailDaoImpl;
import com.nielsen.retailer.config.api.dao.impl.JdbcDaoImpl;
import com.nielsen.retailer.config.api.domain.CommercialStruct;
import com.nielsen.retailer.config.api.domain.CommercialStructDetail;
import com.nielsen.retailer.config.api.domain.CommercialStructHeader;

@RunWith(SpringRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CommercialStructServiceTest extends BaseServiceTest {

	@Mock
	private CommercialStructDao commercialStructDao;
	@Mock
	private CommercialStructRepository commercialStructRepository;
	@Mock
	private CommercialStructDetailDaoImpl commercialStructDetailDaoImpl;
	@Mock
	private CommercialStructHeaderRepository commercialStructHeaderRepository;
	@Mock
	private JdbcDaoImpl jdbcDaoImpl;
	@InjectMocks
	private CommercialStructService commercialStructService;

	List<CommercialStructDetail> listCommercialStructDetail = new ArrayList<CommercialStructDetail>();
	CommercialStructHeader header = new CommercialStructHeader();
	CommercialStructDetail c1;

	@Before
	public void setup() {
		super.setup();
		this.setMemoryCommercialStruct();
	}

	@Test
	public void getCommercialStructs() {
		when(commercialStructDao.findByService(isA(Integer.class))).thenReturn(commercialStructs);

		List<CommercialStruct> result = commercialStructService.getCommercialStructs(1);

		assertEquals(commercialStructs, result);

	}

	@Test
	public void create() throws Exception {

		when(commercialStructDao.findByRetailerId(isA(Integer.class))).thenReturn(null);
		

		when(commercialStructRepository.save(isA(CommercialStruct.class))).thenReturn(commercialStruct);

		when(commercialStructHeaderRepository.save(isA(CommercialStructHeader.class))).thenReturn(header);


		List<Object[]> objects = new ArrayList<>(0);
		Object[] newObj = new Object[] { c1.getCommercialStructId(), c1.getFormatId(), c1.getFormatNm(),
				c1.getInfactNm(), c1.getLevel1(), c1.getLevel2(), c1.getLevel3(), c1.isActive() };
		objects.add(newObj);
		when(jdbcDaoImpl.InsertCommercialStrucDetail(objects)).thenReturn(1);
		int result = commercialStructService.create(commercialStruct);
		assertEquals(1, result);
	}

	@Test
	public void getCommercialStructById() {

		when(commercialStructDao.findById(isA(Integer.class))).thenReturn(commercialStruct);
		when(commercialStructDetailDaoImpl.findByCommercialStructId(isA(Integer.class)))
				.thenReturn(listCommercialStructDetail);
		when(commercialStructHeaderRepository.findById(isA(Integer.class))).thenReturn(header);
		CommercialStruct result = commercialStructService
				.getCommercialStructById(commercialStruct.getCommercialStructId());
		assertEquals(commercialStruct, result);
	}

	@Test
	public void getCommercialStructByIdWithOutDetail() {
		when(commercialStructDao.findById(isA(Integer.class))).thenReturn(commercialStruct);

		CommercialStruct result = commercialStructService.getCommercialStructByIdWithOutDetail(1);
		assertEquals(commercialStruct, result);
	}

	@Test
	public void update() {
		// commercialStruct.setUpdateDt(new Timestamp((new Date()).getTime()));
		when(commercialStructRepository.save(isA(CommercialStruct.class))).thenReturn(commercialStruct);

		int result = commercialStructService.update(commercialStruct);
		assertEquals(1, result);
	}

	private void setMemoryCommercialStruct() {

		c1 = new CommercialStructDetail();
		c1.setCommercialStructId(1);
		c1.setFormatId(1);
		c1.setActive(true);
		c1.setFormatNm("");
		c1.setInfactNm("");
		c1.setLevel1("");
		c1.setLevel2("");
		c1.setLevel3("");

		CommercialStructDetail c2 = new CommercialStructDetail();
		c2.setCommercialStructId(1);
		c2.setFormatId(1);
		c2.setActive(true);

		this.listCommercialStructDetail.add(c1);
		this.listCommercialStructDetail.add(c2);

		header.setCommercialStructId(1);

	}

}
