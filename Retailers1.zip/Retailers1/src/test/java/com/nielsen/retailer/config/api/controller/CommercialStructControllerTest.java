package com.nielsen.retailer.config.api.controller;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;



import static org.mockito.BDDMockito.*;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.when;

import com.nielsen.retailer.commons.api.utils.JacksonUtil;
import com.nielsen.retailer.config.api.domain.CommercialStruct;
import com.nielsen.retailer.config.api.service.CommercialStructService;;


@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CommercialStructControllerTest  extends BaseControllerTest{
	
	@MockBean
	private CommercialStructService commercialStructService; 

	@Before
	public void setup() {
		super.setup();
	}
	
	@Test
	public void getCommercialStructs() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("commercial-struct-by-service")
				.append("/").append("{serviceId}")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(commercialStructService.getCommercialStructs(isA(Integer.class))).thenReturn(super.commercialStructs);
		
		final RequestBuilder request = MockMvcRequestBuilders
				.get(url,super.serviceByCountry.getServiceId())
				.accept(contentType)
				.contentType(contentType);
		
        super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody.[0].commercialStructId").value(super.commercialStruct.getCommercialStructId()))
		.andDo(print())
		.andReturn();
	}
	@Test
	public void getCommercialStructById() throws Exception{
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("commercial-struct")
				.append("/").append("{commercialStructId}")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(commercialStructService.getCommercialStructById(isA(Integer.class))).thenReturn(super.commercialStruct);
		
		final RequestBuilder request = MockMvcRequestBuilders
				.get(url,super.commercialStruct.getCommercialStructId())
				.accept(contentType)
				.contentType(contentType);
		
        super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody.commercialStructId").value(super.commercialStruct.getCommercialStructId()))
		.andDo(print())
		.andReturn();
	}
	@Test
	public void getCommercialStructByIdWithoutDetail() throws Exception{
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("commercial-struct-without-detail")
				.append("/").append("{commercial_struct_id}")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(commercialStructService.getCommercialStructByIdWithOutDetail(isA(Integer.class))).thenReturn(super.commercialStruct);
		
		final RequestBuilder request = MockMvcRequestBuilders
				.get(url,super.commercialStruct.getCommercialStructId())
				.accept(contentType)
				.contentType(contentType);
		
        super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody.commercialStructId").value(super.commercialStruct.getCommercialStructId()))
		.andDo(print())
		.andReturn();
	}
	@Test
	public void createCommercialStruct() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("commercial-struct")//
				.append("/").append("{serviceId}")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		CommercialStruct c1 = new CommercialStruct();
		c1.setCommercialStructId(1);
		c1.setActive(true);
		
		when(commercialStructService.create(isA(CommercialStruct.class))).thenReturn(1);
		
		final RequestBuilder request = MockMvcRequestBuilders.post(url, 1)
				.contentType(contentType)
				.content(JacksonUtil.toString(c1))
				.accept(contentType);
		
		super.mockMvc.perform(request)
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody").value(1))
		.andDo(print());
	}
	@Test
	public void updateCommercialStruct() throws Exception{
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("commercial-struct")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(commercialStructService.update(isA(CommercialStruct.class))).thenReturn(1);
		
		CommercialStruct c = new CommercialStruct();
		c.setCommercialStructId(1);
		c.setActive(true);
		
		final RequestBuilder request = MockMvcRequestBuilders.put(url)
				.contentType(contentType)
				.content(JacksonUtil.toString(c))
				.accept(contentType);
		
		super.mockMvc.perform(request)
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody").value(1))
		.andDo(print());
	}
	

}
