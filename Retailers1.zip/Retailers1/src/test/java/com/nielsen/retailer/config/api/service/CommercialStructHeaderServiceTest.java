package com.nielsen.retailer.config.api.service;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.when;

import org.springframework.test.context.junit4.SpringRunner;

import com.nielsen.retailer.config.api.dao.CommercialStructHeaderRepository;
import com.nielsen.retailer.config.api.domain.CommercialStructHeader;

@RunWith(SpringRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CommercialStructHeaderServiceTest extends BaseServiceTest {

	@Mock
	private CommercialStructHeaderRepository commercialStructHeaderRepository;
	@InjectMocks
	private CommercialStructHeaderService commercialStructHeaderService;

	private CommercialStructHeader c;

	@Before
	public void setup() {
		super.setup();
		this.thisSetupIp();
	}

	private void thisSetupIp() {
		c = new CommercialStructHeader();
		c.setCommercialStructId(1);
	}

	@Test
	public void update() {
		when(commercialStructHeaderRepository.save(isA(CommercialStructHeader.class))).thenReturn(c);

		int result = commercialStructHeaderService.update(c);

		assertEquals(1, result);

	}

	@Test
	public void getById() {
		when(commercialStructHeaderRepository.findById(isA(Integer.class))).thenReturn(c);

		CommercialStructHeader result = commercialStructHeaderService.getById(c.getCommercialStructId());

		assertEquals(c, result);
	}

//	@Test
//	public void getByRetailerId() {
//		when(commercialStructHeaderRepository.findByRetailerId(isA(Integer.class))).thenReturn(c);
//		CommercialStructHeader result = commercialStructHeaderService.getByRetailerId(1);
//
//		assertEquals(c, result);
//
//	}

}
