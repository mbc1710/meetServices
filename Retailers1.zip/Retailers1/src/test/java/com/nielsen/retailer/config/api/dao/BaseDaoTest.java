package com.nielsen.retailer.config.api.dao;

import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.nielsen.retailer.config.api.BaseTest;
import com.nielsen.retailer.config.api.dao.impl.JdbcDaoImpl;

public class BaseDaoTest extends BaseTest{

//	@Mock
//	protected UserDao userDao;
//	
//	@Mock
//	protected CountryDao countryDao;
//	
//	@Mock
//	protected JdbcDaoImpl jdbcDaoImpl;
//	
//	@Mock
//	protected CommercialStructDao commercialStructDao;
//	
//	@Mock
//	protected CommercialStructDetailDao commercialStructDetailDao;
//	
//	@Mock
//	protected ProfileDao profileDao;
//	
//	@Mock
//	protected RelUserProfilesDao relUserProfilesDao;
//	
//	@Mock
//	protected ReportDao reportDao;
//	
//	@Mock
//	protected RetailerDao retailerDao;
//	
//	@Mock
//	protected ServiceByCountryDao serviceByCountryDao;
//	
//	@Mock
//	protected MarketResolutionDetailDao marketResolutionDetailDao;
//	
//	@Mock
//	protected MarketResolutionDao marketResolutionDao;
	
	@Mock
    protected ProfileRepository profileRepository;
	
	@Mock
    protected CommercialStructDetailRepository commercialStructDetailRepository;
	
	@Mock
	protected ServiceByCountryRepository serviceByCountryRepository;
	
	@Mock
	protected RetailerRepository retailerRepository;

	protected void setup() {
		super.setup();
		MockitoAnnotations.initMocks(this);
	}
	
}
