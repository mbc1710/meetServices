package com.nielsen.retailer.config.api.dao;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.nielsen.retailer.config.api.domain.CommercialStructDetail;

@RunWith(SpringRunner.class)
@SpringBootTest
@ConfigurationProperties("classpath:application-test.properties")
public class CommercialStructDetailDaoTest extends BaseDaoTest{
	
	private static Log log = LogFactory.getLog(CountryDaoTest.class);
	
	@Autowired
	CommercialStructDetailDao commercialStructDetailDao;
	
	@Before
	public void setup() {
		super.setup();
	}
	
	@Test
	public void update() throws Exception{
		
		CommercialStructDetail c = new CommercialStructDetail();
		int result = commercialStructDetailDao.update(c);
		//assertEquals(0, result.size());
	}
	
	@Test
	public void create() throws Exception{
		CommercialStructDetail c = new CommercialStructDetail();
		int result = commercialStructDetailDao.create(c);
		//assertEquals(0, result.size());
	}
	
	@Test
	public void  deleteByCommercialStructId() throws Exception{
		Integer id = 1;
		int result = commercialStructDetailDao.deleteByCommercialStructId(id);
		//assertEquals(0, result.size());
	}
	
	@Test
	public void findByCommercialStructId() throws Exception{
		
		Integer id = 1;
		List<CommercialStructDetail> commercialStructDetailList = commercialStructDetailDao.findByCommercialStructId(id);
		//assertEquals(0, result.size());
	}
	
	@Test
	public void findByCommercialStructIdAndFormatId() throws Exception{
		
		int commercialStructId =1;
		int formatId = 1;
		CommercialStructDetail commercialStructDetail = commercialStructDetailDao.findByCommercialStructIdAndFormatId(commercialStructId, formatId);
		//assertEquals(0, result.size());
	}
	
	@Test
	public void updateAllByCommercialStructId() throws Exception{
		
		int commercialStructId = 1;
		Integer result = commercialStructDetailDao.updateAllByCommercialStructId(commercialStructId);
		//assertEquals(0, result.size());
	}

//	@Test
//	public void findByLevel4() throws Exception{
//		
//		int commercialStructId = 1;
//		List<Selected> list = commercialStructDetailDao.findByLevel4(commercialStructId);
//		//assertEquals(0, result.size());
//		
//	}
//	
//	@Test
//	public void findByLevel3() throws Exception{
//		int commercialStructId = 1;
//		List<Selected> list = commercialStructDetailDao.findByLevel3(commercialStructId);
//		//assertEquals(0, result.size());
//	}
//
//	@Test
//	public void findByLevel2() throws Exception{
//		int commercialStructId = 1;
//		List<Selected> list = commercialStructDetailDao.findByLevel2(commercialStructId);
//		//assertEquals(0, result.size());
//	}
//
//	@Test
//	public void findByLevel1() throws Exception{
//		int commercialStructId = 1;
//		List<Selected> list = commercialStructDetailDao.findByLevel1(commercialStructId);	
//		//assertEquals(0, result.size());
//	}
	
}
