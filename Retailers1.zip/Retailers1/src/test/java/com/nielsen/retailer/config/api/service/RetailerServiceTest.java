package com.nielsen.retailer.config.api.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.test.context.junit4.SpringRunner;

import com.nielsen.retailer.config.api.domain.FileRetailer;
import com.nielsen.retailer.config.api.domain.Retailer;

@RunWith(SpringRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RetailerServiceTest extends BaseServiceTest {

	@Before
	public void setup() {
		super.setup();
	}

	@Test
	public void getRetailer() throws Exception {

		when(retailerDao.findByService(isA(Integer.class))).thenReturn(super.retailers);

		List<Retailer> result = retailerService.getRetailer(2);
		assertEquals(2, result.size());

	}

	@Test
	public void getRetailerIsActive() throws Exception {

		when(retailerDao.findByServiceIsActive(isA(Integer.class))).thenReturn(super.retailers);

		List<Retailer> result = retailerService.getRetailerIsActive(1);
		assertEquals(2, result.size());

	}

	@Test
	public void createRetailer() throws Exception {

		Retailer retailer = new Retailer();
		retailer.setRetailerId(1);

		when(retailerRepository.save(isA(Retailer.class))).thenReturn(retailer);

		int result = retailerService.createRetailer(super.retailer);
		assertEquals(1, result);

	}
	
	@Test
	public void createRetailers() throws Exception {
		
		Retailer objRetailer = new Retailer();
		objRetailer.setRetailerId(1);
		
		List<Retailer> listRetailer = new ArrayList<>();
		listRetailer.add(objRetailer);
		
		Set<Retailer> setRetailers = new HashSet<>(1);
		when(retailerDao.updateAllByService(1)).thenReturn(1);
		
		for (FileRetailer record : super.fileRetailers) {
			Retailer retailer = null;
			retailer = retailerDao.findByExternalId(1, record.getRetailerExternalId());
			if (retailer != null) {
				retailer.setRetailerNm(record.getRetailerNm());
				retailer.setActive(true);
			} else {
				retailer = new Retailer();
				retailer.setRetailerNm(record.getRetailerNm());
				retailer.setActive(true);
				retailer.setRetailerExternalId(record.getRetailerExternalId());
				retailer.setServiceId(1);
			}
			setRetailers.add(retailer);
		}
		
		if (setRetailers.size() > 0) {
			when(retailerRepository.save(setRetailers)).thenReturn(listRetailer);
		}

		int result = retailerService.createRetailers(1, super.fileRetailers);
		assertEquals(1, result);
		
	}


	@Test
	public void getRetailerById() throws Exception {

		when(retailerRepository.findRetailerById(1)).thenReturn(super.retailers);

		List<Retailer> result = retailerService.getRetailerById(1);
		assertEquals(super.retailers, result);

	}

	@Test
	public void updateRetailerById() throws Exception {

		final Retailer r = new Retailer();
		r.setRetailerId(super.retailer.getRetailerId());
		r.setRetailerNm("México-Update");
		r.setActive(super.retailer.isActive());
		r.setMarkets(super.retailer.getMarkets());
		r.setRetailerExternalId(super.retailer.getRetailerExternalId());
		r.setServiceId(super.retailer.getServiceId());

		when(retailerDao.update(isA(Retailer.class))).thenReturn(1);

		int result = retailerService.updateRetailerById(r);
		assertEquals(1, result);

	}
	
	@Test
	public void getRetailerByUserId() throws Exception {

		when(retailerDao.findByUser(1, 3)).thenReturn(super.retailers);

		List<Retailer> result = retailerService.getRetailerByUserId(1, 3);
		assertEquals(super.retailers, result);

	}
	
	@Test
	public void findByMarkets() throws Exception {
	
		when(retailerRepository.findRetailerByMarket(1, 3, 4)).thenReturn(super.retailers);

		List<Retailer> result = retailerService.findByMarkets(1, 3, 4);
		assertEquals(super.retailers, result);
		
	}
}
