package com.nielsen.retailer.config.api.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.test.context.junit4.SpringRunner;

import com.nielsen.retailer.config.api.domain.MarketResolutionDetail;
import com.nielsen.retailer.config.api.domain.Profile;

@RunWith(SpringRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ProfileServiceTest extends BaseServiceTest {
	
	@Before
	public void setup() {
		super.setup();
	}
	
	@Test
	public void getProfiles() throws Exception {

		when(profileDao.findAll()).thenReturn(super.profiles);

		List<Profile> result = profileService.getProfiles();
		assertEquals(2, result.size());

	}
	
	@Test
	public void getProfilesIsActive() throws Exception {

		when(profileDao.findAllActives()).thenReturn(super.profiles);

		List<Profile> result = profileService.getProfilesIsActive();
		assertEquals(2, result.size());

	}
	
	@Test
	public void getProfilesByService() throws Exception {

		when(profileDao.findByServiceId(isA(Integer.class))).thenReturn(super.profiles);

		List<Profile> result = profileService.getProfilesByService(2);
		assertEquals(2, result.size());

	}
	
	@Test
	public void getProfileById() {
		
		when(profileDao.findById(isA(Integer.class))).thenReturn(super.profile);
		
		Profile profile = profileDao.findById(1);
		if (profile != null) {
			profile.setReports(reportDao.findByProfile(profile.getProfileId()));
			profile.setMarkets(marketResolutionDetailDao.findByProfileId(profile.getProfileId()));
			profile.setCommercialStructDetails( commercialStructDetailRepository.findByProfile( profile.getProfileId() ) );
			if (profile.getMarkets() != null && profile.getMarkets().size() > 0) {
				for (MarketResolutionDetail mrt : profile.getMarkets()) {
					mrt.setMarketResolution(marketResolutionDao.findById(mrt.getResolutionId()));
				}
			}
			profile.setRetailers(retailerRepository.findByProfile(profile.getProfileId()));
		}
		
		Profile result = profileService.getProfileById(1);
		assertEquals(profile, result);
	}
	
	@Test
	public void getProfileByUserId() throws Exception {

		when(profileDao.findByUserId(isA(Integer.class))).thenReturn(super.profiles);

		List<Profile> result = profileService.getProfileByUserId(super.user.getUserId());
		assertEquals(2, result.size());

	}
	
	@Test
	public void createProfile() throws Exception {

		when(profileDao.create(isA(Profile.class))).thenReturn(1);

		int result = profileService.createProfile(super.profile);
		assertEquals(1, result);

	}
	
	@Test
	public void updateProfile() throws Exception {

		final Date currentDt = new Date();
		final Profile p = new Profile();
		p.setProfileId(super.profile.getProfileId());
		p.setProfileNm("México-Update");
		p.setActive(super.profile.isActive());
		p.setCommercialStructDetails(super.profile.getCommercialStructDetails());
		p.setMarkets(super.profile.getMarkets());
		p.setReports(super.profile.getReports());
		p.setRetailers(super.profile.getRetailers());
		p.setService(super.profile.getService());
		p.setCreateDt(super.profile.getCreateDt());
		p.setUpdateDt(new Timestamp(currentDt.getTime()));

		when(profileDao.update(isA(Profile.class))).thenReturn(1);

		int result = profileService.updateProfile(p);
		assertEquals(1, result);

	}
	
	@Test
	public void deleteProfile() throws Exception {
		
		when(profileDao.delete(isA(Profile.class))).thenReturn(1);

		int result = profileService.deleteProfile(super.profile);
		assertEquals(1, result);
		
	}
	
	@Test
	public void getProfilesByServices() throws Exception {
		
		int[] arr = {1}; 

		when(profileRepository.findByServiceId(isA(Integer.class))).thenReturn(super.profiles);

		List<Profile> result = profileService.getProfilesByServices(arr);
		assertEquals(2, result.size());

	}

}
