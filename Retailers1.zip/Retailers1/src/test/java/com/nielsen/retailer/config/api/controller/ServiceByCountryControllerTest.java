package com.nielsen.retailer.config.api.controller;


import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.sql.Timestamp;
import java.util.Date;

import static org.mockito.BDDMockito.*;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.when;

import com.nielsen.retailer.commons.api.utils.JacksonUtil;
import com.nielsen.retailer.config.api.domain.ServiceByCountry;
import com.nielsen.retailer.config.api.service.ServiceByCountryService;

@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ServiceByCountryControllerTest extends BaseControllerTest {
	
	@MockBean
	private ServiceByCountryService serviceByCountryService; 

	@Before
	public void setup() {
		super.setup();
	}

	@Test
	public void getServices() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("service")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(serviceByCountryService.getServices()).thenReturn(super.serviceByCountrys);
		
		final RequestBuilder request = MockMvcRequestBuilders.get(url)
				.contentType(contentType);
		
		super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody.[0].serviceId").value(super.serviceByCountry.getServiceId()))
		.andDo(print())
		.andReturn();
	}
	
	
	@Test
	public void getServicesByCountryActive() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("service-by-country-active")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(serviceByCountryService.getServicesByCountryActive()).thenReturn(super.serviceByCountrys);
		
		final RequestBuilder request = MockMvcRequestBuilders.get(url)
				.contentType(contentType);
		
		super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody.[0].serviceId").value(super.serviceByCountry.getServiceId()))
		.andDo(print())
		.andReturn();
	} 
	
	@Test
	public void getServicesByCountries() throws Exception {
		
		int [] value = {1};
		
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("services-by-countries")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(serviceByCountryService.getServicesByCountries(value)).thenReturn(super.serviceByCountrys);
		
		final RequestBuilder request = MockMvcRequestBuilders.post(url)
				.contentType(contentType)
				.content(JacksonUtil.toString(value))
				.accept(contentType);
		
        super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody[0].serviceId").value(super.serviceByCountry.getServiceId()))
		.andDo(print())
		.andReturn();
        	
	} 
	
	@Test
	public void getServiceById() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("service")
				.append("/").append("{service_id}")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(serviceByCountryService.getServiceById(isA(Integer.class))).thenReturn(super.serviceByCountry);
		
		final RequestBuilder request = MockMvcRequestBuilders
				.get(url,super.serviceByCountry.getServiceId())
				.accept(contentType)
				.contentType(contentType);
		
        super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody.serviceId").value(super.serviceByCountry.getServiceId()))
		.andDo(print())
		.andReturn();
	}
	
	@Test
	public void getServicesByCountry() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("service-by-country")
				.append("/").append("{countryId}")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(serviceByCountryService.getServicesByCountry(isA(Integer.class))).thenReturn(super.serviceByCountrys);
		
		final RequestBuilder request = MockMvcRequestBuilders
				.get(url,super.country.getCountryId())
				.accept(contentType)
				.contentType(contentType);
		
        super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody.[0].serviceId").value(super.serviceByCountry.getServiceId()))
		.andDo(print())
		.andReturn();
	}
	
	@Test
	public void createServices() throws Exception {

		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("service")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(serviceByCountryService.createServices(isA(ServiceByCountry.class))).thenReturn(1);
		
		final RequestBuilder request = MockMvcRequestBuilders.post(url)
				.contentType(contentType)
				.content(JacksonUtil.toString(super.serviceByCountry))
				.accept(contentType);
		
		super.mockMvc.perform(request)
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody").value(1))
		.andDo(print());

	}
	
	
	@Test
	public void updateService() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("service")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		final Date currentDt = new Date();
		final ServiceByCountry s = new ServiceByCountry();
		s.setServiceId(super.serviceByCountry.getServiceId());
		s.setServiceNm("Scantrack 3");
		s.setCountry(country);
		s.setCreateDt(new Timestamp(currentDt.getTime()));
		s.setUpdateDt(new Timestamp(currentDt.getTime()));
		s.setActive(true);

		when(serviceByCountryService.updateService(isA(ServiceByCountry.class))).thenReturn(1);
		
		final RequestBuilder request = MockMvcRequestBuilders.put(url)
				.contentType(contentType)
				.content(JacksonUtil.toString(s))
				.accept(contentType);
		
		super.mockMvc.perform(request)
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody").value(1))
		.andDo(print());

	}
	
	@Test
	public void deleteService() throws Exception {

		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("service")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(serviceByCountryService.deleteService(isA(ServiceByCountry.class))).thenReturn(1);
		
		final RequestBuilder request = MockMvcRequestBuilders.delete(url)
				.contentType(contentType)
				.content(JacksonUtil.toString(super.serviceByCountry))
				.accept(contentType);
		
		super.mockMvc.perform(request)
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody").value(1))
		.andDo(print());

	}
	
	

}
