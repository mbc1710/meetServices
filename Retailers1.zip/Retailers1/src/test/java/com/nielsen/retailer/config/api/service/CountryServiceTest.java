package com.nielsen.retailer.config.api.service;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.test.context.junit4.SpringRunner;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.BDDMockito.*;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.when;

import com.nielsen.retailer.config.api.domain.Country;

@RunWith(SpringRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CountryServiceTest extends BaseServiceTest {

	@Before
	public void setup() {
		super.setup();
	}

	@Test
	public void getCountries() throws Exception {

		when(countryDao.findAll()).thenReturn(super.countries);

		List<Country> result = countryServices.getCountries();
		assertEquals(2, result.size());

	}

	@Test
	public void getCountriesIsActive() throws Exception {

		when(countryDao.findAllIsActive()).thenReturn(super.countries);

		List<Country> result = countryServices.getCountriesIsActive();
		assertEquals(2, result.size());

	}

	@Test
	public void getCountriesByUser() throws Exception {

		when(countryDao.findAllByUser(isA(Integer.class), isA(Integer.class))).thenReturn(super.countries);

		List<Country> result = countryServices.getCountriesByUser(super.user.getUserId(),2);
		assertEquals(2, result.size());

	}
	
	@Test
	public void getCountryById() {
		
		when(countryDao.findById(isA(Integer.class))).thenReturn(super.country);

		Country result = countryServices.getCountryById(1);
		assertEquals(super.country, result);
		
	}
	
	@Test
	public void deleteCountry() throws Exception {

		when(countryDao.delete(isA(Country.class))).thenReturn(1);

		int result = countryServices.deleteCountry(super.country);
		assertEquals(1, result);

	}

	@Test
	public void createCountry() throws Exception {

		when(countryDao.create(isA(Country.class))).thenReturn(1);

		int result = countryServices.createCountry(super.country);
		assertEquals(1, result);

	}

	@Test
	public void updateCountry() throws Exception {

		final Date currentDt = new Date();
		final Country c = new Country();
		c.setCountryId(super.country.getCountryId());
		c.setCountryNm("México-Update");
		c.setActive(super.country.isActive());
		c.setCodeIso(super.country.getCodeIso());
		c.setShortNm(super.country.getShortNm());
		c.setCreateDt(super.country.getCreateDt());
		c.setUpdateDt(new Timestamp(currentDt.getTime()));

		when(countryDao.update(isA(Country.class))).thenReturn(1);

		int result = countryServices.updateCountry(c);
		assertEquals(1, result);

	}
}
