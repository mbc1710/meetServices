package com.nielsen.retailer.config.api.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import com.nielsen.retailer.config.api.domain.Language;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.nielsen.retailer.config.api.service.LanguageService;

@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class LanguageControllerTest extends BaseControllerTest{

	
	@MockBean
	private LanguageService languageService;
	
	private List<Language> listLanguage;
	
	@Before
	public void setup() {
		super.setup();
		this.mySetUp();
	}
	private void mySetUp(){
		Language l1= new Language();
		l1.setLanguageId(1);
		l1.setCode("l1");
		l1.setLanguageNm("l1");
		
		Language l2= new Language();
		l2.setLanguageId(2);
		l2.setCode("l2");
		l2.setLanguageNm("l2");
		
		Language l3= new Language();
		l3.setLanguageId(3);
		l3.setCode("l3");
		l3.setLanguageNm("l3");
		
		listLanguage = new ArrayList<Language>();
		listLanguage.add(l1);
		listLanguage.add(l2);
		listLanguage.add(l3);		
	}
	
	@Test
	public void getAllLanguage() throws Exception{
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("language")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		
		when(languageService.getAllLanguage()).thenReturn(listLanguage);
		
		final RequestBuilder request = MockMvcRequestBuilders
				.get(url)
				.accept(contentType)
				.contentType(contentType);
		
        super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody.[0].languageId").value(1))
		.andDo(print())
		.andReturn();
		
	}
	
}
