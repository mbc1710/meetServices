package com.nielsen.retailer.config.api.controller;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.sql.Timestamp;
import java.util.Date;

import static org.mockito.BDDMockito.*;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.when;

import com.nielsen.retailer.commons.api.utils.JacksonUtil;
import com.nielsen.retailer.config.api.domain.Report;
import com.nielsen.retailer.config.api.service.ReportService;

@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class ReportControllerTest extends BaseControllerTest {
	
	@MockBean
	private ReportService reportService; 

	@Before
	public void setup() {
		super.setup();
	}
	
	@Test
	public void createReport() throws Exception {

		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("report")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(reportService.createReport(isA(Report.class))).thenReturn(1);
		
		final RequestBuilder request = MockMvcRequestBuilders.post(url)
				.contentType(contentType)
				.content(JacksonUtil.toString(super.report))
				.accept(contentType);
		
		super.mockMvc.perform(request)
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody").value(1))
		.andDo(print());

	}
	
	@Test
	public void updateReport() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("report")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		final Date currentDt = new Date();
		final Report r = new Report();
		r.setReportId(1);
		r.setReportNm("Performance Review");
		r.setParentReportId(0);
		r.setUrl("/promp_01");
		r.setActive(true);
		r.setParent(true);
		r.setCreateDt(new Timestamp(currentDt.getTime()));
		r.setUpdateDt(new Timestamp(currentDt.getTime()));

		when(reportService.updateReport(isA(Report.class))).thenReturn(1);
		
		final RequestBuilder request = MockMvcRequestBuilders.put(url)
				.contentType(contentType)
				.content(JacksonUtil.toString(r))
				.accept(contentType);
		
		super.mockMvc.perform(request)
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody").value(1))
		.andDo(print());

	}
	
	@Test
	public void getReport() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("report")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(reportService.getReport()).thenReturn(super.reports);
		
		final RequestBuilder request = MockMvcRequestBuilders.get(url)
				.contentType(contentType);
		
		super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody.[0].reportId").value(super.report.getReportId()))
		.andDo(print())
		.andReturn();
	}
	
	@Test
	public void getReportIsActive() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("report-is-active")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(reportService.getReportIsActive()).thenReturn(super.reports);
		
		final RequestBuilder request = MockMvcRequestBuilders.get(url)
				.contentType(contentType);
		
		super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody.[0]reportId").value(super.report.getReportId()))
		.andDo(print())
		.andReturn();
	}

	
	@Test
	public void getReportById() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("report")
				.append("/").append("{reportId}")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(reportService.getReportById(isA(Integer.class))).thenReturn(super.report);
		
		final RequestBuilder request = MockMvcRequestBuilders
				.get(url,super.report.getReportId())
				.accept(contentType)
				.contentType(contentType);
		
        super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody.reportId").value(super.report.getReportId()))
		.andDo(print())
		.andReturn();
	}
	
	@Test
	public void getReportByService() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("report-by-service")
				.append("/").append("{serviceId}")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(reportService.getReportByService(isA(Integer.class))).thenReturn(super.reports);
		
		final RequestBuilder request = MockMvcRequestBuilders
				.get(url,super.serviceByCountry.getServiceId())
				.accept(contentType)
				.contentType(contentType);
		
        super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody.[0]reportId").value(super.report.getReportId()))
		.andDo(print())
		.andReturn();
	}
	
	
	
	@Test
	public void getReportsByUserId() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("report-by-user")
				.append("/").append("{userId}")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(reportService.getReportsByUserId(isA(Integer.class))).thenReturn(super.reports);
		
		final RequestBuilder request = MockMvcRequestBuilders
				.get(url,super.user.getUserId())
				.accept(contentType)
				.contentType(contentType);
		
        super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody.[0]reportId").value(super.report.getReportId()))
		.andDo(print())
		.andReturn();
	}
	@Test
	public void deleteReport() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("report")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		final Date currentDt = new Date();
		final Report r = new Report();
		r.setReportId(1);
		r.setReportNm("Performance Review");
		r.setParentReportId(0);
		r.setUrl("/promp_01");
		r.setActive(true);
		r.setParent(true);
		r.setCreateDt(new Timestamp(currentDt.getTime()));
		r.setUpdateDt(new Timestamp(currentDt.getTime()));

		when(reportService.deleteReport(isA(Report.class))).thenReturn(1);
		
		final RequestBuilder request = MockMvcRequestBuilders.delete(url)
				.contentType(contentType)
				.content(JacksonUtil.toString(r))
				.accept(contentType);
		
		super.mockMvc.perform(request)
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody").value(1))
		.andDo(print());

	}
}
