package com.nielsen.retailer.config.api.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.test.context.junit4.SpringRunner;

import com.nielsen.retailer.config.api.domain.ServiceByCountry;

@RunWith(SpringRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ServiceByCountryServiceTest extends BaseServiceTest {

	@Before
	public void setup() {
		super.setup();
	}

	@Test
	public void getServices() throws Exception {

		when(serviceByCountryDao.findAll()).thenReturn(super.serviceByCountrys);

		List<ServiceByCountry> result = serviceByCountryService.getServices();
		assertEquals(2, result.size());

	}

	@Test
	public void getServicesByCountryActive() throws Exception {

		when(serviceByCountryDao.findAllIsActive()).thenReturn(super.serviceByCountrys);

		List<ServiceByCountry> result = serviceByCountryService.getServicesByCountryActive();
		assertEquals(2, result.size());

	}

	@Test
	public void getServicesByCountry() throws Exception {

		when(serviceByCountryDao.findByCountry(isA(Integer.class))).thenReturn(super.serviceByCountrys);

		List<ServiceByCountry> result = serviceByCountryService.getServicesByCountry(2);
		assertEquals(2, result.size());

	}

	@Test
	public void getServiceById() throws Exception {

		when(serviceByCountryDao.findById(isA(Integer.class))).thenReturn(super.serviceByCountry);

		ServiceByCountry result = serviceByCountryService.getServiceById(1);
		assertEquals(super.serviceByCountry, result);

	}

	@Test
	public void createServices() throws Exception {

		when(serviceByCountryDao.create(isA(ServiceByCountry.class))).thenReturn(1);

		int result = serviceByCountryService.createServices(super.serviceByCountry);
		assertEquals(1, result);

	}

	@Test
	public void updateService() throws Exception {

		final Date currentDt = new Date();
		final ServiceByCountry s = new ServiceByCountry();
		s.setServiceId(super.serviceByCountry.getServiceId());
		s.setCountry(super.serviceByCountry.getCountry());
		s.setActive(super.serviceByCountry.isActive());
		s.setServiceNm("México-Update");
		s.setCreateDt(super.serviceByCountry.getCreateDt());
		s.setUpdateDt(new Timestamp(currentDt.getTime()));

		when(serviceByCountryDao.update(isA(ServiceByCountry.class))).thenReturn(1);

		int result = serviceByCountryService.updateService(s);
		assertEquals(1, result);

	}

	@Test
	public void deleteService() throws Exception {

		when(serviceByCountryDao.delete(isA(ServiceByCountry.class))).thenReturn(1);

		int result = serviceByCountryService.deleteService(super.serviceByCountry);
		assertEquals(1, result);

	}

	@Test
	public void getServicesByCountries() throws Exception {

		when(serviceByCountryRepository.findByCountriesId(isA(Integer.class))).thenReturn(super.serviceByCountrys);

		List<ServiceByCountry> result = serviceByCountryService.getServicesByCountries(1);
		assertEquals(super.serviceByCountrys, result);

	}

}
