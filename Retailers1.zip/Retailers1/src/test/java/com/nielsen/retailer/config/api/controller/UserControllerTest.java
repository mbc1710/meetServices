package com.nielsen.retailer.config.api.controller;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.sql.Timestamp;
import java.util.Date;

import static org.mockito.BDDMockito.*;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.when;

import com.nielsen.retailer.commons.api.utils.JacksonUtil;
import com.nielsen.retailer.config.api.domain.User;
import com.nielsen.retailer.config.api.service.UserService;

@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class UserControllerTest extends BaseControllerTest {
	
	@MockBean
	private UserService userService; 

	@Before
	public void setup() {
		super.setup();
	}


	
	@Test
	public void createUser() throws Exception {

		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("user")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(userService.createUser(isA(User.class))).thenReturn(1);
		
		final RequestBuilder request = MockMvcRequestBuilders.post(url)
				.contentType(contentType)
				.content(JacksonUtil.toString(super.user))
				.accept(contentType);
		
		super.mockMvc.perform(request)
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody").value(1))
		.andDo(print());

	}
	
	@Test
	public void deleteUser() throws Exception {

		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("user")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(userService.deleteUser(isA(User.class))).thenReturn(1);
		
		final RequestBuilder request = MockMvcRequestBuilders.delete(url)
				.contentType(contentType)
				.content(JacksonUtil.toString(super.user))
				.accept(contentType);
		
		super.mockMvc.perform(request)
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody").value(1))
		.andDo(print());

	}
	
	@Test
	public void updateUser() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("user")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		final Date currentDt = new Date();
		final User u = new User();
		u.setUserId(super.user.getUserId());
		u.setUserNm("Alexis Araujo");
		u.setEmail(super.user.getEmail());
		u.setActive(false);
		u.setCreateDt(new Timestamp(currentDt.getTime()));
		u.setUpdateDt(super.user.getCreateDt());
		u.setLanguageId(super.user.getLanguageId());

		when(userService.updateUser(isA(User.class))).thenReturn(1);
		
		final RequestBuilder request = MockMvcRequestBuilders.put(url)
				.contentType(contentType)
				.content(JacksonUtil.toString(u))
				.accept(contentType);
		
		super.mockMvc.perform(request)
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody").value(1))
		.andDo(print());

	}

	@Test
	public void getUser() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("user")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(userService.getUsers()).thenReturn(super.users);
		
		final RequestBuilder request = MockMvcRequestBuilders.get(url)
				.contentType(contentType);
		
		super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody.[0].userId").value(super.user.getUserId()))
		.andDo(print())
		.andReturn();
	}
	
	@Test
	public void getUserById() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("user")
				.append("/").append("{user_id}")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();
		
		when(userService.getUserById(isA(Integer.class))).thenReturn(super.user);
		
		final RequestBuilder request = MockMvcRequestBuilders
				.get(url,super.user.getUserId())
				.accept(contentType)
				.contentType(contentType);
		
        super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody.userId").value(super.user.getUserId()))
		.andDo(print())
		.andReturn();
	}
	
	@Test
	public void getUserByEmail() throws Exception {
		final String url = new StringBuilder()
				.append(CountryController.CONTRACT_BASE_URI)
				.append("/").append("/user-by-email")
				.append("?").append(LOCALE.getCountry()).append("_").append(LOCALE.getLanguage()).toString();                
		
		
		
		when(userService.getUserByEmail(isA(String.class))).thenReturn(super.user);
		
		final RequestBuilder request = MockMvcRequestBuilders
				.get(url)
				.header("email", super.user.getEmail())
				.accept(contentType)
				.contentType(contentType);
		
        super.mockMvc.perform(request)
		.andExpect(status().isOk())		
		.andExpect(jsonPath("$.status").value(200))
		.andExpect(jsonPath("$.responseBody.userId").value(super.user.getUserId()))
		.andDo(print())
		.andReturn();
	}
	
}
