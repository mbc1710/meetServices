package com.nielsen.retailer.config.api.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Before;

public class PerformanceReviewControllerTest extends BaseControllerTest{
	
final static Log log = LogFactory.getLog(PerformanceReviewControllerTest.class);


	@Before
	public void setup() {
		super.setup();
	}
	

}
