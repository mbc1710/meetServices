

INSERT INTO mars_config.cat_countries ( code_iso, country_id, country_nm, create_dt, is_active, short_nm, update_dt) 
VALUES ( 'MEX',1 , 'Mexico', '2017-06-30', true, 'MEX', '2017-06-30');

INSERT INTO mars_config.cat_services ( country_id, create_dt, is_active, service_id, service_nm, update_dt) 
VALUES (1 , '2017-06-30', true, 1 , 'Servicio', '2017-06-30' );

INSERT INTO mars_config.cat_retailers ( is_active, retailer_external_id, retailer_id, retailer_nm, service_id) 
VALUES ( true,1 ,1 , 'Mexico', 1 );

INSERT INTO mars_config.cat_commercial_structs 
( commercial_struct_id, commercial_struct_nm, create_dt, is_active, retailer_id, update_dt) 
VALUES ( 1, 'Mexico', '2017-06-30',true,1, '2017-06-30' );