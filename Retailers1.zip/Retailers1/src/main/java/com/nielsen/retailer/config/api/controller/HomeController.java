package com.nielsen.retailer.config.api.controller;

import org.slf4j.LoggerFactory;

import java.sql.*;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.nielsen.retailer.commons.api.utils.Response;
import com.nielsen.retailer.config.api.util.MessageService;

import ch.qos.logback.classic.BasicConfigurator;

@CrossOrigin
@RestController
@RequestMapping(value = "/retailer-config-api")
public class HomeController {

	final static Logger logger = LoggerFactory.getLogger(BasicConfigurator.class);

	@Autowired
	private MessageService messageSource;

	// Define a string as the fully qualified class name (FQCN) of
	// the desired JDBC driver
	static String JDBCDriver = "java.sql.Driver";
	// Define a string as the connection URL
	static String ConnectionURL = "jdbc:impala://tparhebfmi006.enterprisenet.org:21050/mars_datamart_sr";

	@RequestMapping("/home")
	public @ResponseBody ResponseEntity<Response<String>> home() {
		final String msg = messageSource.getMessage("api.controller.home");
		Response<String> response = new Response<String>(msg);
		// com.cloudera.impala.jdbc.jdbc4.
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		StringBuilder sb = new StringBuilder();
		try {
			// Register the driver using the class name
			Class.forName(JDBCDriver);
			// String insert = "insert into cat_filter_values(type_id, value_nm)
			// PARTITION (selection_id = 2) values(1, cast('01' as
			// varchar(100)))";
			// Establish a connection using the connection URL

			String query = "CREATE TABLE cat_filter_values (   type_id INT,    value_nm VARCHAR(100) ) PARTITIONED BY (   selection_id INT )";

			con = DriverManager.getConnection(ConnectionURL, "olympia_user", "PrgShrUZw3BN");
			//con.prepareStatement(query).execute();
			//query = "compute stats cat_filter_values";
			//con.prepareStatement(query).execute();
			//query = "refresh cat_filter_values";
			//con.prepareStatement(query).execute();
			rs = con.prepareStatement("select selection_id, type_id,  value_nm from cat_filter_values").executeQuery();

			while (rs.next()) {
				System.out.println("===> " + rs.getString(1));
				System.out.println("===> " + rs.getString(2));
				System.out.println("===> " + rs.getString(3));
				sb.append(rs.getInt(1)).append("-").append(rs.getInt(1)).append("-").append(rs.getString(2)).append("\n");
			}
			response.setMessage(sb.toString());
			System.out.println("Estamos conectados ? " + !con.isClosed());
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}

		return new ResponseEntity<Response<String>>(response, HttpStatus.valueOf(response.getStatus()));
	}
}
