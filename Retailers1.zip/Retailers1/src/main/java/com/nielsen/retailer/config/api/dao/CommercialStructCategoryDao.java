package com.nielsen.retailer.config.api.dao;

import java.util.List;

import com.nielsen.retailer.config.api.domain.CommercialStructCategory;

public interface CommercialStructCategoryDao {
	public List<CommercialStructCategory> findByRetailerIdAndUserId(int retailerId, int userId);
}
