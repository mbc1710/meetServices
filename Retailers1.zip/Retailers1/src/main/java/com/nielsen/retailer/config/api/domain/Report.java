package com.nielsen.retailer.config.api.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "cat_reports")
@Table(name = "cat_reports", schema = "mars_config")
public class Report implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "report_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int reportId;

	@Column(name = "report_nm")
	private String reportNm;
	
	@Column(name = "parent_report_id")
	private int parentReportId;

	@Column(name = "url")
	private String url;
	
	@Column(name = "is_active")
	private boolean active;
	
	@Column(name = "is_parent")
	private boolean isParent;
	
	@Column(name = "create_dt")
	private Timestamp createDt;

	@Column(name = "update_dt")
	private Timestamp updateDt;
	
	
	public int getReportId() { 
		return reportId;
	}

	public void setReportId(int reportId) {
		this.reportId = reportId;
	}

	public String getReportNm() {
		return reportNm;
	}

	public void setReportNm(String reportNm) {
		this.reportNm = reportNm;
	}

	public int getParentReportId() {
		return parentReportId;
	}

	public void setParentReportId(int parentReportId) {
		this.parentReportId = parentReportId;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}



	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public boolean isParent() {
		return isParent;
	}

	public void setParent(boolean isParent) {
		this.isParent = isParent;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Report [reportId=");
		builder.append(reportId);
		builder.append(", reportNm=");
		builder.append(reportNm);
		builder.append(", parentReportId=");
		builder.append(parentReportId);
		builder.append(", url=");
		builder.append(url);
		builder.append(", isActive=");
		builder.append(active);
		builder.append(", isParent=");
		builder.append(isParent);
		builder.append(", createDt=");
		builder.append(createDt);
		builder.append(", updateDt=");
		builder.append(updateDt);		
		builder.append("]");
		return builder.toString();
	}
}
