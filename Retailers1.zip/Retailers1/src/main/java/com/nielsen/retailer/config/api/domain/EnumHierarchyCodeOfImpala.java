package com.nielsen.retailer.config.api.domain;

public enum EnumHierarchyCodeOfImpala {	
		 TMCB(1), TCMB(2), TMB(3);
		EnumHierarchyCodeOfImpala(int id) {
			this.id = id;
		}

		private int id;

		public int getId() {
			return id;
		}
}
