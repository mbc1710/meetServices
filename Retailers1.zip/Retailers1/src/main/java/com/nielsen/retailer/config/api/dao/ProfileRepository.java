package com.nielsen.retailer.config.api.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nielsen.retailer.config.api.domain.Profile;

@Repository
@Transactional(readOnly = true)
public interface ProfileRepository extends JpaRepository<Profile, Integer> {

	@Query(value = "SELECT p FROM cat_profiles p WHERE p.service.serviceId in (:serviceId) ")
	public List<Profile> findByServiceId(@Param("serviceId") int ... serviceId);
	
}
