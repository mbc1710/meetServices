package com.nielsen.retailer.config.api.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity(name = "cat_commercial_struct_details")
@Table(name = "cat_commercial_struct_details", schema = "mars_config")
@IdClass(CommercialStructDetailPK.class)
public class CommercialStructDetail implements Serializable, Comparable<CommercialStructDetail> {

	private static final long serialVersionUID = 1L;

	@Id
	@NotNull
	@Column(name = "commercial_struct_id")
	private int commercialStructId;

	@Id
	@NotNull
	@Column(name = "format_id")
	private int formatId;

	@Column(name = "format_nm")
	private String formatNm;

	@Column(name = "infact_nm")
	private String infactNm;

	@Column(name = "level_1")
	private String level1;

	@Column(name = "level_2")
	private String level2;

	@Column(name = "level_3")
	private String level3;

	@Column(name = "is_active")
	private boolean active;

	public CommercialStructDetail() {
	}

	public int getCommercialStructId() {
		return commercialStructId;
	}

	public void setCommercialStructId(int commercialStructId) {
		this.commercialStructId = commercialStructId;
	}

	public int getFormatId() {
		return formatId;
	}

	public void setFormatId(int formatId) {
		this.formatId = formatId;
	}

	public String getFormatNm() {
		return formatNm;
	}

	public void setFormatNm(String formatNm) {
		this.formatNm = formatNm;
	}

	public String getInfactNm() {
		return infactNm;
	}

	public void setInfactNm(String infactNm) {
		this.infactNm = infactNm;
	}

	public String getLevel1() {
		return level1;
	}

	public void setLevel1(String level1) {
		this.level1 = level1;
	}

	public String getLevel2() {
		return level2;
	}

	public void setLevel2(String level2) {
		this.level2 = level2;
	}

	public String getLevel3() {
		return level3;
	}

	public void setLevel3(String level3) {
		this.level3 = level3;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	@Override
	public int compareTo(CommercialStructDetail o) {
		if (commercialStructId == o.getCommercialStructId() && formatId == o.getFormatId())
			return 0;
		else if (commercialStructId > o.getCommercialStructId() && formatId == o.getFormatId())
			return 1;
		else
			return -1;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj instanceof Retailer) {
			CommercialStructDetail o = (CommercialStructDetail) obj;
			return (commercialStructId == o.getCommercialStructId() && formatId == o.getFormatId()) ? true : false;
		}
		return false;
	}
}

class CommercialStructDetailPK implements Serializable {

	private static final long serialVersionUID = 1L;

	private int commercialStructId;
	private int formatId;

	public CommercialStructDetailPK() {
	}

	public CommercialStructDetailPK(int commercialStructId, int formatId) {
		this.commercialStructId = commercialStructId;
		this.formatId = formatId;
	}

	public int getCommercialStructId() {
		return commercialStructId;
	}

	public void setCommercialStructId(int commercialStructId) {
		this.commercialStructId = commercialStructId;
	}

	public int getFormatId() {
		return formatId;
	}

	public void setFormatId(int formatId) {
		this.formatId = formatId;
	}

	@Override
	public int hashCode() {
		String code = "" + this.getCommercialStructId() + "" + getFormatId();
		return Integer.parseInt(code);
	}

	@Override
	public boolean equals(Object o) {
		boolean flag = false;
		CommercialStructDetailPK myId = (CommercialStructDetailPK) o;

		if ((o instanceof CommercialStructDetailPK) && (this.getCommercialStructId() == myId.getCommercialStructId())
				&& (this.getFormatId() == myId.getFormatId())) {
			flag = true;
		}
		return flag;
	}
}
