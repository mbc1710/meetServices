package com.nielsen.retailer.config.api.service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nielsen.retailer.config.api.dao.RetailerDao;
import com.nielsen.retailer.config.api.dao.RetailerRepository;
import com.nielsen.retailer.config.api.domain.FileRetailer;
import com.nielsen.retailer.config.api.domain.Retailer;

@Service
public class RetailerService {

	@Autowired
	private RetailerDao retailerDao;

	@Autowired
	private RetailerRepository retailerRepository;

	public List<Retailer> getRetailer(int serviceId) {
		List<Retailer> list = retailerDao.findByService(serviceId);
		return list;
	}
	
	public List<Retailer> getRetailerIsActive(int serviceId) {
		List<Retailer> list = retailerDao.findByServiceIsActive(serviceId);
		return list;
	}
	
	public int createRetailer(Retailer retailer) {
		return retailerRepository.save(retailer) == null ? 0 : 1;
	}

	public int createRetailers(int serviceId, List<FileRetailer> records) {
		Set<Retailer> retailers = new HashSet<>(1);
		retailerDao.updateAllByService(serviceId);
		for (FileRetailer record : records) {
			Retailer retailer = null;
			retailer = retailerDao.findByExternalId(serviceId, record.getRetailerExternalId());
			if (retailer != null) {
				retailer.setRetailerNm(record.getRetailerNm());
				retailer.setActive(true);
			} else {
				retailer = new Retailer();
				retailer.setRetailerNm(record.getRetailerNm());
				retailer.setActive(true);
				retailer.setRetailerExternalId(record.getRetailerExternalId());
				retailer.setServiceId(serviceId);
			}
			retailers.add(retailer);
		}
		if (retailers.size() > 0) {
			retailerRepository.save(retailers);
		}

		return 1;
	}

	public List<Retailer> getRetailerById(int retailerId) {
		List<Retailer> list = retailerRepository.findRetailerById(retailerId);
		return list;
	}

	public int updateRetailerById(Retailer retailer) {
		return retailerDao.update(retailer);
	}
	
	public int updateRetailerStatus(Retailer retailer) {
		return retailerDao.updateStatus(retailer);
	}
	
	public List<Retailer> getRetailerByUserId(int userId, int countryId){
		return retailerDao.findByUser(userId, countryId);
	}
	
	public List<Retailer> getRetailerByUserIdAndCountryHyerarchy(int userId, int countryId){
		return retailerDao.findByUserHyerarchy(userId, countryId);
	}

	public List<Retailer> findByMarkets(int ... marketsId) {
		// TODO Auto-generated method stub
		return retailerRepository.findRetailerByMarket(marketsId);
	}

}