package com.nielsen.retailer.config.api.domain;

import java.io.Serializable;
import java.util.List;

public class RptProductHierarchy implements Serializable {
	private static final long serialVersionUID = 1L;

	private int levelId;
	private int hierarchyId;
	private String description;

	private List<SelectedProductHierarchy> detail;

	public int getLevelId() {
		return levelId;
	}

	public void setLevelId(int levelId) { 
		this.levelId = levelId;
	}

	public int getHierarchyId() {
		return hierarchyId;
	}

	public void setHierarchyId(int prodHierId) {
		this.hierarchyId = prodHierId;
	}

	public RptProductHierarchy() {
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<SelectedProductHierarchy> getDetail() {
		return detail;
	}

	public void setDetail(List<SelectedProductHierarchy> detail) {
		this.detail = detail;
	}
}
