package com.nielsen.retailer.config.api.service;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nielsen.retailer.config.api.dao.CatValueDao;
import com.nielsen.retailer.config.api.dao.CommercialStructDetailDao;
import com.nielsen.retailer.config.api.dao.CommercialStructHeaderRepository;
import com.nielsen.retailer.config.api.dao.ProductHierarchyDao;
import com.nielsen.retailer.config.api.domain.CatValue;
import com.nielsen.retailer.config.api.domain.CommercialStructHeader;
import com.nielsen.retailer.config.api.domain.RptCommercialStrunct;
import com.nielsen.retailer.config.api.domain.RptProductHierarchy;
import com.nielsen.retailer.config.api.domain.Selected;
import com.nielsen.retailer.config.api.domain.SelectedProductHierarchy;

@Service
public class PerformanceReviewService {

	@Autowired
	private CommercialStructHeaderRepository structHeaderRepository;

	@Autowired
	private CommercialStructDetailDao structDetailDao;

	@Autowired
	private CatValueDao catValueDao;

	@Autowired
	private ProductHierarchyDao productHierarchyDao;

	public List<CatValue> getSelectByTypeId(int serviceId, int reportId, int userId, Integer[] typeId) {
		List<CatValue> values = catValueDao.findAll(serviceId, reportId, userId, typeId);
		for (CatValue catValue : values) {
			Hibernate.initialize(catValue.getUrls());
		}
		return values;
	}

	public List<RptCommercialStrunct> getCommercialStruct(int reportId, int retailerId, int userId) {
		final CommercialStructHeader h = structHeaderRepository.findByRetailerId(retailerId, reportId, userId);
		final List<RptCommercialStrunct> list = new ArrayList<>();

		if (h != null) {

			if (h.getLevelOneNm() != null) {
				final RptCommercialStrunct rpt1 = new RptCommercialStrunct();
				List<Selected> result1 = structDetailDao.findByLevel1(h.getCommercialStructId(), retailerId, reportId,
						userId);
				rpt1.setDescription(h.getLevelOneNm());
				rpt1.setDetail(result1);
				list.add(rpt1);
			}

			if (h.getLevelTwoNm() != null) {
				final RptCommercialStrunct rpt2 = new RptCommercialStrunct();
				List<Selected> result2 = structDetailDao.findByLevel2(h.getCommercialStructId(), retailerId, reportId,
						userId);
				rpt2.setDescription(h.getLevelTwoNm());
				rpt2.setDetail(result2);
				list.add(rpt2);
			}

			final RptCommercialStrunct rpt3 = new RptCommercialStrunct();
			List<Selected> result3 = structDetailDao.findByLevel3(h.getCommercialStructId(), retailerId, reportId,
					userId);
			rpt3.setDescription(h.getLevelThreeNm());
			rpt3.setDetail(result3);
			list.add(rpt3);

			final RptCommercialStrunct rpt4 = new RptCommercialStrunct();
			List<Selected> result4 = structDetailDao.findByLevel4(h.getCommercialStructId(), retailerId, reportId,
					userId);
			rpt4.setDescription("Categoria");
			rpt4.setDetail(result4);
			list.add(rpt4);

		}

		return list;
	}

	public List<RptProductHierarchy> getProductStruct(int serviceId, int reportId, int retailerId, int userId) {
		final List<RptProductHierarchy> list = new ArrayList<>();

		return list;
	}

	public List<RptProductHierarchy> getPerformanceReviewHeader(int serviceId, int retailerId, int reportId) {
		return productHierarchyDao.findPerformanceReviewHeader(serviceId, retailerId, reportId);
	}

	public List<RptProductHierarchy> getAllCatalogPerformanceReviewHierarchy(int serviceId, int retailerId,
			int reportId) {
		List<RptProductHierarchy> list = new ArrayList<>();
		list = productHierarchyDao.findByServiceIdAndRetailerId(serviceId, retailerId, reportId);

		for (RptProductHierarchy item : list) {
			List<SelectedProductHierarchy> details = productHierarchyDao.findByHierarchyIdAndLevelId(serviceId,
					item.getHierarchyId(), item.getLevelId(), reportId);
			item.setDetail(details);
		}
		return list;
	}

	public int getLevelCeroProductHierarchy(int serviceId, int retailerId, int reportId) {
		SelectedProductHierarchy detail = productHierarchyDao.findLevelCeroByServiceIdAndRetailerId(serviceId,
				retailerId, reportId);
		if (detail != null) {
			return detail.getProductId();
		} else {
			return -1;
		}
	}

	public List<SelectedProductHierarchy> getManufacturers(int serviceId, String code, int retailerId, int reportId) {
		int levelId = 1;

		List<SelectedProductHierarchy> detail = productHierarchyDao.findManufacturers(serviceId, code, levelId,
				retailerId, reportId);
		SelectedProductHierarchy s = new SelectedProductHierarchy();
		s.setDescription("Top 100 Suppliers on Sales Value (RM) for Latest 52 Weeks");
		s.setParentId(-1);
		s.setProductId(-1);
		detail.add(s);
		return detail;

	}

	public List<SelectedProductHierarchy> getReviewCategory(int serviceId, String code, int retailerId, int reportId) {
		int levelId = 1;

		List<SelectedProductHierarchy> detail = productHierarchyDao.findManufacturers(serviceId, code, levelId,
				retailerId, reportId);

		return detail;

	}

	public List<SelectedProductHierarchy> getManufacturersId(int serviceId, int productId, String code, int retailerId,
			int reportId) {
		int levelId = 1;

		List<SelectedProductHierarchy> detail = productHierarchyDao.findManufacturersId(serviceId, code, levelId,
				productId, retailerId, reportId);
		SelectedProductHierarchy s = new SelectedProductHierarchy();
		s.setDescription("Top 100 Suppliers on Sales Value (RM) for Latest 52 Weeks");
		s.setParentId(-1);
		s.setProductId(-1);
		detail.add(s);
		return detail;

	}

}
