package com.nielsen.retailer.config.api.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "rel_profile_commercial_structs")
@Table(name = "rel_profile_commercial_structs", schema = "mars_config")
public class RelProfileCommercialStruct implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "profile_id")
	private int profileId;

	@Id
	@Column(name = "commercial_struct_id")
	private int commercialStructId;
	
	@Id
	@Column(name = "format_id")
	private int formatId;
	
	
	public int getProfileId() {
		return profileId;
	}

	public void setProfileId(int profileId) {
		this.profileId = profileId;
	}

	public int getCommercialStructId() {
		return commercialStructId;
	}

	public void setCommercialStructId(int commercialStructId) {
		this.commercialStructId = commercialStructId;
	}

	public int getFormatId() {
		return formatId;
	}

	public void setFormatId(int formatId) {
		this.formatId = formatId;
	}

	@Override
	public String toString() {
		return "RelProfileCommercialStruct [profileId=" + profileId + ", commercialStructId=" + commercialStructId
				+ ", formatId=" + formatId + "]";
	}
	
	

	
}
