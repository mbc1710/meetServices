package com.nielsen.retailer.config.api.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nielsen.retailer.config.api.domain.CommercialStruct;

@Repository
public interface CommercialStructRepository extends JpaRepository<CommercialStruct, Integer> {

}
