package com.nielsen.retailer.config.api.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.nielsen.retailer.commons.api.utils.Response;
import com.nielsen.retailer.config.api.domain.ServiceByCountry;
import com.nielsen.retailer.config.api.service.ServiceByCountryService;
import com.nielsen.retailer.config.api.util.MessageService;

import ch.qos.logback.classic.BasicConfigurator;

@CrossOrigin
@RestController
@RequestMapping(value = "/retailer-config-api")
public class ServiceByCountryController {
	final static Logger logger = LoggerFactory.getLogger(BasicConfigurator.class);

	@Autowired
	private MessageService messageSource;

	@Autowired
	private ServiceByCountryService servicesService;

	@RequestMapping(value = { "/service" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<ServiceByCountry>>> getServices() {
		
		List<ServiceByCountry> services = servicesService.getServices();
		Response<List<ServiceByCountry>> response;
		String msg = "";
		
		if (!(services != null && services.size() > 0)) {
			msg = messageSource.getMessage("api.service.messages.1000");
		}
		
		response = new Response<List<ServiceByCountry>>(services, msg);
		return new ResponseEntity<Response<List<ServiceByCountry>>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/service-by-country-active" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<ServiceByCountry>>> getServicesBycountryActive() {
		
		List<ServiceByCountry> services = servicesService.getServicesByCountryActive();
		Response<List<ServiceByCountry>> response;
		String msg = "";
		
		if (!(services != null && services.size() > 0)) {
			msg = messageSource.getMessage("api.service.messages.1000");
		}
		
		response = new Response<List<ServiceByCountry>>(services, msg);
		return new ResponseEntity<Response<List<ServiceByCountry>>>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@RequestMapping(value = { "/service-by-country/{countryId}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<ServiceByCountry>>> getServicesByCountry(
			@PathVariable(name = "countryId", required = true) int countryId) {
		List<ServiceByCountry> services = servicesService.getServicesByCountry(countryId);
		Response<List<ServiceByCountry>> response;
		String msg = "";
		
		if (!(services != null && services.size() > 0)) {
			msg = messageSource.getMessage("api.retailer.messages.1000");
		}
		
		response = new Response<List<ServiceByCountry>>(services, msg);
		return new ResponseEntity<Response<List<ServiceByCountry>>>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@RequestMapping(value = { "/service-by-country-user/{countryId}/{userId}/{reportId}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<ServiceByCountry>>> getServicesByCountryUser(
			@PathVariable(name = "countryId", required = true) int countryId,
			@PathVariable(name = "userId", required = true) int userId,
			@PathVariable(name = "reportId", required = true) int reportId) {
		List<ServiceByCountry> services = servicesService.getServicesByCountryUser(countryId,userId,reportId);
		Response<List<ServiceByCountry>> response;
		String msg = "";
		
		if (!(services != null && services.size() > 0)) {
			msg = messageSource.getMessage("api.retailer.messages.1000");
		}
		
		response = new Response<List<ServiceByCountry>>(services, msg);
		return new ResponseEntity<Response<List<ServiceByCountry>>>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@RequestMapping(value = { "/services-by-countries" }, method = { RequestMethod.POST })
	public @ResponseBody ResponseEntity<Response<List<ServiceByCountry>>> getServicesByCountries(
			@RequestBody int[] countryId) {
		
		List<ServiceByCountry> services = servicesService.getServicesByCountries(countryId);
		Response<List<ServiceByCountry>> response;
		String msg = "";
		
		if (!(services != null && services.size() > 0)) {
			msg = messageSource.getMessage("api.service.messages.1004");
		}else{
			msg = messageSource.getMessage("api.service.messages.1008");
		}
		
		response = new Response<List<ServiceByCountry>>(services, msg);
		return new ResponseEntity<Response<List<ServiceByCountry>>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/service/{service_id}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<ServiceByCountry>> getServiceById(
			@PathVariable(name = "service_id", required = true) int id) {
		final String msg = messageSource.getMessage("api.service.messages.1000");
		ServiceByCountry service = servicesService.getServiceById(id);
		Response<ServiceByCountry> response;

		if (service == null) {
			response = new Response<ServiceByCountry>(service, msg);
		} else {
			response = new Response<ServiceByCountry>(service);
		}

		return new ResponseEntity<Response<ServiceByCountry>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/service" }, method = { RequestMethod.DELETE })
	public @ResponseBody ResponseEntity<Response<Integer>> deleteService(@RequestBody ServiceByCountry service) {
		String msg = "";
		int result = servicesService.deleteService(service);
		Response<Integer> response;

		if (result != 1) {
			msg = messageSource.getMessage("api.service.messages.1003");
		} else {
			msg = messageSource.getMessage("api.service.messages.1007");
		}

		response = new Response<Integer>(result, msg);

		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/service" }, method = { RequestMethod.PUT })
	public @ResponseBody ResponseEntity<Response<Integer>> updateService(@RequestBody ServiceByCountry service) {
		String msg = "";
		int result = servicesService.updateService(service);
		Response<Integer> response;

		if (result != 1) {
			msg = messageSource.getMessage("api.service.messages.1002");
		} else {
			msg = messageSource.getMessage("api.service.messages.1006");
		}

		response = new Response<Integer>(result, msg);

		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	
	@RequestMapping(value = { "/service-status" }, method = { RequestMethod.PUT })
	public @ResponseBody ResponseEntity<Response<Integer>> updateServiceStatus(@RequestBody ServiceByCountry service) {
		String msg = "";
		int result = servicesService.updateServiceStatus(service);
		Response<Integer> response;
	if (result != 1) {
			msg = messageSource.getMessage("api.user.messages.1002");
		} else {
			msg = messageSource.getMessage("api.user.messages.1006");
		}

		response = new Response<Integer>(result, msg);

		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@RequestMapping(value = { "/service" }, method = { RequestMethod.POST })
	public @ResponseBody ResponseEntity<Response<Integer>> createService(@RequestBody ServiceByCountry service) {
		String msg = "";
		int result = servicesService.createServices(service);
		Response<Integer> response;
		if (result != 1) {
			msg = messageSource.getMessage("api.service.messages.1001");
		} else {
			msg = messageSource.getMessage("api.service.messages.1005");
		}
		response = new Response<Integer>(result, msg);
		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}
}
