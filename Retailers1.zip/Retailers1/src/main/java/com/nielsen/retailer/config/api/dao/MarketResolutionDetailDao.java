package com.nielsen.retailer.config.api.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nielsen.retailer.config.api.domain.MarketResolutionDetail;

@Repository
@Transactional(readOnly = true)
public interface MarketResolutionDetailDao extends JpaRepository<MarketResolutionDetail, Integer> {

	@Query(value = "SELECT mtr FROM cat_market_resolution_details mtr WHERE mtr.resolutionId in (:resolutionId)")
	public List<MarketResolutionDetail> findByResolutionId(@Param("resolutionId") int... resolutionId);

	@Query(value = "SELECT mtr FROM cat_market_resolution_details mtr WHERE mtr.resolutionId in (:resolutionId) AND active = true")
	public List<MarketResolutionDetail> findByResolutionIdIsActive(@Param("resolutionId") int... resolutionId);

	@Query(value = "SELECT DISTINCT mrd FROM cat_market_resolution_details mrd, rel_profile_markets pm  WHERE mrd.marketId = pm.marketId AND pm.profileId = :profileId")
	public List<MarketResolutionDetail> findByProfileId(@Param("profileId") int profileId);

	@Query(value = " SELECT DISTINCT mrd.* FROM mars_config.cat_services cs "
			+ " inner join mars_config.cat_market_definitions md on cs.service_id = md.service_id "
			+ " inner join mars_config.cat_market_resolutions mr on md.definition_id = mr.definition_id "
			+ " inner join mars_config.cat_market_resolution_details mrd on mr.resolution_id = mrd.resolution_id "
			+ " inner join mars_config.rel_profile_markets pm on mrd.market_id = pm.market_id "
			+ " inner join mars_config.rel_user_profiles up on pm.profile_id = up.profile_id "
			+ " inner join mars_config.cat_market_types mt on mr.type_id = mt.type_id and mt.is_total = false "
			+ " inner join mars_config.cat_retailers cr on cs.service_id = cr.service_id "
			+ " inner join mars_config.rel_market_retailer rmr on (rmr.market_id = mrd.market_id and cr.retailer_id = rmr.retailer_id)"
			+ " where up.user_id = :userId and rmr.retailer_id = :retailerId  and cs.service_id = :serviceId "
			+ " order by mrd.market_nm ", nativeQuery = true)
	public List<MarketResolutionDetail> findByUserIdNoTotal(
			@Param("userId") int userId,
			@Param("retailerId") int retailerId,
			@Param("serviceId") int serviceId);
	
	
	@Query(value = " SELECT DISTINCT mrd.* FROM mars_config.cat_services cs"
			+ " inner join mars_config.cat_market_definitions md on (cs.service_id = md.service_id ) "
			+ " inner join mars_config.cat_market_resolutions mr on (md.definition_id = mr.definition_id) "
			+ " inner join mars_config.cat_market_resolution_details mrd on (mr.resolution_id = mrd.resolution_id) "
			+ " inner join mars_config.rel_profile_markets pm on (mrd.market_id = pm.market_id) "
			+ " inner join mars_config.rel_user_profiles up on (pm.profile_id = up.profile_id) "
			+ " inner join mars_config.cat_market_types mt on (mr.type_id = mt.type_id and mt.is_total = true) "
			+ " inner join mars_config.rel_comparison_markets rcm on (mrd.market_id = rcm.comparison_market_id and rcm.market_id = :marketId) "
			+ " where up.user_id = :userId and cs.service_id = :serviceId order by mrd.market_nm", nativeQuery = true)
	public List<MarketResolutionDetail> findByUserProfileIdIsTotal(
			@Param("userId") int userId,
			@Param("serviceId") int serviceId,
			@Param("marketId") int marketId);
	
}