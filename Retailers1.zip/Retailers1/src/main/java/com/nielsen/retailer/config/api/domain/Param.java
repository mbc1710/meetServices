package com.nielsen.retailer.config.api.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "cat_params")
@Table(name = "cat_params", schema = "mars_config")
public class Param implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "param_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int paramId;

	@Column(name = "param_nm")
	private String paramNm;

	@Column(name = "param_value")
	private String paramValue;

	public Param() {
	}

	public int getParamId() {
		return paramId;
	}

	public void setParamId(int paramId) {
		this.paramId = paramId;
	}

	public String getParamNm() {
		return paramNm;
	}

	public void setParamNm(String paramNm) {
		this.paramNm = paramNm;
	}

	public String getParamValue() {
		return paramValue;
	}

	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}

}
