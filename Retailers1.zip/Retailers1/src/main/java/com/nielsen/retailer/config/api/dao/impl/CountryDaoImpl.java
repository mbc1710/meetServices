package com.nielsen.retailer.config.api.dao.impl;

import java.util.Date;
import java.sql.Timestamp;
import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nielsen.retailer.config.api.dao.CountryDao;
import com.nielsen.retailer.config.api.domain.Country;

@Repository
@Transactional(readOnly = true)
public class CountryDaoImpl implements CountryDao {

	@PersistenceContext
	EntityManager em;

	final static Logger logger = LoggerFactory.getLogger(ProfileDaoImpl.class);

	@Override
	public List<Country> findAll() {
		TypedQuery<Country> query = em.createQuery("SELECT c FROM cat_countries c order by id", Country.class);
		return query.getResultList();
	}

	@Override
	public List<Country> findAllIsActive() {
		TypedQuery<Country> query = em.createQuery("SELECT c FROM cat_countries c where c.active = true  order by id",
				Country.class);
		return query.getResultList();
	}

	@Override
	public List<Country> findAllByUser(int userId, int reportId) {
		
		TypedQuery<Country> query = em.createQuery("select distinct c "
				+ " from cat_countries c, "
				+ " cat_services cs, "
				+ " cat_profiles cp, "
				+ " rel_user_profiles rup, "
				+ " rel_profile_reports rpr,"
				+ " cat_retailers cr,"
				+ " cat_commercial_structs ccs "
				+ " where c.active = true "
				+ " and cp.active = true "
				+ " and cr.active = true "
				+ " and ccs.active = true "
				+ " and c.countryId = cs.country "
				+ " and cp.service = cs.serviceId "
				+ " and rup.profileId = rpr.profileId "
				+ " and cp.profileId = rup.profileId "
				+ " and cs.serviceId = cr.serviceId "
				+ " and cr.retailerId = ccs.retailer "
				+ " and rup.userId = :userId "
				+ " and rpr.reportId = :reportId "
				, Country.class);
		query.setParameter("userId",userId);
		query.setParameter("reportId",reportId);
		
		return query.getResultList();
	}

	@Override
	public Country findById(int id) {
		TypedQuery<Country> query = em.createQuery("SELECT c FROM cat_countries c WHERE country_id = :country_id",
				Country.class);
		query.setParameter("country_id", id);
		List<Country> list = query.getResultList();
		return (list == null || list.size() == 0) ? null : list.get(0);
	}

	@Override
	@Transactional(readOnly = false)
	public int update(Country obj) {
		obj.setUpdateDt(new Timestamp((new Date()).getTime()));
		em.merge(obj);
		return 1;
	}
	
	@Override
	@Transactional(readOnly = false)
	public int updateStatus(Country obj) {
		
		Boolean active = obj.isActive();
		int countryId = obj.getCountryId();
	
		Query query = em.createQuery("UPDATE cat_countries SET active = :active WHERE countryId = :countryId");
		query.setParameter("active", active);
		query.setParameter("countryId", countryId);
		em.flush();
		return query.executeUpdate();
	}

	@Override
	@Transactional(readOnly = false)
	public int create(Country obj) {
		obj.setCreateDt(new Timestamp((new Date()).getTime()));
		obj.setUpdateDt(new Timestamp((new Date()).getTime()));
		obj.setActive(true);
		em.persist(obj);
		return 1;
	}

	@Override
	@Transactional(readOnly = false)
	public int delete(Country obj) {
		Query query = em.createQuery("DELETE FROM cat_countries WHERE country_id = :country_id");
		query.setParameter("country_id", obj.getCountryId());
		return query.executeUpdate();
	}

}
