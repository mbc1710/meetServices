package com.nielsen.retailer.config.api.domain;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity(name = "cat_market_resolution_details")
@Table(name = "cat_market_resolution_details", schema = "mars_config")
public class MarketResolutionDetail implements Serializable {

	private static final long serialVersionUID = -4641487683126440335L;

	@Id
	@Column(name = "market_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int marketId;

	@Column(name = "market_nm")
	private String marketNm;

	@Column(name = "market_tag_id")
	private String marketTagId;

	@Column(name = "market_parent_id")
	private int marketParentId;

	@Column(name = "level_id")
	private int levelId;

	@Column(name = "market_parent_tag_id")
	private String marketParentTagId;

	@Column(name = "is_active")
	private boolean active;

	@Column(name = "resolution_id")
	private int resolutionId;

	@Transient
	@JsonProperty
	private MarketResolution marketResolution;

	@ManyToMany(mappedBy = "markets")
	@JsonBackReference
	private Set<Retailer> retailers;

	public Set<Retailer> getRetailers() {
		return retailers;
	}

	public void setRetailers(Set<Retailer> retailers) {
		this.retailers = retailers;
	}

	public MarketResolution getMarketResolution() {
		return marketResolution;
	}

	public void setMarketResolution(MarketResolution marketResolution) {
		this.marketResolution = marketResolution;
	}

	public int getMarketId() {
		return marketId;
	}

	public void setMarketId(int marketId) {
		this.marketId = marketId;
	}

	public String getMarketNm() {
		return marketNm;
	}

	public void setMarketNm(String marketNm) {
		this.marketNm = marketNm;
	}

	public String getMarketTagId() {
		return marketTagId;
	}

	public void setMarketTagId(String marketTagId) {
		this.marketTagId = marketTagId;
	}

	public int getMarketParentId() {
		return marketParentId;
	}

	public void setMarketParentId(int marketParentId) {
		this.marketParentId = marketParentId;
	}

	public int getLevelId() {
		return levelId;
	}

	public void setLevelId(int levelId) {
		this.levelId = levelId;
	}

	public String getMarketParentTagId() {
		return marketParentTagId;
	}

	public void setMarketParentTagId(String marketParentTagId) {
		this.marketParentTagId = marketParentTagId;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public int getResolutionId() {
		return resolutionId;
	}

	public void setResolutionId(int resolutionId) {
		this.resolutionId = resolutionId;
	}

}
