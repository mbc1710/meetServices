package com.nielsen.retailer.config.api.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "rel_profile_reports")
@Table(name = "rel_profile_reports", schema = "mars_config")
public class RelProfileReports implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "profile_id")
	private int profileId;

	@Id
	@Column(name = "report_id")
	private int reportId;

	@Column(name = "create_dt")
	private Date createDt;

	public int getProfileId() {
		return profileId;
	}

	public void setProfileId(int profileId) {
		this.profileId = profileId;
	}

	public int getReportId() {
		return reportId;
	}

	public void setReportId(int reportId) {
		this.reportId = reportId;
	}

	public Date getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RelProfileReports [profileId=");
		builder.append(profileId);
		builder.append(", reportId=");
		builder.append(reportId);
		builder.append(", createDt=");
		builder.append(createDt);
		builder.append("]");
		return builder.toString();
	}

}
