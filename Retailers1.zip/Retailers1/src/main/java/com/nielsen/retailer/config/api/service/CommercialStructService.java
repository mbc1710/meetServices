package com.nielsen.retailer.config.api.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nielsen.retailer.config.api.dao.CommercialStructDao;
import com.nielsen.retailer.config.api.dao.CommercialStructHeaderRepository;
import com.nielsen.retailer.config.api.dao.CommercialStructRepository;
import com.nielsen.retailer.config.api.dao.impl.CommercialStructDetailDaoImpl;
import com.nielsen.retailer.config.api.dao.impl.JdbcDaoImpl;
import com.nielsen.retailer.config.api.domain.CommercialStruct;
import com.nielsen.retailer.config.api.domain.CommercialStructDetail;

@Service
public class CommercialStructService {

	@Autowired
	private CommercialStructRepository commercialStructRepository;

	@Autowired
	CommercialStructHeaderRepository cshr;

	@Autowired
	private CommercialStructDao commercialStructDao;

	@Autowired
	private CommercialStructDetailDaoImpl detailDaoImpl;

	@Autowired
	private JdbcDaoImpl jdbcDaoImpl;

	@Autowired
	private CommercialStructDetailService commercialStructDetailService;

	public List<CommercialStruct> getCommercialStructs(int serviceId) {
		return commercialStructDao.findByService(serviceId);
	}

	@Transactional
	public int create(CommercialStruct obj) throws Exception {

		CommercialStruct cs = commercialStructDao.findByRetailerId(obj.getRetailer().getRetailerId());
		if (cs != null) {
			throw new Exception("el retailer ya existe");
		}

		List<Object[]> objects = new ArrayList<>(0);
		obj.setCreateDt(new Timestamp((new Date()).getTime()));
		obj.setUpdateDt(new Timestamp((new Date()).getTime()));

		commercialStructRepository.save(obj);

		if (obj.getHeader() != null) {
			obj.getHeader().setCommercialStructId(obj.getCommercialStructId());
			cshr.save(obj.getHeader());
		}

		for (CommercialStructDetail item : obj.getDetails()) {
			item.setCommercialStructId(obj.getCommercialStructId());
			Object[] newObj = new Object[] { item.getCommercialStructId(), item.getFormatId(), item.getFormatNm(),
					item.getInfactNm(), item.getLevel1(), item.getLevel2(), item.getLevel3(), obj.isActive() };
			objects.add(newObj);
		}
		jdbcDaoImpl.InsertCommercialStrucDetail(objects);
		return 1;
	}

	public CommercialStruct getCommercialStructById(int commercialStructId) {
		CommercialStruct cs = commercialStructDao.findById(commercialStructId);
		if (cs != null) {
			cs.setDetails(detailDaoImpl.findByCommercialStructId(commercialStructId));
			cs.setHeader(cshr.findById(commercialStructId));
		}
		return cs;
	}

	public CommercialStruct getCommercialStructByIdWithOutDetail(int commercialStructId) {
		CommercialStruct cs = commercialStructDao.findById(commercialStructId);
		if (cs != null) {
			cs.setDetails(new ArrayList<>());
		}
		return cs;
	}

	public int update(CommercialStruct obj) {
		obj.setUpdateDt(new Timestamp((new Date()).getTime()));
		commercialStructRepository.save(obj);
		return 1;
	}

	
	public int updateCommercialStructStatus(CommercialStruct obj) {
		commercialStructDao.updateStatus(obj);
		return 1;
	}
	
	@Transactional
	public int updateFull(CommercialStruct obj) throws Exception {
		if(obj.getHeader() != null){
			obj.getHeader().setCommercialStructId(obj.getCommercialStructId());
			cshr.save(obj.getHeader());
		}
		
		commercialStructDetailService.updateCommercialStructDetail(obj.getCommercialStructId(), obj.getDetails());
		return 1;
	}
}
