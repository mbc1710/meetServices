package com.nielsen.retailer.config.api.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "rel_profile_values")
@Table(name = "rel_profile_values", schema = "mars_config")
public class RelProfileValue implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	
	@Id
	@Column(name = "value_id")
	private int valueId;

	@Id
	@Column(name = "profile_id")
	private int profileId;

	public int getValueId() {
		return valueId;
	}

	public void setValueId(int valueId) {
		this.valueId = valueId;
	}

	public int getProfileId() {
		return profileId;
	}

	public void setProfileId(int profileId) {
		this.profileId = profileId;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RelProfileReports [valueId=");
		builder.append(valueId);
		builder.append(", profileId=");
		builder.append(profileId);
		builder.append("]");
		return builder.toString();
	}


}
