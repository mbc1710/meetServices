package com.nielsen.retailer.config.api.dao.impl;

import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nielsen.retailer.config.api.dao.CatValueDao;
import com.nielsen.retailer.config.api.domain.CatValue;

@Repository
@Transactional(readOnly = true)
public class CatValueDaoImpl implements CatValueDao {

	@PersistenceContext
	EntityManager em;

	final static Logger logger = LoggerFactory.getLogger(CatValueDaoImpl.class);

	@Value("${datasource.schema}")
	private String schema;

	@SuppressWarnings("unchecked")
	@Override
	public List<CatValue> findAll(int serviceId, int reportId, int userId, Integer[] typeId) {
		
		String strQuery = "SELECT distinct "+ 
				  "v.report_id, "+
				  "v.service_id, "+
				  "v.tag_id, "+
				  "v.value_external, "+
				  "v.value_id, "+
				  "(CASE WHEN tl.text_value IS NULL THEN v.value_nm ELSE tl.text_value END) value_nm, "+
				  " v.value_type_id "+
				"FROM "+ schema +".cat_values v "+
				  "JOIN "+ schema +".rel_profile_values pv on (v.value_id = pv.value_id) "+
				  "JOIN "+ schema +".rel_user_profiles up on (pv.profile_id =  up.profile_id) "+
				  "JOIN "+ schema +".cat_profiles p on (up.profile_id = p.profile_id and v.service_id = p.service_id) "+
				  "LEFT JOIN "+ schema +".rel_tag_languages tl on (v.tag_id = tl.tag_id AND tl.language_id = 1) "+
				"WHERE "+
				  "p.is_active = true "+
				  "AND v.value_type_id IN ( " + (Arrays.toString(typeId).replace("[", "").replace("]", "")) + " ) " +
				  "AND v.service_id = (:serviceId) "+
				  "AND v.report_id = (:reportId) "+
				  "AND up.user_id = (:userId) " +
				  "ORDER BY v.value_id";
		//strQuery.replace(":valueTypes", Arrays.toString(typeId).replaceAll("[", "").replace("]", ""));
		Query query = em.createNativeQuery(strQuery, CatValue.class);
		query.setParameter("serviceId", serviceId);
		query.setParameter("reportId", reportId);
		query.setParameter("userId", userId);
		return query.getResultList();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<CatValue> findByReportAndService(int reportId, int serviceId, int languageId) {
		String strQuery = "SELECT v.report_id, v.service_id, v.tag_id, v.value_external, v.value_id, " +
				  "(CASE WHEN tl.text_value IS NULL THEN v.value_nm ELSE tl.text_value END) value_nm, v.value_type_id " +
				  "FROM "+ schema +".cat_values v "+
				  "LEFT JOIN "+ schema +".rel_tag_languages tl on (v.tag_id = tl.tag_id AND tl.language_id = :languageId) "+
				  "WHERE v.service_id = (:serviceId) "+
				  "AND v.report_id = (:reportId) " +
				  "ORDER BY v.value_id";
		Query query = em.createNativeQuery(strQuery, CatValue.class);
		query.setParameter("serviceId", serviceId);
		query.setParameter("reportId", reportId);
		query.setParameter("languageId", languageId);
		return query.getResultList();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<CatValue> findByProfile(int profileId) {
		// TODO Auto-generated method stub
		String strQuery = "SELECT "+ 
				  "v.report_id, "+
				  "v.service_id, "+
				  "v.tag_id, "+
				  "v.value_external, "+
				  "v.value_id, "+
				  "(CASE WHEN tl.text_value IS NULL THEN v.value_nm ELSE tl.text_value END) value_nm, "+
				  " v.value_type_id "+
				"FROM "+ schema +".cat_values v "+
				  "JOIN "+ schema +".rel_profile_values pv on (v.value_id = pv.value_id) "+
				  "LEFT JOIN "+ schema +".rel_tag_languages tl on (v.tag_id = tl.tag_id AND tl.language_id = 1) "+
				"WHERE pv.profile_id = (:profileId) " +
				"ORDER BY v.value_id";
		//strQuery.replace(":valueTypes", Arrays.toString(typeId).replaceAll("[", "").replace("]", ""));
		Query query = em.createNativeQuery(strQuery, CatValue.class);
		query.setParameter("profileId", profileId);
		return query.getResultList();
	}
	
	
	@SuppressWarnings("unchecked")
	public List<CatValue> findFactsAndPeriods(int serviceId, int userId, int reportId, int languageId, Integer[] typesId) {
		// TODO Auto-generated method stub
		String strQuery = " SELECT distinct "
					+ " v.report_id, "
					+ " v.service_id, "
					+ " v.tag_id, "
					+ " v.value_external, "
					+ " v.value_id, "
					+ " (CASE WHEN tl.text_value IS NULL THEN v.value_nm ELSE tl.text_value END) value_nm, "
					+ " v.value_type_id "
					+ " FROM "+ schema +".cat_values v "
					+ " JOIN "+ schema +".rel_profile_values pv on (v.value_id = pv.value_id) "
					+ " JOIN "+ schema +".rel_user_profiles up on (pv.profile_id =  up.profile_id) "
					+ " JOIN "+ schema +".cat_profiles p on (up.profile_id = p.profile_id and v.service_id = p.service_id) "
					+ " LEFT JOIN "+ schema +".rel_tag_languages tl on (v.tag_id = tl.tag_id AND tl.language_id = (:languageId)) "
					+ " WHERE p.is_active = true "
					+ " AND v.value_type_id IN ( " + (Arrays.toString(typesId).replace("[", "").replace("]", "")) + " ) "
					+ " AND v.service_id = (:serviceId) "
					+ " AND v.report_id = (:reportId) "
					+ " AND up.user_id = (:userId) ";
		Query query = em.createNativeQuery(strQuery, CatValue.class);
		query.setParameter("serviceId", serviceId);
		query.setParameter("userId", userId);
		query.setParameter("reportId", reportId);
		query.setParameter("languageId", languageId);
		return query.getResultList();
		
	}
	
	
	
}
