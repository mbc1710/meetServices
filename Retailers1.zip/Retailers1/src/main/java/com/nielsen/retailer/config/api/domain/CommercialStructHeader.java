package com.nielsen.retailer.config.api.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity(name = "cat_commercial_struct_headers")
@Table(name = "cat_commercial_struct_headers", schema = "mars_config")
public class CommercialStructHeader implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@NotNull
	@Column(name = "commercial_struct_id")
	private int commercialStructId;

	@Column(name = "level_1_nm")
	private String levelOneNm;

	@Column(name = "level_2_nm")
	private String levelTwoNm;

	@Column(name = "level_3_nm")
	@NotNull
	private String levelThreeNm;

	public CommercialStructHeader() {
	}

	public int getCommercialStructId() {
		return commercialStructId;
	}

	public void setCommercialStructId(int commercialStructId) {
		this.commercialStructId = commercialStructId;
	}

	public String getLevelOneNm() {
		return levelOneNm;
	}

	public void setLevelOneNm(String levelOneNm) {
		this.levelOneNm = levelOneNm;
	}

	public String getLevelTwoNm() {
		return levelTwoNm;
	}

	public void setLevelTwoNm(String levelTwoNm) {
		this.levelTwoNm = levelTwoNm;
	}

	public String getLevelThreeNm() {
		return levelThreeNm;
	}

	public void setLevelThreeNm(String levelThreeNm) {
		this.levelThreeNm = levelThreeNm;
	}

}
