package com.nielsen.retailer.config.api.dao.impl;

import java.util.Date;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.Query;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nielsen.retailer.config.api.dao.ServiceByCountryDao;
import com.nielsen.retailer.config.api.domain.ServiceByCountry;

@Service
public class ServiceByCountryDaoImpl implements ServiceByCountryDao {

	@PersistenceContext
	private EntityManager em;

	@Override
	public List<ServiceByCountry> findAll() {
		TypedQuery<ServiceByCountry> query = em.createQuery("SELECT s FROM cat_services s, cat_countries c "
				+ "where s.country = c.countryId and c.active = true order by s.serviceNm", ServiceByCountry.class);
		List<ServiceByCountry> res = query.getResultList();
		return res;
	}

	@Override
	public List<ServiceByCountry> findByCountry(int countryId) {
		TypedQuery<ServiceByCountry> query = em.createQuery(
				"SELECT s FROM cat_services s where s.country.countryId = :countryId and s.active = true " , ServiceByCountry.class);
		query.setParameter("countryId", countryId);
		List<ServiceByCountry> res = query.getResultList();
		return res;
	}

	@Override
	public List<ServiceByCountry> findByCountryUser(int countryId, int userId, int reportId) {
		TypedQuery<ServiceByCountry> query = em.createQuery(
				  " select distinct cs "
				+ "from cat_services cs, "
				+ " cat_countries cc, "
				+ " cat_profiles cp, "
			    + " rel_user_profiles rup, "
			    + " rel_profile_reports rpr, "
			    + " cat_retailers cr, "
			    + " cat_commercial_structs ccs  "
				+ " where cc.active = true and cs.active = true and cp.active = true "
				+ " and cr.active = true and ccs.active = true "
				+ " and cs.country = cc.countryId "
				+ " and cs.serviceId = cp.service and cp.profileId = rup.profileId "
				+ " and cp.profileId = rpr.profileId and cs.serviceId = cr.serviceId "
				+ " and cr.retailerId = ccs.retailer "
				+ " and cc.countryId = :countryId "
				+ " and rup.userId = :userId "
				+ " and rpr.reportId = :reportId "
					, ServiceByCountry.class);
		query.setParameter("countryId", countryId);
		query.setParameter("userId", userId);
		query.setParameter("reportId", reportId);
		List<ServiceByCountry> res = query.getResultList();
		return res;
	}
	
	@Override
	public ServiceByCountry findById(int id) {
		TypedQuery<ServiceByCountry> query = em.createQuery("SELECT s FROM cat_services s WHERE serviceId = :serviceId",
				ServiceByCountry.class);
		query.setParameter("serviceId", id);
		List<ServiceByCountry> list = query.getResultList();

		return (list == null || list.size() == 0) ? null : list.get(0);
	}

	@Override
	@Transactional(readOnly = false)
	public int update(ServiceByCountry obj) {
		obj.setUpdateDt(new Timestamp((new Date()).getTime()));
		em.merge(obj);
		return 1;
	}
	
	@Override
	@Transactional(readOnly = false)
	public int updateStatus(ServiceByCountry obj) {
		
		Boolean active = obj.isActive();
		int serviceId = obj.getServiceId();
	
		Query query = em.createQuery("UPDATE cat_services SET active = :active WHERE serviceId = :serviceId");
		query.setParameter("active", active);
		query.setParameter("serviceId", serviceId);
		em.flush();
		return query.executeUpdate();
	}

	@Override
	@Transactional(readOnly = false)
	public int create(ServiceByCountry obj) {
		obj.setCreateDt(new Timestamp((new Date()).getTime()));
		obj.setUpdateDt(new Timestamp((new Date()).getTime()));
		obj.setActive(true);
		em.persist(obj);
		return 1;
	}

	@Override
	@Transactional(readOnly = false)
	public int delete(ServiceByCountry obj) {
		Query query = em.createQuery("DELETE FROM cat_services WHERE service_id = :service_id");
		query.setParameter("service_id", obj.getServiceId());
		return query.executeUpdate();
	}

	@Override
	public List<ServiceByCountry> findAllIsActive() {
		TypedQuery<ServiceByCountry> query = em.createQuery("SELECT s FROM cat_services s where s.active = true  ", ServiceByCountry.class);
		List<ServiceByCountry> res = query.getResultList();
		return res;
	}

	
}
