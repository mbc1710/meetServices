package com.nielsen.retailer.config.api.dao;

import java.util.List;

import com.nielsen.retailer.config.api.domain.Retailer;

public interface RetailerDao {

	public List<Retailer> findByService(int serviceId);
	
	public List<Retailer> findByServiceIsActive(int serviceId);
	
	public Retailer findByExternalId(int serviceId, int retailerExternalId);

	public int updateAllByService(int serviceId);

	public int update(Retailer obj);
	
	public int updateStatus(Retailer obj);
	
	public List<Retailer> findByUser(int userId, int serviceId);

	List<Retailer> findByUserHyerarchy(int userId, int countryId);

}
