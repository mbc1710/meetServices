package com.nielsen.retailer.config.api.util;

public interface MessageService {
	public String getMessage(String id);
}
