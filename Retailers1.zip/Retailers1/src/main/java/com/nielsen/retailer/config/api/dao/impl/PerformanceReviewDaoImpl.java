package com.nielsen.retailer.config.api.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nielsen.retailer.config.api.dao.PerformanceReviewDao;
import com.nielsen.retailer.config.api.domain.Selected;

@Repository
@Transactional(readOnly = true)
public class PerformanceReviewDaoImpl implements PerformanceReviewDao {

	@PersistenceContext
	private EntityManager em;

	final static Logger logger = LoggerFactory.getLogger(PerformanceReviewDaoImpl.class);

	@Override
	public List<Selected> findValuesByTypeId(int serviceId, int userId, int reportId, int typeId) {

		TypedQuery<Object[]> query = em.createQuery(
				"SELECT DISTINCT cmsd.formatNm, cmsd.formatNm FROM cat_commercial_struct_details cmsd WHERE cmsd.commercialStructId = :commercialStructId ",
				Object[].class);
		query.setParameter("serviceId", serviceId);
		query.setParameter("userId", userId);
		query.setParameter("reportId", reportId);
		query.setParameter("typeId", typeId);

		List<Object[]> results = query.getResultList();
		List<Selected> selects = new ArrayList<>();

		results.stream().forEach((record) -> {
			Selected s = new Selected();
			s.setLevel((record[1] == null ? "" : (String) record[1]));
			s.setLeveldown((record[1] == null ? "" :(String) record[0]));
			selects.add(s);
		});

		return selects;
	}

}
