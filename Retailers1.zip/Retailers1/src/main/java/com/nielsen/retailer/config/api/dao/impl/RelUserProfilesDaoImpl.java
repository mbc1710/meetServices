package com.nielsen.retailer.config.api.dao.impl;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nielsen.retailer.config.api.dao.RelUserProfilesDao;
import com.nielsen.retailer.config.api.domain.RelUserProfiles;

@Service
public class RelUserProfilesDaoImpl implements RelUserProfilesDao {
	@PersistenceContext
	EntityManager em;

	final static Logger logger = LoggerFactory.getLogger(ProfileDaoImpl.class);

	@Override
	public List<RelUserProfiles> findAllByUser(int id) {
		TypedQuery<RelUserProfiles> query = em.createQuery("SELECT p FROM rel_user_profiles p WHERE user_id = :user_id",
				RelUserProfiles.class);
		query.setParameter("user_id", id);
		return query.getResultList();
	}

	@Override
	public RelUserProfiles findById(int userId, int prfileId) {
		TypedQuery<RelUserProfiles> query = em.createQuery(
				"SELECT p FROM rel_user_profiles p WHERE profile_id = :profile_id AND user_id = :user_id",
				RelUserProfiles.class);
		query.setParameter("user_id", userId);
		query.setParameter("profile_id", prfileId);
		List<RelUserProfiles> list = query.getResultList();

		return (list == null || list.size() == 0) ? null : list.get(0);
	}

	@Override
	@Transactional(readOnly = false)
	public int create(RelUserProfiles obj) {
		obj.setCreateDt(new Timestamp((new Date()).getTime()));
		em.persist(obj);

		return 1;
	}

	@Override
	@Transactional(readOnly = false)
	public int delete(RelUserProfiles obj) {
		Query query = em.createQuery("DELETE FROM rel_user_profiles WHERE profile_id = :profile_id AND user_id = :user_id");
		query.setParameter("user_id", obj.getProfileId());
		query.setParameter("profile_id", obj.getProfileId());
		return query.executeUpdate();
	}

	@Override
	public int deleteAllByUser(int id) {
		Query query = em.createQuery("DELETE FROM rel_user_profiles r");
		//query.setParameter("user_id", id);
		return query.executeUpdate();
	}
}
