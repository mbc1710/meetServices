package com.nielsen.retailer.config.api.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nielsen.retailer.config.api.domain.Language;
import com.nielsen.retailer.config.api.dao.LanguageRepository;

@Service
public class LanguageService {

	@Autowired
	private LanguageRepository languageDao;

	public List<Language> getAllLanguage() {
		List<Language> list = languageDao.selectAll();

		return list;

	}

}
