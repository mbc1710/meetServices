package com.nielsen.retailer.config.api.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nielsen.retailer.config.api.dao.RetailerDao;
import com.nielsen.retailer.config.api.domain.Retailer;

@Repository
@Transactional(readOnly = true)
public class RetailerDaoImpl implements RetailerDao {

	@PersistenceContext
	EntityManager em;
	
	@Value("${datasource.schema}")
	private String schema;

	final static Logger logger = LoggerFactory.getLogger(RetailerDaoImpl.class);

	public List<Retailer> findByService(int serviceId) {
		TypedQuery<Retailer> query = em.createQuery("SELECT r FROM cat_retailers r WHERE r.serviceId =:serviceId order by id",
				Retailer.class);
		query.setParameter("serviceId", serviceId);
		return query.getResultList();
	}

	public List<Retailer> findByServiceIsActive(int serviceId) {
		TypedQuery<Retailer> query = em.createQuery("SELECT r FROM cat_retailers r WHERE r.serviceId =:serviceId and active = true order by id",
				Retailer.class);
		query.setParameter("serviceId", serviceId);
		return query.getResultList();
	}

	
	public Retailer findByExternalId(int serviceId, int retailerExternalId) {
		TypedQuery<Retailer> query = em.createQuery(
				"SELECT r FROM cat_retailers r WHERE r.serviceId =:serviceId AND r.retailerExternalId = :retailerExternalId order by id",
				Retailer.class);
		query.setParameter("serviceId", serviceId);
		query.setParameter("retailerExternalId", retailerExternalId);
		List<Retailer> list = query.getResultList();

		return (list == null || list.size() == 0) ? null : list.get(0);
	}

	@Override
	@Transactional(readOnly = false)
	public int updateAllByService(int serviceId) {
		Query query = em.createQuery("UPDATE cat_retailers SET active = false WHERE serviceId = :serviceId");
		query.setParameter("serviceId", serviceId);
		em.flush();
		return query.executeUpdate();

	}

	@Override
	@Transactional(readOnly = false)
	public int update(Retailer obj) {
		em.merge(obj);
		return 1;
	}
	
	@Override
	@Transactional(readOnly = false)
	public int updateStatus(Retailer obj) {
		
		Boolean active = obj.isActive();
		int retailerId = obj.getRetailerId();
	
		Query query = em.createQuery("UPDATE cat_retailers SET active = :active WHERE retailerId = :retailerId");
		query.setParameter("active", active);
		query.setParameter("retailerId", retailerId);
		em.flush();
		return query.executeUpdate();
	}

	@Override
	public List<Retailer> findByUser(int userId, int serviceId) {
		TypedQuery<Retailer> query = em.createQuery(
				"SELECT Distinct cr FROM cat_retailers cr,"
				+ " cat_services cs, "
				+ " cat_countries cc, "
		    	+ " rel_profile_retailers pr, "
		    	+ " rel_user_profiles up, "
		    	+ " cat_commercial_structs ccs "
			    + " WHERE cr.serviceId = cs.serviceId "
			    + " AND cr.retailerId = pr.retailerId "
			    + " AND pr.profileId = up.profileId "
			    + " AND cs.country = cc.countryId"
			    + " AND up.userId = :userId "
			    + " AND cs.serviceId = :serviceId "
			    + " AND ccs.retailer.retailerId = cr.retailerId "
			    + " AND cr.active = true  order by 1",
				Retailer.class);
		query.setParameter("userId",userId);
		query.setParameter("serviceId",serviceId);
		
		return query.getResultList();
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Retailer> findByUserHyerarchy (int userId, int countryId) {
		
		String strQuery = "SELECT Distinct cr.* "
				+ " FROM "+ schema +".cat_retailers cr "
				+ " inner join "+ schema +".cat_services cs on (cr.service_id = cs.service_id ) "
				+ " inner join "+ schema +".cat_countries cc on (cs.country_id = cc.country_id and cc.country_id = :countryId ) "
				+ " inner join "+ schema +".rel_profile_retailers pr on (cr.retailer_id = pr.retailer_id) "
				+ " inner join "+ schema +".rel_user_profiles up on (pr.profile_id = up.profile_id and up.user_id = :userId) "
				+ " inner join "+ schema +".cat_commercial_structs ccs on (ccs.retailer_id = cr.retailer_id ) "
				+ " inner join "+ schema +".dim_product_hierarchy ph on (ccs.commercial_struct_id = ph.prod_hier_id) "
				+ " where cr.is_active = true order by cr.retailer_nm asc ";
		Query query = em.createNativeQuery(strQuery, Retailer.class);
		query.setParameter("userId", userId);
		query.setParameter("countryId", countryId);
		return query.getResultList();
	}
	
}
