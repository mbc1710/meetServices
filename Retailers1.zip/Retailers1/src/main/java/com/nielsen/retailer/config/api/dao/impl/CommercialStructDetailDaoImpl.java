package com.nielsen.retailer.config.api.dao.impl;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nielsen.retailer.config.api.dao.CommercialStructDetailDao;
import com.nielsen.retailer.config.api.domain.CommercialStructDetail;
import com.nielsen.retailer.config.api.domain.Selected;

@Repository
@Transactional(readOnly = true)
public class CommercialStructDetailDaoImpl implements CommercialStructDetailDao {

	@PersistenceContext
	EntityManager em;

	final static Logger logger = LoggerFactory.getLogger(CommercialStructDetail.class);

	@Override
	@Transactional(readOnly = false)
	public int update(CommercialStructDetail obj) {
		em.merge(obj);
		return 1;
	}

	@Override
	@Transactional(readOnly = false)
	public int deleteByCommercialStructId(int commercialStructId) {
		Query query = em.createQuery(
				"DELETE FROM cat_commercial_struct_details WHERE commercialStructId = :commercialStructId");
		query.setParameter("commercialStructId", commercialStructId);
		query.executeUpdate();
		return 1;
	}

	@Override
	public List<CommercialStructDetail> findByCommercialStructId(int commercialStructId) {
		TypedQuery<CommercialStructDetail> query = em.createQuery(
				"SELECT cmsd FROM cat_commercial_struct_details cmsd WHERE commercialStructId = :commercialStructId order by id",
				CommercialStructDetail.class);
		query.setParameter("commercialStructId", commercialStructId);
		return query.getResultList();
	}

	@Override
	public CommercialStructDetail findByCommercialStructIdAndFormatId(int commercialStructId, int formatId) {
		TypedQuery<CommercialStructDetail> query = em.createQuery(
				"SELECT cmsd FROM cat_commercial_struct_details cmsd WHERE commercialStructId = :commercialStructId AND formatId = :formatId",
				CommercialStructDetail.class);
		query.setParameter("commercialStructId", commercialStructId);
		query.setParameter("formatId", formatId);
		List<CommercialStructDetail> list = query.getResultList();

		return (list == null || list.size() == 0) ? null : list.get(0);
	}

	@Override
	@Transactional(readOnly = false)
	public int updateAllByCommercialStructId(int commercialStructId) {
		Query query = em.createQuery(
				"UPDATE cat_commercial_struct_details SET active = false WHERE commercialStructId = :commercialStructId");
		query.setParameter("commercialStructId", commercialStructId);
		em.flush();
		return query.executeUpdate();

	}

	@Override
	@Transactional(readOnly = false)
	public int create(CommercialStructDetail obj) {
		em.persist(obj);
		return 0;
	}

	@Override
	public List<Selected> findByLevel4(int commercialStructId, int retailerId, int reportId, int userId) {
		TypedQuery<Object[]> query = em.createQuery(
				"SELECT DISTINCT CMSD.formatNm, CMSD.formatNm "
				+ " FROM cat_commercial_struct_details CMSD, "
				+ " cat_commercial_structs CS, "
				+ " rel_profile_retailers RPR, "
				+ " rel_user_profiles RUP, "
				+ " rel_profile_reports RPRS "
				+ " WHERE CMSD.commercialStructId = CS.commercialStructId "
				+ " AND CMSD.active = true "
				+ " AND CS.retailer = RPR.retailerId " 
				+ " AND RPR.profileId = RUP.profileId "
				+ " AND RUP.profileId = RPRS.profileId "
				+ " AND CMSD.commercialStructId = :commercialStructId "
				+ " AND CS.retailer.retailerId = :retailerId "
				+ " AND RPRS.reportId = :reportId "
				+ " AND RUP.userId = :userId",
				Object[].class);
		query.setParameter("commercialStructId", commercialStructId);
		query.setParameter("retailerId", retailerId);
		query.setParameter("reportId", reportId);
		query.setParameter("userId", userId);

		List<Object[]> results = query.getResultList();
		List<Selected> selects = new ArrayList<>();
		for (Object[] result : results) {
			Selected s = new Selected();
			s.setLevel((String) result[1]);
			s.setLeveldown((String) result[0]);
			selects.add(s);
		}
		return selects;
	}

	@Override
	public List<Selected> findByLevel3(int commercialStructId, int retailerId, int reportId, int userId) {
		TypedQuery<Object[]> query = em.createQuery(
				"SELECT DISTINCT CMSD.formatNm, CMSD.level3 "
						+ " FROM cat_commercial_struct_details CMSD, "
						+ " cat_commercial_structs CS, "
						+ " rel_profile_retailers RPR, "
						+ " rel_user_profiles RUP, "
						+ " rel_profile_reports RPRS "
						+ " WHERE CMSD.commercialStructId = CS.commercialStructId "
						+ " AND CMSD.active = true "
						+ " AND CS.retailer = RPR.retailerId " 
						+ " AND RPR.profileId = RUP.profileId "
						+ " AND RUP.profileId = RPRS.profileId "
						+ " AND CMSD.commercialStructId = :commercialStructId "
						+ " AND CS.retailer.retailerId = :retailerId "
						+ " AND RPRS.reportId = :reportId "
						+ " AND RUP.userId = :userId",
				Object[].class);
		query.setParameter("commercialStructId", commercialStructId);
		query.setParameter("retailerId", retailerId);
		query.setParameter("reportId", reportId);
		query.setParameter("userId", userId);
		
		List<Object[]> results = query.getResultList();
		List<Selected> selects = new ArrayList<>();
		for (Object[] result : results) {
			Selected s = new Selected();
			s.setLevel((String) result[1]);
			s.setLeveldown((String) result[0]);
			selects.add(s);
		}
		return selects;
	}

	@Override
	public List<Selected> findByLevel2(int commercialStructId, int retailerId, int reportId, int userId) {
		TypedQuery<Object[]> query = em.createQuery(
				"SELECT DISTINCT CMSD.level3, CMSD.level2 "
						+ " FROM cat_commercial_struct_details CMSD, "
						+ " cat_commercial_structs CS, "
						+ " rel_profile_retailers RPR, "
						+ " rel_user_profiles RUP, "
						+ " rel_profile_reports RPRS "
						+ " WHERE CMSD.commercialStructId = CS.commercialStructId "
						+ " AND CMSD.active = true "
						+ " AND CS.retailer = RPR.retailerId " 
						+ " AND RPR.profileId = RUP.profileId "
						+ " AND RUP.profileId = RPRS.profileId "
						+ " AND CMSD.commercialStructId = :commercialStructId "
						+ " AND CS.retailer.retailerId = :retailerId "
						+ " AND RPRS.reportId = :reportId "
						+ " AND RUP.userId = :userId",
				Object[].class);
		query.setParameter("commercialStructId", commercialStructId);
		query.setParameter("retailerId", retailerId);
		query.setParameter("reportId", reportId);
		query.setParameter("userId", userId);

		List<Object[]> results = query.getResultList();
		List<Selected> selects = new ArrayList<>();
		for (Object[] result : results) {
			Selected s = new Selected();
			s.setLevel((String) result[1]);
			s.setLeveldown((String) result[0]);
			selects.add(s);
		}
		return selects;
	}

	@Override
	public List<Selected> findByLevel1(int commercialStructId, int retailerId, int reportId, int userId) {
		TypedQuery<Object[]> query = em.createQuery(
				"SELECT DISTINCT CMSD.level2, CMSD.level1 "
						+ " FROM cat_commercial_struct_details CMSD, "
						+ " cat_commercial_structs CS, "
						+ " rel_profile_retailers RPR, "
						+ " rel_user_profiles RUP, "
						+ " rel_profile_reports RPRS "
						+ " WHERE CMSD.commercialStructId = CS.commercialStructId "
						+ " AND CMSD.active = true "
						+ " AND CS.retailer = RPR.retailerId " 
						+ " AND RPR.profileId = RUP.profileId "
						+ " AND RUP.profileId = RPRS.profileId "
						+ " AND CMSD.commercialStructId = :commercialStructId "
						+ " AND CS.retailer.retailerId = :retailerId "
						+ " AND RPRS.reportId = :reportId "
						+ " AND RUP.userId = :userId",
				Object[].class);
		query.setParameter("commercialStructId", commercialStructId);
		query.setParameter("retailerId", retailerId);
		query.setParameter("reportId", reportId);
		query.setParameter("userId", userId);
		
		List<Object[]> results = query.getResultList();
		List<Selected> selects = new ArrayList<>();
		for (Object[] result : results) {
			Selected s = new Selected();
			s.setLevel((String) result[1]);
			s.setLeveldown((String) result[0]);
			selects.add(s);
		}
		return selects;
	}
	
	
	@Override
	public List<CommercialStructDetail> findByCommercialStructCat( int reportId,int retailerId, int userId) {
		TypedQuery<CommercialStructDetail> query = em.createQuery(
				"SELECT DISTINCT CMSD"
						+ " FROM cat_commercial_struct_details CMSD, "
						+ " cat_commercial_structs CS, "
						+ " rel_profile_retailers RPR, "
						+ " rel_user_profiles RUP, "
						+ " rel_profile_reports RPRS "
						+ " WHERE CMSD.commercialStructId = CS.commercialStructId "
						+ " AND CMSD.active = true "
						+ " AND CS.retailer = RPR.retailerId " 
						+ " AND RPR.profileId = RUP.profileId "
						+ " AND RUP.profileId = RPRS.profileId "
						+ " AND CS.retailer.retailerId = :retailerId "
						+ " AND RPRS.reportId = :reportId "
						+ " AND RUP.userId = :userId",
						CommercialStructDetail.class);
		query.setParameter("retailerId", retailerId);
		query.setParameter("reportId", reportId);
		query.setParameter("userId", userId);
		return query.getResultList();
	}

}
