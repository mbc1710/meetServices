package com.nielsen.retailer.config.api.domain;

public class FileRetailer {
	private String retailerNm;
	private int retailerExternalId;

	public FileRetailer() {
	}

	public String getRetailerNm() {
		return retailerNm;
	}

	public void setRetailerNm(String retailerNm) {
		this.retailerNm = retailerNm;
	}

	public int getRetailerExternalId() {
		return retailerExternalId;
	}

	public void setRetailerExternalId(int retailerExternalId) {
		this.retailerExternalId = retailerExternalId;
	}

}
