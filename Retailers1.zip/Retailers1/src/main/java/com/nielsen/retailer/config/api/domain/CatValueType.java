package com.nielsen.retailer.config.api.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "cat_value_types")
@Table(name = "cat_value_types", schema = "mars_config")
public class CatValueType implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "value_type_id")
	private int valueTypeId;

	@Id
	@Column(name = "value_type_nm")
	private String valueTypeNm;

	@Column(name = "is_active")
	private boolean active;

	public CatValueType() {
	}

}