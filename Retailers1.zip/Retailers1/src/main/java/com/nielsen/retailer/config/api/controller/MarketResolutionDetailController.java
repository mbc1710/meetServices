package com.nielsen.retailer.config.api.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.nielsen.retailer.commons.api.utils.Response;
import com.nielsen.retailer.config.api.domain.MarketResolutionDetail;
import com.nielsen.retailer.config.api.service.MarketResolutionDetailService;
import com.nielsen.retailer.config.api.util.MessageService;

import ch.qos.logback.classic.BasicConfigurator;

@CrossOrigin
@RestController
@RequestMapping(value = "/retailer-config-api")
public class MarketResolutionDetailController {

	final static Logger logger = LoggerFactory.getLogger(BasicConfigurator.class);

	@Autowired
	private MarketResolutionDetailService marketResolutionDetailService;

	@Autowired
	private MessageService messageSource;

	@RequestMapping(value = { "/market-resolution-detail/{resolutionId}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<MarketResolutionDetail>>> getMarketResolutionDetail(
			@PathVariable(name = "resolutionId", required = true) int resolutionId) {

		List<MarketResolutionDetail> list = marketResolutionDetailService.getMarketByResolutionId(resolutionId);
		Response<List<MarketResolutionDetail>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.marketResolutionDetail.messages.1000");
		}

		response = new Response<List<MarketResolutionDetail>>(list, msg);
		return new ResponseEntity<Response<List<MarketResolutionDetail>>>(response,
				HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/market-resolution-detail-is-active/{resolutionId}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<MarketResolutionDetail>>> getMarketResolutionDetailIsActive(
			@PathVariable(name = "resolutionId", required = true) int resolutionId) {

		List<MarketResolutionDetail> list = marketResolutionDetailService.getMarketByResolutionIdIsActive(resolutionId);
		Response<List<MarketResolutionDetail>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.marketResolutionDetail.messages.1000");
		}

		response = new Response<List<MarketResolutionDetail>>(list, msg);
		return new ResponseEntity<Response<List<MarketResolutionDetail>>>(response,
				HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/market-resolution-details" }, method = { RequestMethod.POST })
	public @ResponseBody ResponseEntity<Response<List<MarketResolutionDetail>>> getMarketsResolutionsDetails(
			@RequestBody int[] resolutionId) {

		List<MarketResolutionDetail> list = marketResolutionDetailService.getMarketByResolutionId(resolutionId);
		Response<List<MarketResolutionDetail>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.marketResolutionDetail.messages.1001");
		} else {
			msg = messageSource.getMessage("api.marketResolutionDetail.messages.1002");
		}

		response = new Response<List<MarketResolutionDetail>>(list, msg);
		return new ResponseEntity<Response<List<MarketResolutionDetail>>>(response,
				HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/resolution-detail-by-user-profile-no-total/{userId}/{retailerId}/{countryId}" }, method = {
			RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<MarketResolutionDetail>>> getResolutionDetailByUserProfileNoTotal(
			@PathVariable(name = "userId", required = true) int userId,
			@PathVariable(name = "retailerId", required = true) int retailerId,
			@PathVariable(name = "countryId", required = true) int countryId) {
		
		System.out.println(userId + " " +retailerId+ " "+countryId);

		List<MarketResolutionDetail> list = marketResolutionDetailService.getMarketByUserProfileIdNoTotal(userId,retailerId,countryId);
		Response<List<MarketResolutionDetail>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.marketResolutionDetail.messages.1000");
		}

		response = new Response<List<MarketResolutionDetail>>(list, msg);
		return new ResponseEntity<Response<List<MarketResolutionDetail>>>(response,
				HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/resolution-detail-by-user-profile-is-total/{userId}/{serviceId}/{marketId}" }, method = {
			RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<MarketResolutionDetail>>> getResolutionDetailByUserProfileIsTotal(
			@PathVariable(name = "userId", required = true) int userId,
			@PathVariable(name = "serviceId", required = true) int serviceId,
			@PathVariable(name = "marketId", required = true) int marketId) {

		List<MarketResolutionDetail> list = marketResolutionDetailService.getMarketByUserProfileIdIsTotal(userId, serviceId, marketId);
		Response<List<MarketResolutionDetail>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.marketResolutionDetail.messages.1000");
		}

		response = new Response<List<MarketResolutionDetail>>(list, msg);
		return new ResponseEntity<Response<List<MarketResolutionDetail>>>(response,
				HttpStatus.valueOf(response.getStatus()));
	}
}
