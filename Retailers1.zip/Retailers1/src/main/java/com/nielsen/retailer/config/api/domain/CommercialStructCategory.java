package com.nielsen.retailer.config.api.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "cat_comm_struct_category")
@Table(name = "cat_comm_struct_category", schema = "mars_config")
public class CommercialStructCategory implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "category_id")
	private int categoryId;

	@Column(name = "commercial_struct_id")
	private int commercialStructId;

	@Column(name = "format_id")
	private int formatId;

	@Column(name = "format_desc")
	private String formatDesc;

	@Column(name = "retailer_id")
	private int retailerId;

	public CommercialStructCategory() {
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public int getCommercialStructId() {
		return commercialStructId;
	}

	public void setCommercialStructId(int commercialStructId) {
		this.commercialStructId = commercialStructId;
	}

	public int getFormatId() {
		return formatId;
	}

	public void setFormatId(int formatId) {
		this.formatId = formatId;
	}

	public String getFormatDesc() {
		return formatDesc;
	}

	public void setFormatDesc(String formatDesc) {
		this.formatDesc = formatDesc;
	}

	public int getRetailerId() {
		return retailerId;
	}

	public void setRetailerId(int retailerId) {
		this.retailerId = retailerId;
	}

}
