package com.nielsen.retailer.config.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.nielsen.retailer.commons.api.utils.Response;
import com.nielsen.retailer.config.api.domain.CommercialStructHeader;
import com.nielsen.retailer.config.api.service.CommercialStructHeaderService;
import com.nielsen.retailer.config.api.util.MessageService;

import ch.qos.logback.classic.BasicConfigurator;

@CrossOrigin
@RestController
@RequestMapping(value = "/retailer-config-api")
public class CommercialStructHeaderController {

	final static Logger logger = LoggerFactory.getLogger(BasicConfigurator.class);

	@Autowired
	private CommercialStructHeaderService commercialStructHeaderController;

	@Autowired
	private MessageService messageSource;

	@RequestMapping(value = { "/commercial-struct-header/{commercialStructId}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<CommercialStructHeader>> getCommercialStructHeaderById(
			@PathVariable(name = "commercialStructId", required = true) int commercialStructId) {

		final String msg = messageSource.getMessage("api.commercialStructHeader.messages.1000");
		CommercialStructHeader obj = commercialStructHeaderController.getById(commercialStructId);
		Response<CommercialStructHeader> response;

		if (obj == null) {
			response = new Response<CommercialStructHeader>(obj, msg);
		} else {
			response = new Response<CommercialStructHeader>(obj);
		}

		response = new Response<CommercialStructHeader>(obj, "");
		return new ResponseEntity<Response<CommercialStructHeader>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/commercial-struct-header" }, method = { RequestMethod.PUT })
	public @ResponseBody ResponseEntity<Response<Integer>> updateCommercialStruct(
			@RequestBody(required = true) CommercialStructHeader obj) {
		String msg = "";
		int result = commercialStructHeaderController.update(obj);

		Response<Integer> response;

		if (result != 1) {
			msg = messageSource.getMessage("api.commercialStructHeader.messages.1002");
		} else {
			msg = messageSource.getMessage("api.commercialStructHeader.messages.1006");
		}

		response = new Response<Integer>(result, msg);

		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@RequestMapping(value = { "/commercial-struct-header-by_retailer/{retailerId}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<CommercialStructHeader>> getCommercialStructHeaderByRetailerId(
			@PathVariable(name = "retailerId", required = true) int retailerId) {

		final String msg = messageSource.getMessage("api.commercialStructHeader.messages.1000");
		CommercialStructHeader obj = commercialStructHeaderController.getById(retailerId);
		Response<CommercialStructHeader> response;

		if (obj == null) {
			response = new Response<CommercialStructHeader>(obj, msg);
		} else {
			response = new Response<CommercialStructHeader>(obj);
		}

		response = new Response<CommercialStructHeader>(obj, "");
		return new ResponseEntity<Response<CommercialStructHeader>>(response, HttpStatus.valueOf(response.getStatus()));
	}

}
