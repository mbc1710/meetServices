package com.nielsen.retailer.config.api.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "rel_profile_retailers")
@Table(name = "rel_profile_retailers", schema = "mars_config")
public class RelProfileRetailer implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "profile_id")
	private int profileId;

	@Id
	@Column(name = "retailer_id")
	private int retailerId;

	public int getProfileId() {
		return profileId;
	}

	public void setProfileId(int profileId) {
		this.profileId = profileId;
	}

	public int getReailerId() {
		return retailerId;
	}

	public void setReailerId(int reailerId) {
		this.retailerId = reailerId;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RelProfileRetailer [profileId=");
		builder.append(profileId);
		builder.append(", reailerId=");
		builder.append(retailerId);
		builder.append("]");
		return builder.toString();
		
		
		
		
	}
}
