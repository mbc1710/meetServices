package com.nielsen.retailer.config.api.dao;

import java.util.List;

import com.nielsen.retailer.config.api.domain.User;

public interface UserDao {
	public List<User> findAll();

	public User findById(int id);

	public int update(User obj);
	
	public int updateStatus(User obj);

	public int create(User obj);

	public int delete(User id);

	public User findByEmail(String email);

}
