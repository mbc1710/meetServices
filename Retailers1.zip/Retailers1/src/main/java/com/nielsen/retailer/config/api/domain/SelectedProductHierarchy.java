package com.nielsen.retailer.config.api.domain;

import java.io.Serializable;

public class SelectedProductHierarchy implements Serializable {

	private static final long serialVersionUID = 1L;

	private String description;
	private String hierarchyCode;
	private int parentId;
	private int productId;

	public SelectedProductHierarchy() {
	}

	public SelectedProductHierarchy(String description, int parentId, int productId) {
		this.description = description;
		this.parentId = parentId;
		this.productId = productId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getParentId() {
		return parentId;
	}

	public void setParentId(int parentId) {
		this.parentId = parentId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getHierarchyCode() {
		return hierarchyCode;
	}

	public void setHierarchyCode(String hierarchyCode) {
		this.hierarchyCode = hierarchyCode;
	}

}
