package com.nielsen.retailer.config.api.dao;

import java.util.List;

import com.nielsen.retailer.config.api.domain.Country;

public interface CountryDao {

	public List<Country> findAll();
	
	public List<Country> findAllIsActive();
	
	public List<Country> findAllByUser(int userId, int reportId);

	public Country findById(int id);

	public int update(Country obj);
	
	public int updateStatus(Country obj);

	public int create(Country obj);

	public int delete(Country id);

}
