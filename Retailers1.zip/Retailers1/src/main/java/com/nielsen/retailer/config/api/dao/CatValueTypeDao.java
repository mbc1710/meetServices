package com.nielsen.retailer.config.api.dao;

import java.util.List;

import com.nielsen.retailer.config.api.domain.CatValueType;

public interface CatValueTypeDao {
	List<CatValueType> findAll();
}
