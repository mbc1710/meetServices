package com.nielsen.retailer.config.api.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nielsen.retailer.config.api.dao.CatValueDao;
import com.nielsen.retailer.config.api.dao.CommercialStructDetailRepository;
import com.nielsen.retailer.config.api.dao.MarketResolutionDao;
import com.nielsen.retailer.config.api.dao.MarketResolutionDetailDao;
import com.nielsen.retailer.config.api.dao.ProfileDao;
import com.nielsen.retailer.config.api.dao.ProfileRepository;
import com.nielsen.retailer.config.api.dao.ReportDao;
import com.nielsen.retailer.config.api.dao.RetailerRepository;
import com.nielsen.retailer.config.api.domain.MarketResolutionDetail;
import com.nielsen.retailer.config.api.domain.Profile;

@Service
public class ProfileService {

	@Autowired
	private ProfileDao profileDao;

	@Autowired
	private ReportDao reportDao;

	@Autowired
	private MarketResolutionDetailDao marketResolutionDetailDao;

	@Autowired
	private MarketResolutionDao marketResolutionDao;

	@Autowired
	private RetailerRepository retailerRepository;

	@Autowired
	private ProfileRepository profileDao2;
	
	@Autowired
	private CatValueDao catValueDao;
	
	@Autowired
	private CommercialStructDetailRepository commercialStructDetailRepository;

	public List<Profile> getProfiles() {
		return profileDao.findAll();
	}

	public List<Profile> getProfilesIsActive() {
		return profileDao.findAllActives();
	}

	public List<Profile> getProfilesByService(int serviceId) {
		return profileDao.findByServiceId(serviceId);
	}

	public Profile getProfileById(int id) {
		Profile profile = profileDao.findById(id);
		if (profile != null) {
			profile.setReports(reportDao.findByProfile(profile.getProfileId()));
			profile.setMarkets(marketResolutionDetailDao.findByProfileId(profile.getProfileId()));
			profile.setCommercialStructDetails( commercialStructDetailRepository.findByProfile( profile.getProfileId() ) );
			profile.setCatValues( catValueDao.findByProfile(profile.getProfileId()) );
			if (profile.getMarkets() != null && profile.getMarkets().size() > 0) {
				for (MarketResolutionDetail mrt : profile.getMarkets()) {
					mrt.setMarketResolution(marketResolutionDao.findById(mrt.getResolutionId()));
				}
			}
			profile.setRetailers(retailerRepository.findByProfile(profile.getProfileId()));
		}
		return profile;
	}

	public List<Profile> getProfileByUserId(int id) {
		return profileDao.findByUserId(id);
	}

	public int createProfile(Profile Profile) {
		return profileDao.create(Profile);
	}

	public int updateProfile(Profile Profile) {
		return profileDao.update(Profile);
	}

	public int updateProfileStatus(Profile profile) {
		return profileDao.updateStatus(profile);
	}

	public int deleteProfile(Profile Profile) {
		return profileDao.delete(Profile);
	}

	public List<Profile> getProfilesByServices(int[] servicesId) {
		return profileDao2.findByServiceId(servicesId);
	}

}
