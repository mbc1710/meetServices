package com.nielsen.retailer.config.api.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity(name = "cat_value_urls")
@Table(name = "cat_value_urls", schema = "mars_config")
@IdClass(CatValueUrlPK.class)
public class CatValueUrl implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@JoinColumn(name = "value_id")
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnore
	private CatValue objValue;

	@Id
	@Column(name = "url_tag")
	private String urlTag;

	@Column(name = "url")
	private String url;
	
	@Column(name = "group_id")
	private Integer groupId;
	
	public CatValue getObjValue() {
		return objValue;
	}

	public void setObjValue(CatValue objValue) {
		this.objValue = objValue;
	}

	public String getUrlTag() {
		return urlTag;
	}

	public void setUrlTag(String urlTag) {
		this.urlTag = urlTag;
	}

	@Override
	public String toString() {
		return "CatValueUrl [objValue=" + objValue + ", urlTag=" + urlTag + "]";
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Integer getGroupId() {
		return groupId;
	}

	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}

}

class CatValueUrlPK implements Serializable {

	private static final long serialVersionUID = 1L;

	private CatValue objValue;
	private String urlTag;

	public CatValueUrlPK() {
	}

	public CatValueUrlPK(CatValue objValue, String urlTag) {
		this.objValue = objValue;
		this.urlTag = urlTag;
	}

	public CatValue getObjValue() {
		return objValue;
	}

	public void setValueId(CatValue objValue) {
		this.objValue = objValue;
	}

	public String getUrlTag() {
		return urlTag;
	}

	public void setUrlTag(String urlTag) {
		this.urlTag = urlTag;
	}

	@Override
	public int hashCode() {
		String code = "" + this.objValue.getValueId() + "" + getUrlTag();
		return Integer.parseInt(code);
	}

	@Override
	public boolean equals(Object o) {
		boolean flag = false;
		CatValueUrl myId = (CatValueUrl) o;

		if ((o instanceof CatValueUrl) && (this.objValue.getValueId() == myId.getObjValue().getValueId())
				&& (this.getUrlTag() == myId.getUrlTag())) {
			flag = true;
		}
		return flag;
	}
}