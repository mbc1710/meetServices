package com.nielsen.retailer.config.api.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.nielsen.retailer.commons.api.utils.Response;
import com.nielsen.retailer.config.api.domain.Language;
import com.nielsen.retailer.config.api.service.LanguageService;
import com.nielsen.retailer.config.api.util.MessageService;

@CrossOrigin
@RestController
@RequestMapping(value = "/retailer-config-api")
public class LanguageController {

	@Autowired
	LanguageService languageService;
	
	@Autowired
	private MessageService messageSource;

	@RequestMapping(value = { "/language" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<Language>>> getAllLanguage() {
		
		List<Language> list = languageService.getAllLanguage();
		Response<List<Language>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.language.messages.1000");
		}

		response = new Response<List<Language>>(list, msg);
		return new ResponseEntity<Response<List<Language>>>(response, HttpStatus.valueOf(response.getStatus()));
	}

}
