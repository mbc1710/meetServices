package com.nielsen.retailer.config.api.domain;

import java.io.Serializable;
import java.util.List;

public class RptCommercialStrunct implements Serializable {
	private static final long serialVersionUID = 1L;
	private String description;
	private List<Selected> detail;

	public RptCommercialStrunct() {
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<Selected> getDetail() {
		return detail;
	}

	public void setDetail(List<Selected> detail) {
		this.detail = detail;
	}

}
