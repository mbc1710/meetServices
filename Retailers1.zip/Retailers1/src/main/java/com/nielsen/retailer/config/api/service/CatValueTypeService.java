package com.nielsen.retailer.config.api.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nielsen.retailer.config.api.dao.CatValueTypeDao;
import com.nielsen.retailer.config.api.domain.CatValueType;

@Service
public class CatValueTypeService {

	@Autowired
	private CatValueTypeDao catValueTypeDao;

	public List<CatValueType> getAll() {
		return this.catValueTypeDao.findAll();
	}

}
