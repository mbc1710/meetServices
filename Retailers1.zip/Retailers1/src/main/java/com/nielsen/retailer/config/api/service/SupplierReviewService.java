package com.nielsen.retailer.config.api.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nielsen.retailer.config.api.dao.CatValueDao;
import com.nielsen.retailer.config.api.dao.ProductHierarchyDao;
import com.nielsen.retailer.config.api.dao.impl.JdbcDaoImpl;
import com.nielsen.retailer.config.api.dao.impl.JdbcImpalaDaoImpl;
import com.nielsen.retailer.config.api.domain.CatValue;
import com.nielsen.retailer.config.api.domain.EnumHierarchyCodeOfImpala;
import com.nielsen.retailer.config.api.domain.EnumParameterTypeOfImpala;
import com.nielsen.retailer.config.api.domain.SelectedProductHierarchy;

@Service
public class SupplierReviewService {

	@Autowired
	private JdbcDaoImpl jdbcDaoImpl;

	@Autowired
	private JdbcImpalaDaoImpl jdbcImpalaDaoImpl;

	@Autowired
	private ProductHierarchyDao productHierarchyDao;

	@Autowired
	private CatValueDao catValueDao;

	public int saveManufacturersWithCategoryToImpala(List<Object> parameters) {
		List<Object[]> listParameters = new ArrayList<>();

		parameters.stream().forEach((record) -> {
			if (parameters instanceof SelectedProductHierarchy) {
				Object[] parameter = new Object[] { EnumParameterTypeOfImpala.Manufacturer.getId(),
						((SelectedProductHierarchy) record).getProductId() };
				listParameters.add(parameter);
			}
		});

		int selectionId = jdbcDaoImpl.nextSelectionId();

		jdbcImpalaDaoImpl.saveParameterToImpala(selectionId, listParameters);
						
		 return selectionId;
		
	}

	public List<Integer> saveManufacturersWithoutCategoryToImpala(int serviceId, int retailerId,
			List<SelectedProductHierarchy> parameters, int reportId) throws Exception {

		List<String> descriptions = new ArrayList<String>();
		List<Object[]> listParameters = new ArrayList<>();
		List<Object[]> listParametersTMSB = new ArrayList<>();
		List<Integer> result = new ArrayList<Integer>();

		parameters.stream().forEach((record) -> {
			if (record instanceof SelectedProductHierarchy) {
				Object[] parameter = new Object[] { EnumParameterTypeOfImpala.Manufacturer.getId(),
						((SelectedProductHierarchy) record).getProductId() };
				descriptions.add(((SelectedProductHierarchy) record).getDescription());
				listParameters.add(parameter);
			}
		});

		List<SelectedProductHierarchy> listTMSB = productHierarchyDao.getByDescriptions(serviceId,
				EnumHierarchyCodeOfImpala.TMCB.name(), retailerId, descriptions.toArray(new String[0]), reportId);

		if (listTMSB != null && listTMSB.size() < 1) {
			throw new Exception("data empty");
		}

		listTMSB.stream().forEach((record) -> {
			Object[] parameterTMSB = new Object[] { EnumParameterTypeOfImpala.Manufacturer.getId(),
					((SelectedProductHierarchy) record).getProductId() };
			listParametersTMSB.add(parameterTMSB);
		});
		int selectionId = jdbcDaoImpl.nextSelectionId();
		int selectionIdTMSB = jdbcDaoImpl.nextSelectionId();
		jdbcImpalaDaoImpl.saveParameterToImpala(selectionId, listParameters);
		jdbcImpalaDaoImpl.saveParameterToImpala(selectionIdTMSB, listParametersTMSB);
		result.add(selectionId);
		result.add(selectionIdTMSB);

		return result;
	}

	public SelectedProductHierarchy getHierarchyZero(int serviceId, int retailerId, String hierarchyCode,
			int reportId) {
		return this.productHierarchyDao.findLevelCeroByServiceIdAndRetailerAndHiearchyCode(serviceId, retailerId,
				hierarchyCode, reportId);
	}

	public List<CatValue> getFactsAndPeriods(int serviceId, int userId, int reportId, int groupId, int laguageId,
			Integer[] typesId) {

		List<CatValue> values = catValueDao.findFactsAndPeriods(serviceId, userId, reportId, laguageId, typesId);
		for (CatValue catValue : values) {
			Hibernate.initialize(catValue.getUrls());
			catValue.setUrls(catValue.getUrls().stream().filter(url -> url.getGroupId() == groupId)
					.collect(Collectors.toList()));
		}
		return values;
	}

	public List<SelectedProductHierarchy> getProductId(int productId, String hierarchyCode, int serviceId,
			int retailerId, int reportId) {

		List<SelectedProductHierarchy> list = productHierarchyDao.getProductId(productId, hierarchyCode, serviceId,
				retailerId, reportId);

		return list;
	}

	public List<SelectedProductHierarchy> getProductAndHerarchy(int levelId, int serviceId, int retailerId,
			int reportId) {

		List<SelectedProductHierarchy> list = productHierarchyDao.getProductlevelId(levelId, serviceId, retailerId,
				reportId);

		return list;
	}

	public List<SelectedProductHierarchy> getProductAndHerarchyCode(int serviceId, String hierarchyCode, int retailerId,
			int reportId) {

		List<SelectedProductHierarchy> list = productHierarchyDao.getProductDescription(serviceId, hierarchyCode,
				retailerId, reportId);

		return list;
	}

	public SelectedProductHierarchy getProductInHierarchyByDescription(String descripcion, String hierarchyCode,
			int serviceId, int retailerId, int reportId) {
		String descriptions[] = { descripcion };
		List<SelectedProductHierarchy> list = productHierarchyDao.getByDescriptions(serviceId, hierarchyCode,
				retailerId, descriptions, reportId);
		return (list == null || list.size() <= 0) ? null : list.get(0);
	}

}
