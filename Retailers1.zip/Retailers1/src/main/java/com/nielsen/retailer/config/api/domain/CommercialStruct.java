package com.nielsen.retailer.config.api.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity(name = "cat_commercial_structs")
@Table(name = "cat_commercial_structs", schema = "mars_config")
public class CommercialStruct implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@NotNull
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "commercial_struct_id")
	private int commercialStructId;

	@Column(name = "commercial_struct_nm")
	private String commercialStructNm;

	@Column(name = "is_active")
	private boolean active;

	@Column(name = "create_dt")
	private Timestamp createDt;

	@Column(name = "update_dt")
	private Timestamp updateDt;

	@ManyToOne(cascade = CascadeType.DETACH, fetch = FetchType.EAGER)
	@JoinColumn(name = "retailer_id")
	@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
	private Retailer retailer;

	@Transient
	@JsonProperty
	private List<CommercialStructDetail> details = new ArrayList<>();

	@Transient
	@JsonProperty
	private CommercialStructHeader header;

	public CommercialStruct() {
	}

	public int getCommercialStructId() {
		return commercialStructId;
	}

	public void setCommercialStructId(int commercialStructId) {
		this.commercialStructId = commercialStructId;
	}

	public String getCommercialStructNm() {
		return commercialStructNm;
	}

	public void setCommercialStructNm(String commercialStructNm) {
		this.commercialStructNm = commercialStructNm;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

	public Retailer getRetailer() {
		return retailer;
	}

	public void setRetailer(Retailer retailer) {
		this.retailer = retailer;
	}

	public List<CommercialStructDetail> getDetails() {
		return details;
	}

	public void setDetails(List<CommercialStructDetail> details) {
		this.details = details;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public CommercialStructHeader getHeader() {
		return header;
	}

	public void setHeader(CommercialStructHeader header) {
		this.header = header;
	}

}
