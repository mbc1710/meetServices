package com.nielsen.retailer.config.api.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nielsen.retailer.config.api.dao.CommercialStructCategoryDao;
import com.nielsen.retailer.config.api.domain.CommercialStructCategory;

@Repository
@Transactional(readOnly = true)
public class CommercialStructCategoryDaoImpl implements CommercialStructCategoryDao {

	@PersistenceContext
	private EntityManager em;

	final static Logger logger = LoggerFactory.getLogger(CommercialStructCategoryDaoImpl.class);

	@Override
	public List<CommercialStructCategory> findByRetailerIdAndUserId(int retailerId, int userId) {
		TypedQuery<CommercialStructCategory> query = em.createQuery(
				"SELECT c FROM cat_comm_struct_category c, rel_profile_commercial_structs cs, rel_user_profiles up WHERE cs.formatId = c.formatId AND up.profileId = cs.profileId AND c.retailerId = :retailerId AND up.userId = :userId",
				CommercialStructCategory.class);
		query.setParameter("retailerId", retailerId);
		query.setParameter("userId", userId);
		return query.getResultList();
	}

}
