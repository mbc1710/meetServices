package com.nielsen.retailer.config.api.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nielsen.retailer.config.api.dao.MarketTypeDao;
import com.nielsen.retailer.config.api.domain.MarketType;

@Service
public class MarketTypeService {

	@Autowired
	private MarketTypeDao marketTypeDao;

	public List<MarketType> getAllMarketTypesIsActive() {
		List<MarketType> list = marketTypeDao.findAllMartektTypesIsActive();
		return list;
	}

	public MarketType getMarketType(int id) {
		MarketType item = marketTypeDao.findOne(id);
		return item;
	}

	public List<MarketType> getAllMarketTypes() {
		List<MarketType> list = marketTypeDao.findAll();
		return list;
	}
}
