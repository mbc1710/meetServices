package com.nielsen.retailer.config.api.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nielsen.retailer.config.api.dao.MarketResolutionDetailDao;
import com.nielsen.retailer.config.api.domain.MarketResolutionDetail;

@Service
public class MarketResolutionDetailService {

	@Autowired
	private MarketResolutionDetailDao marketResolutionDetailDao;

	public List<MarketResolutionDetail> getMarketByResolutionId(int... resolutionId) {
		return marketResolutionDetailDao.findByResolutionId(resolutionId);
	}

	public List<MarketResolutionDetail> getMarketByResolutionIdIsActive(int... resolutionId) {
		return marketResolutionDetailDao.findByResolutionIdIsActive(resolutionId);
	}

	public List<MarketResolutionDetail> getMarketByUserProfileIdNoTotal(int userId, int retailerId, int countryId) {
		System.out.println(userId + " " +retailerId+ " "+countryId);
		return marketResolutionDetailDao.findByUserIdNoTotal(userId, retailerId, countryId);
	}

	public List<MarketResolutionDetail> getMarketByUserProfileIdIsTotal(int userId, int serviceId, int marketId) {
		return marketResolutionDetailDao.findByUserProfileIdIsTotal(userId, serviceId, marketId);
	}

}