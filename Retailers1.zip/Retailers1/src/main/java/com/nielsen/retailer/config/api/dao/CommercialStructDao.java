package com.nielsen.retailer.config.api.dao;

import java.util.List;

import com.nielsen.retailer.config.api.domain.CommercialStruct;

public interface CommercialStructDao {

	public List<CommercialStruct> findByService(int serviceId);

	public CommercialStruct findById(int id);
	
	public CommercialStruct findByRetailerId(int retailerId);

	public int update(CommercialStruct obj);
	
	public int updateStatus(CommercialStruct obj);

	public int create(CommercialStruct obj);

}
