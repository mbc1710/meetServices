package com.nielsen.retailer.config.api.dao.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository()
public class JdbcImpalaDaoImpl {

	@Value("${datasource.schema}")
	private String schema;

	@Autowired
	@Qualifier("impalaJdbcTemplate")
	private JdbcTemplate jdbcTemplateImpala;

	final static Logger logger = LoggerFactory.getLogger(JdbcImpalaDaoImpl.class);

	public int saveParameterToImpala(int selectionId, List<Object[]> parameters) {

		String query = "INSERT INTO cat_filter_values(type_id, product_id, create_dt) PARTITION (selection_id = %d) VALUES(%d, %d, now()) ";

		parameters.stream().forEach((record -> {
			jdbcTemplateImpala.update(String.format(query, selectionId, record[0], record[1]));

		}));
		
		jdbcTemplateImpala.execute("COMPUTE STATS cat_filter_values");
		jdbcTemplateImpala.execute("REFRESH cat_filter_values");

		return 1;
	}
}
