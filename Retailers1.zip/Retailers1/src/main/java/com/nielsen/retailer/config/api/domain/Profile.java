package com.nielsen.retailer.config.api.domain;

import java.sql.Timestamp;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity(name = "cat_profiles")
@Table(name = "cat_profiles", schema = "mars_config")
public class Profile implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "profile_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int profileId;

	@Column(name = "profile_nm")
	private String profileNm;

	@Column(name = "create_dt")
	private Timestamp createDt;

	@Column(name = "update_dt")
	private Timestamp updateDt;

	@Column(name = "is_active")
	private boolean active;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "service_id")
	@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
	private ServiceByCountry service;

	@Transient
	@JsonProperty
	private List<Report> reports = new ArrayList<>();

	@Transient
	@JsonProperty
	private List<MarketResolutionDetail> markets = new ArrayList<>();

	@Transient
	@JsonProperty
	private List<Retailer> retailers;
	
	@Transient
	@JsonProperty
	private List<CommercialStructDetail> commercialStructDetails;
	
	@Transient
	@JsonProperty
	private List<CatValue> catValues;

	public Profile() {
	}

	public Profile(int profileId, String profileNm, Timestamp createDt, boolean active) {
		super();
		this.profileId = profileId;
		this.profileNm = profileNm;
		this.createDt = createDt;
		this.active = active;
	}
	
	public List<CommercialStructDetail> getCommercialStructDetails() {
		return commercialStructDetails;
	}

	public void setCommercialStructDetails(List<CommercialStructDetail> commercialStructDetails) {
		this.commercialStructDetails = commercialStructDetails;
	}

	public List<CatValue> getCatValues() {
		return catValues;
	}

	public void setCatValues(List<CatValue> catValues) {
		this.catValues = catValues;
	}

	public int getProfileId() {
		return profileId;
	}

	public void setProfileId(int profileId) {
		this.profileId = profileId;
	}

	public String getProfileNm() {
		return profileNm;
	}

	public void setProfileNm(String profileNm) {
		this.profileNm = profileNm;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public ServiceByCountry getService() {
		return service;
	}

	public void setService(ServiceByCountry service) {
		this.service = service;
	}

	public List<Report> getReports() {
		return reports;
	}

	public void setReports(List<Report> reports) {
		this.reports = reports;
	}

	public List<MarketResolutionDetail> getMarkets() {
		return markets;
	}

	public void setMarkets(List<MarketResolutionDetail> markets) {
		this.markets = markets;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Profile [profileId=");
		builder.append(profileId);
		builder.append(", profileNm=");
		builder.append(profileNm);
		builder.append(", createDt=");
		builder.append(createDt);
		builder.append(", updateDt=");
		builder.append(updateDt);
		builder.append(", isActive=");
		builder.append(active);
		builder.append(", service=");
		builder.append(service);
		builder.append(", reports=");
		builder.append(reports);
		builder.append(", markets=");
		builder.append(markets);
		builder.append("]");
		return builder.toString();
	}

	public List<Retailer> getRetailers() {
		return retailers;
	}

	public void setRetailers(List<Retailer> retailers) {
		this.retailers = retailers;
	}

}
