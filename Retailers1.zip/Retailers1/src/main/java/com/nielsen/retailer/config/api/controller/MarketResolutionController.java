package com.nielsen.retailer.config.api.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.nielsen.retailer.commons.api.utils.Response;
import com.nielsen.retailer.config.api.domain.MarketResolution;
import com.nielsen.retailer.config.api.service.MarketResolutionService;
import com.nielsen.retailer.config.api.util.MessageService;

import ch.qos.logback.classic.BasicConfigurator;

@CrossOrigin
@RestController
@RequestMapping(value = "/retailer-config-api")
public class MarketResolutionController {

	final static Logger logger = LoggerFactory.getLogger(BasicConfigurator.class);

	@Autowired
	private MarketResolutionService marketResolutionService;

	@Autowired
	private MessageService messageSource;

	@RequestMapping(value = { "/market-resolution-type/{typeId}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<MarketResolution>>> getResolutionsByMarketType(
			@PathVariable(name = "typeId", required = true) int typeId) {

		List<MarketResolution> list = marketResolutionService.getByMarketTypeId(typeId);
		Response<List<MarketResolution>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.marketResolution.messages.1000");
		}

		response = new Response<List<MarketResolution>>(list, msg);
		return new ResponseEntity<Response<List<MarketResolution>>>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@RequestMapping(value = { "/market-resolution-type-is-active/{typeId}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<MarketResolution>>> getResolutionsByMarketTypeIsActive(
			@PathVariable(name = "typeId", required = true) int typeId) {

		List<MarketResolution> list = marketResolutionService.getByMarketTypeId(typeId);
		Response<List<MarketResolution>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.marketResolution.messages.1000");
		}

		response = new Response<List<MarketResolution>>(list, msg);
		return new ResponseEntity<Response<List<MarketResolution>>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/market-resolution-type-is-active/{servicioId}/{typeId}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<MarketResolution>>> getMarketByServicioIdAndTypeId(
			@PathVariable(name = "servicioId", required = true) int servicioId,
			@PathVariable(name = "typeId", required = true) int typeId
			) {

		List<MarketResolution> list = marketResolutionService.getMarketByServicioIdAndTypeId(servicioId,typeId);
		Response<List<MarketResolution>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.marketResolution.messages.1000");
		}

		response = new Response<List<MarketResolution>>(list, msg);
		return new ResponseEntity<Response<List<MarketResolution>>>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@RequestMapping(value = { "/market-resolution-types" }, method = { RequestMethod.POST })
	public @ResponseBody ResponseEntity<Response<List<MarketResolution>>> getResolutionsByMarketsTypes(
			@RequestBody int[] typesIds) {

		List<MarketResolution> list = marketResolutionService.getByMarketsTypesIds(typesIds);
		Response<List<MarketResolution>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.marketResolution.messages.1001");
		}else{
			msg = messageSource.getMessage("api.marketResolution.messages.1002");
		}

		response = new Response<List<MarketResolution>>(list, msg);
		return new ResponseEntity<Response<List<MarketResolution>>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/market-resolution/{resolutionId}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<MarketResolution>> getResolutionById(
			@PathVariable(name = "resolutionId", required = true) int resolutionId) {
		
		final String msg = messageSource.getMessage("api.marketResolution.messages.1000");
		MarketResolution item = marketResolutionService.getById(resolutionId);
		Response<MarketResolution> response; 
		
		if (item == null) {
			response = new Response<MarketResolution>(item, msg);
		} else {
			response = new Response<MarketResolution>(item);
		}

		return new ResponseEntity<Response<MarketResolution>>(response, HttpStatus.valueOf(response.getStatus()));
	}
}
