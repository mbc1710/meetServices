package com.nielsen.retailer.config.api.dao;

import java.util.List;

import com.nielsen.retailer.config.api.domain.CatValue;

public interface CatValueDao {
	public List<CatValue> findAll(int serviceId, int reportId, int userId, Integer [] typeId);
	
	public List<CatValue> findByReportAndService(int reportId, int serviceId, int languageId);
	
	public List<CatValue> findByProfile(int profileId);
	
	public List<CatValue> findFactsAndPeriods(int serviceId, int userId, int reportId, int laguageId, Integer[] typesId);
}
