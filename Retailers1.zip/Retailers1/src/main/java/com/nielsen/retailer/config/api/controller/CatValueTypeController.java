package com.nielsen.retailer.config.api.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.nielsen.retailer.commons.api.utils.Response;
import com.nielsen.retailer.config.api.domain.CatValueType;
import com.nielsen.retailer.config.api.service.CatValueTypeService;
import com.nielsen.retailer.config.api.util.MessageService;

import ch.qos.logback.classic.BasicConfigurator;

@CrossOrigin
@RestController
@RequestMapping(value = "/retailer-config-api")
public class CatValueTypeController {

	final static Logger logger = LoggerFactory.getLogger(BasicConfigurator.class);
	@Autowired
	private MessageService messageSource;

	@Autowired
	private CatValueTypeService catValueTypeService;

	@RequestMapping(value = { "/value-type" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<CatValueType>>> getCatValueTypes() {

		List<CatValueType> list = catValueTypeService.getAll();
		Response<List<CatValueType>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.commercialStructDetail.messages.1000");
		}

		response = new Response<List<CatValueType>>(list, msg);
		return new ResponseEntity<Response<List<CatValueType>>>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
}
