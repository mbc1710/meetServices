package com.nielsen.retailer.config.api.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.nielsen.retailer.config.api.dao.ServiceByCountryDao;
import com.nielsen.retailer.config.api.dao.ServiceByCountryRepository;
import com.nielsen.retailer.config.api.domain.ServiceByCountry;

@Service
public class ServiceByCountryService {

	@Autowired
	private ServiceByCountryDao servicesDao;
	
	@Autowired
	private ServiceByCountryRepository servicesDao2;

	public List<ServiceByCountry> getServices() {
		List<ServiceByCountry> ser = servicesDao.findAll();
		return ser;
	}
	
	public List<ServiceByCountry> getServicesByCountryActive() {
		List<ServiceByCountry> ser = servicesDao.findAllIsActive();
		return ser;
	}

	public List<ServiceByCountry> getServicesByCountry(int countryId) {
		List<ServiceByCountry> ser = servicesDao.findByCountry(countryId);
		return ser;
	}
	
	public List<ServiceByCountry> getServicesByCountryUser(int countryId, int userId, int reportId) {
		List<ServiceByCountry> ser = servicesDao.findByCountryUser(countryId, userId, reportId);
		return ser;
	}

	public ServiceByCountry getServiceById(int id) {
		return servicesDao.findById(id);
	}

	public int createServices(ServiceByCountry service) {
		return servicesDao.create(service);
	}

	public int updateService(ServiceByCountry service) {
		return servicesDao.update(service);
	}

	public int updateServiceStatus(ServiceByCountry service) {
		return servicesDao.updateStatus(service);
	}
	
	public int deleteService(ServiceByCountry service) {
		return servicesDao.delete(service);
	}

	public List<ServiceByCountry> getServicesByCountries(int ... countryId) {
		// TODO Auto-generated method stub
		return servicesDao2.findByCountriesId(countryId);
	}
}
