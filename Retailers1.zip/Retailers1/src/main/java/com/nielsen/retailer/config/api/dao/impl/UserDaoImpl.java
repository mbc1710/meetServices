package com.nielsen.retailer.config.api.dao.impl;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nielsen.retailer.config.api.dao.UserDao;
import com.nielsen.retailer.config.api.domain.Profile;
import com.nielsen.retailer.config.api.domain.RelUserProfiles;
import com.nielsen.retailer.config.api.domain.User;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional(readOnly = true)
public class UserDaoImpl implements UserDao {

	@PersistenceContext
	EntityManager em;

	final static Logger logger = LoggerFactory.getLogger(UserDaoImpl.class);

	@Override
	public List<User> findAll() {
		TypedQuery<User> query = em.createQuery("SELECT u FROM cat_users u order by id", User.class);
		return query.getResultList();
	}

	@Override
	public User findById(int id) {
		TypedQuery<User> query = em.createQuery("SELECT u FROM cat_users u WHERE user_id = :user_id order by user_id",
				User.class);
		query.setParameter("user_id", id);
		List<User> list = query.getResultList();

		return (list == null || list.size() == 0) ? null : list.get(0);
	}

	@Override
	public User findByEmail(String email) {
		TypedQuery<User> query = em.createQuery("SELECT u FROM cat_users u WHERE email = :email order by id",
				User.class);
		query.setParameter("email", email);
		List<User> list = query.getResultList();

		return (list == null || list.size() == 0) ? null : list.get(0);
	}

	@Override
	@Transactional(readOnly = false)
	public int update(User obj) {
		obj.setUpdateDt(new Timestamp((new Date()).getTime()));
		em.merge(obj);

		if (obj.getProfiles() != null && obj.getProfiles().size() > 0) {
			Query query = em.createQuery("DELETE FROM rel_user_profiles r WHERE user_id = :user_id ");
			query.setParameter("user_id", obj.getUserId());
			query.executeUpdate();

			for (Profile item : obj.getProfiles()) {
				RelUserProfiles newObj = new RelUserProfiles();
				newObj.setProfileId(item.getProfileId());
				newObj.setUserId(obj.getUserId());
				newObj.setCreateDt(new Timestamp((new Date()).getTime()));
				em.persist(newObj);
			}
		}
		return 1;
	}
	
	@Override
	@Transactional(readOnly = false)
	public int updateStatus(User obj) {
		
		Boolean active = obj.isActive();
		int userId = obj.getUserId();
	
		Query query = em.createQuery("UPDATE cat_users SET active = :active WHERE userId = :userId");
		query.setParameter("active", active);
		query.setParameter("userId", userId);
		em.flush();
		return query.executeUpdate();
	}
	
	@Override
	@Transactional(readOnly = false)
	public int create(User obj) {
		obj.setCreateDt(new Timestamp((new Date()).getTime()));
		obj.setUpdateDt(new Timestamp((new Date()).getTime()));
		em.persist(obj);
		Query query = em.createQuery("DELETE FROM rel_user_profiles r WHERE user_id = :user_id");
		query.setParameter("user_id", obj.getUserId());
		query.executeUpdate();

		for (Profile item : obj.getProfiles()) {
			RelUserProfiles newObj = new RelUserProfiles();
			newObj.setProfileId(item.getProfileId());
			newObj.setUserId(obj.getUserId());
			newObj.setCreateDt(new Timestamp((new Date()).getTime()));
			em.persist(newObj);
		}
		return 1;
	}

	@Override
	@Transactional(readOnly = false)
	public int delete(User obj) {
		Query query1 = em.createQuery("DELETE FROM rel_user_profiles r WHERE user_id = :user_id");
		query1.setParameter("user_id", obj.getUserId());
		query1.executeUpdate();
		Query query2 = em.createQuery("DELETE FROM cat_users WHERE user_id = :user_id");
		query2.setParameter("user_id", obj.getUserId());
		return query2.executeUpdate();
	}

}
