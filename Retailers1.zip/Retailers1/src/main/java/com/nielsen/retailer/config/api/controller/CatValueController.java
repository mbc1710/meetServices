package com.nielsen.retailer.config.api.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.nielsen.retailer.commons.api.utils.Response;
import com.nielsen.retailer.config.api.domain.CatValue;
import com.nielsen.retailer.config.api.service.CatValueService;
import com.nielsen.retailer.config.api.util.MessageService;

import ch.qos.logback.classic.BasicConfigurator;

@CrossOrigin
@RestController
@RequestMapping(value = "/retailer-config-api")
public class CatValueController {

	final static Logger logger = LoggerFactory.getLogger(BasicConfigurator.class);
	@Autowired
	private MessageService messageSource;

	@Autowired
	private CatValueService catValueService;

	@RequestMapping(value = { "/cat-values/{reportId}/{serviceId}/{languageId}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<Map<String, List<CatValue>> >> getCatValues(
			@PathVariable(name = "reportId", required = true) int reportId,
			@PathVariable(name = "serviceId", required = true) int serviceId,
			@PathVariable(name = "languageId", required = true) int languageId) {

		Map<String, List<CatValue>> list = catValueService.getByReportAndService(reportId, serviceId, languageId);
		Response<Map<String, List<CatValue>> > response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.commercialStructDetail.messages.1000");
		}

		response = new Response<>(list, msg);
		return new ResponseEntity<Response<Map<String, List<CatValue>>>>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
}
