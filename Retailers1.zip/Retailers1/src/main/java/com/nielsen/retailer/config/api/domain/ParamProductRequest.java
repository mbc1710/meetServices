package com.nielsen.retailer.config.api.domain;

public class ParamProductRequest {

	
	private String descripcion; 
	private String hierarchyCode;
	private int serviceId;
	private int retailerId;
	
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public String getHierarchyCode() {
		return hierarchyCode;
	}
	public void setHierarchyCode(String hierarchyCode) {
		this.hierarchyCode = hierarchyCode;
	}
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public int getRetailerId() {
		return retailerId;
	}
	public void setRetailerId(int retailerId) {
		this.retailerId = retailerId;
	}

	
}
