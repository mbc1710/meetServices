package com.nielsen.retailer.config.api.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nielsen.retailer.config.api.dao.MarketResolutionDao;
import com.nielsen.retailer.config.api.domain.MarketResolution;

@Service
public class MarketResolutionService {

	@Autowired
	private MarketResolutionDao marketResolutionDao;

	public List<MarketResolution> getByMarketTypeId(int typeId) {
		return marketResolutionDao.findAllByMarketType(typeId);
	}

	
	public List<MarketResolution> getMarketByServicioIdAndTypeId(int servicioId,int typeId ) {
		return marketResolutionDao.findAllMarketByServiceIdAndTypeId(servicioId,typeId);
	}

	public List<MarketResolution> getByMarketTypeIdIsActive(int typeId) {
		return marketResolutionDao.findAllByMarketTypeIsActive(typeId);
	}
	
	public MarketResolution getById(int resolutionId) {
		return marketResolutionDao.findById(resolutionId);
	}

	public List<MarketResolution> getByMarketsTypesIds(int[] typesIds) {
		return marketResolutionDao.findAllByMarketType(typesIds);
	}
}
