package com.nielsen.retailer.config.api.dao;

import java.util.List;

import com.nielsen.retailer.config.api.domain.Profile;;

public interface ProfileDao {

	public List<Profile> findAll();

	public List<Profile> findAllActives();
	
	public List<Profile> findByServiceId(int serviceId);

	public Profile findById(int id);

	public List<Profile> findByUserId(int id);

	public int update(Profile obj);
	
	public int updateStatus(Profile obj);

	public int create(Profile obj);

	public int delete(Profile id);
}
