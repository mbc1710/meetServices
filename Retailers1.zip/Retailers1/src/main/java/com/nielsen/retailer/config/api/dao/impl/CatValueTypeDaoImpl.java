package com.nielsen.retailer.config.api.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nielsen.retailer.config.api.dao.CatValueTypeDao;
import com.nielsen.retailer.config.api.domain.CatValueType;

@Repository
@Transactional(readOnly = true)
public class CatValueTypeDaoImpl implements CatValueTypeDao {

	@PersistenceContext
	private EntityManager em;

	@SuppressWarnings("unused")
	private final static Logger LOGGER = LoggerFactory.getLogger(CatValueTypeDaoImpl.class);

	@Override
	public List<CatValueType> findAll() {
		TypedQuery<CatValueType> query = em.createQuery("SELECT vt FROM cat_value_types vt order by valueTypeId",
				CatValueType.class);
		return query.getResultList();
	}

}
