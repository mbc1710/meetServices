package com.nielsen.retailer.config.api.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nielsen.retailer.config.api.dao.ProfileDao;
import com.nielsen.retailer.config.api.dao.UserDao;
import com.nielsen.retailer.config.api.domain.User;

@Service
public class UserService {

	@Autowired
	private UserDao userDao;

	@Autowired
	private ProfileDao profileDao;

	public List<User> getUsers() {
		return userDao.findAll();
	}

	public User getUserById(int id) {
		User user = userDao.findById(id);
		if (user != null) {
			user.setProfiles(profileDao.findByUserId(id));
		}
		return user;
	}

	public int createUser(User user) {
		return userDao.create(user);
	}

	public int updateUser(User user) {
		return userDao.update(user);
	}
	
	public int updateUserStatus(User user) {
		return userDao.updateStatus(user);
	}

	public int deleteUser(User user) {
		return userDao.delete(user);
	}

	public User getUserByEmail(String email) {
		User user = userDao.findByEmail(email);
		if (user != null) {
			user.setProfiles(profileDao.findByUserId(user.getUserId()));
		}
		return user;
	}
	

}
