package com.nielsen.retailer.config.api.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.nielsen.retailer.commons.api.utils.Response;
import com.nielsen.retailer.config.api.domain.Country;
import com.nielsen.retailer.config.api.service.CountryServices;
import com.nielsen.retailer.config.api.util.MessageService;

import ch.qos.logback.classic.BasicConfigurator;

@CrossOrigin
@RestController
@RequestMapping(value = CountryController.CONTRACT_BASE_URI)
public class CountryController {

	final static Logger logger = LoggerFactory.getLogger(BasicConfigurator.class);
	
	public final static String CONTRACT_BASE_URI = "/retailer-config-api";

	@Autowired
	private MessageService messageSource;

	@Autowired
	private CountryServices countriesServices;

	@RequestMapping(value = { "/country" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<Country>>> getCountries() {

		List<Country> countries = countriesServices.getCountries();
		Response<List<Country>> response;
		String msg = "";

		if (!(countries != null && countries.size() > 0)) {
			msg = messageSource.getMessage("api.country.messages.1000");
		}

		response = new Response<List<Country>>(countries, msg);
		return new ResponseEntity<Response<List<Country>>>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@RequestMapping(value = { "/country_is_active" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<Country>>> getCountriesIsActive() {

		List<Country> countries = countriesServices.getCountriesIsActive();
		Response<List<Country>> response;
		String msg = "";

		if (!(countries != null && countries.size() > 0)) {
			msg = messageSource.getMessage("api.country.messages.1000");
		}

		response = new Response<List<Country>>(countries, msg);
		return new ResponseEntity<Response<List<Country>>>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@RequestMapping(value = { "/country_by_user/{userId}/{reportId}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<Country>>> getCountriesByUser(
			@PathVariable(name = "userId", required = true) int userId,
			@PathVariable(name = "reportId", required = true) int reportId ) {

		List<Country> list = countriesServices.getCountriesByUser(userId, reportId);
		Response<List<Country>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.country.messages.1000");
		}

		response = new Response<List<Country>>(list, msg);
		return new ResponseEntity<Response<List<Country>>>(response,
				HttpStatus.valueOf(response.getStatus()));
	}

	
	@RequestMapping(value = { "/country/{countryId}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<Country>> getCountryById(
			@PathVariable(name = "countryId", required = true) int id) {
		final String msg = messageSource.getMessage("api.country.messages.1000");
		Country countries = countriesServices.getCountryById(id);
		Response<Country> response;

		if (countries == null) {
			response = new Response<Country>(countries, msg);
		} else {
			response = new Response<Country>(countries);
		}

		return new ResponseEntity<Response<Country>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/country" }, method = { RequestMethod.DELETE })
	public @ResponseBody ResponseEntity<Response<Integer>> deleteCountries(@RequestBody Country countries) {
		String msg = "";
		int result = countriesServices.deleteCountry(countries);
		Response<Integer> response;

		if (result != 1) {
			msg = messageSource.getMessage("api.country.messages.1003");
		} else {
			msg = messageSource.getMessage("api.country.messages.1006");
		}

		response = new Response<Integer>(result, msg);

		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/country" }, method = { RequestMethod.POST })
	public @ResponseBody ResponseEntity<Response<Integer>> createCountries(@RequestBody Country country) {
		String msg = "";
		int result = countriesServices.createCountry(country);
		Response<Integer> response;

		if (result != 1) {
			msg = messageSource.getMessage("api.country.messages.1001");
		} else {
			msg = messageSource.getMessage("api.country.messages.1004");
		}

		response = new Response<Integer>(result, msg);

		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/country" }, method = { RequestMethod.PUT })
	public @ResponseBody ResponseEntity<Response<Integer>> updateCountries(@RequestBody Country countries) {
		String msg = "";
		int result = countriesServices.updateCountry(countries);
		Response<Integer> response;

		if (result != 1) {
			msg = messageSource.getMessage("api.country.messages.1002");
		} else {
			msg = messageSource.getMessage("api.country.messages.1005");
		}

		response = new Response<Integer>(result, msg);

		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@RequestMapping(value = { "/country-status" }, method = { RequestMethod.PUT })
	public @ResponseBody ResponseEntity<Response<Integer>> updateCountriesStatus(@RequestBody Country countries) {
		String msg = "";
		int result = countriesServices.updateCountriesStatus(countries);
		Response<Integer> response;
	if (result != 1) {
			msg = messageSource.getMessage("api.user.messages.1002");
		} else {
			msg = messageSource.getMessage("api.user.messages.1006");
		}

		response = new Response<Integer>(result, msg);

		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}

}
