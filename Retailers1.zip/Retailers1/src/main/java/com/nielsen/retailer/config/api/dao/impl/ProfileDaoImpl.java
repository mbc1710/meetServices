package com.nielsen.retailer.config.api.dao.impl;

import java.util.Date;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nielsen.retailer.config.api.dao.ProfileDao;
import com.nielsen.retailer.config.api.domain.CatValue;
import com.nielsen.retailer.config.api.domain.CommercialStructDetail;
import com.nielsen.retailer.config.api.domain.MarketResolutionDetail;
import com.nielsen.retailer.config.api.domain.Profile;
import com.nielsen.retailer.config.api.domain.RelProfileCommercialStruct;
import com.nielsen.retailer.config.api.domain.RelProfileMarket;
import com.nielsen.retailer.config.api.domain.RelProfileReports;
import com.nielsen.retailer.config.api.domain.RelProfileRetailer;
import com.nielsen.retailer.config.api.domain.RelProfileValue;
import com.nielsen.retailer.config.api.domain.Report;
import com.nielsen.retailer.config.api.domain.Retailer;

@Repository
@Transactional(readOnly = true)
public class ProfileDaoImpl implements ProfileDao {

	@PersistenceContext
	EntityManager em;

	final static Logger logger = LoggerFactory.getLogger(ProfileDaoImpl.class);

	@Override
	public List<Profile> findAll() {
		StringBuilder builder = new StringBuilder();
		builder.append("SELECT p FROM cat_profiles p, " + " cat_services cs, cat_countries cc "
				+ " where p.service.serviceId = cs.serviceId " + " and cs.active = true "
				+ " and cs.country.countryId = cc.countryId " + " and cc.active = true " + " order by cc.countryNm ");
		TypedQuery<Profile> query = em.createQuery(builder.toString(), Profile.class);
		return query.getResultList();
	}

	@Override
	public Profile findById(int id) {
		String queryString = "SELECT p FROM cat_profiles p WHERE p.profileId = :profile_id order by id";
		TypedQuery<Profile> query = em.createQuery(queryString, Profile.class);
		query.setParameter("profile_id", id);
		List<Profile> list = query.getResultList();
		return (list == null || list.size() == 0) ? null : list.get(0);
	}

	@Override
	public List<Profile> findByServiceId(int serviceId) {
		String queryString = "SELECT p FROM cat_profiles p WHERE p.service.serviceId = :serviceId and p.active = true order by id";
		TypedQuery<Profile> query = em.createQuery(queryString, Profile.class);
		query.setParameter("serviceId", serviceId);
		return query.getResultList();
	}

	@Override
	@Transactional(readOnly = false)
	public int update(Profile obj) {
		Date toDay = new Date();
		obj.setUpdateDt(new Timestamp(toDay.getTime()));
		em.merge(obj);		

		if (obj.getReports() != null && obj.getReports().size() > 0) {

			Query query1 = em.createQuery("DELETE FROM rel_profile_reports r WHERE profile_id = :profile_id");
			query1.setParameter("profile_id", obj.getProfileId());
			query1.executeUpdate();

			for (Report item : obj.getReports()) {
				RelProfileReports newObj = new RelProfileReports();
				newObj.setProfileId(obj.getProfileId());
				newObj.setReportId(item.getReportId());
				newObj.setCreateDt(new Timestamp((new Date()).getTime()));
				em.persist(newObj);
			}
		}
		if (obj.getMarkets() != null && obj.getMarkets().size() > 0) {

			Query query2 = em.createQuery("DELETE FROM rel_profile_markets m WHERE profile_id = :profile_id");
			query2.setParameter("profile_id", obj.getProfileId());
			query2.executeUpdate();

			for (MarketResolutionDetail item : obj.getMarkets()) {
				RelProfileMarket newObj = new RelProfileMarket();
				newObj.setProfileId(obj.getProfileId());
				newObj.setMarketId(item.getMarketId());
				em.persist(newObj);
			}
		}

		if (obj.getRetailers() != null && obj.getRetailers().size() > 0) {

			Query query3 = em.createQuery("DELETE FROM rel_profile_retailers pr WHERE profile_id = :profile_id");
			query3.setParameter("profile_id", obj.getProfileId());
			query3.executeUpdate();

			for (Retailer item : obj.getRetailers()) {
				RelProfileRetailer newObj = new RelProfileRetailer();
				newObj.setProfileId(obj.getProfileId());
				newObj.setReailerId(item.getRetailerId());
				em.persist(newObj);
			}
		}

		if (obj.getCommercialStructDetails() != null && obj.getCommercialStructDetails().size() > 0) {

			Query query4 = em
					.createQuery("DELETE FROM rel_profile_commercial_structs pr WHERE profile_id = :profile_id");
			query4.setParameter("profile_id", obj.getProfileId());
			query4.executeUpdate();

			for (CommercialStructDetail item : obj.getCommercialStructDetails()) {
				RelProfileCommercialStruct newObj = new RelProfileCommercialStruct();
				newObj.setProfileId(obj.getProfileId());
				newObj.setCommercialStructId(item.getCommercialStructId());
				newObj.setFormatId(item.getFormatId());
				em.persist(newObj);

			}
		}
		
		if(obj.getCatValues() !=null) {
			Query query5 = em.createQuery("DELETE FROM rel_profile_values rpv WHERE profile_id = :profile_id");
			query5.setParameter("profile_id", obj.getProfileId());
			query5.executeUpdate();
			
			for(CatValue item : obj.getCatValues()){
				RelProfileValue newObj = new RelProfileValue();
				newObj.setValueId(item.getValueId());
				newObj.setProfileId(obj.getProfileId());
				em.persist(newObj);
			}
		}

		return 1;
	}

	@Override
	@Transactional(readOnly = false)
	public int create(Profile obj) {
		Date toDay = new Date();
		obj.setCreateDt(new Timestamp(toDay.getTime()));
		obj.setUpdateDt(new Timestamp(toDay.getTime()));
		em.persist(obj);

		/*
		 * Query query1 = em.
		 * createQuery("DELETE FROM rel_profile_reports r WHERE profile_id = :profile_id"
		 * ); query1.setParameter("profile_id", obj.getProfileId());
		 * query1.executeUpdate();
		 * 
		 * Query query2 = em.
		 * createQuery("DELETE FROM rel_profile_markets m WHERE profile_id = :profile_id"
		 * ); query2.setParameter("profile_id", obj.getProfileId());
		 * query2.executeUpdate();
		 * 
		 * Query query3 = em.
		 * createQuery("DELETE FROM rel_profile_retailers pr WHERE profile_id = :profile_id"
		 * ); query3.setParameter("profile_id", obj.getProfileId());
		 * query3.executeUpdate();
		 * 
		 * Query query4 = em.
		 * createQuery("DELETE FROM rel_profile_commercial_structs pr WHERE profile_id = :profile_id"
		 * ); query4.setParameter("profile_id", obj.getProfileId());
		 * query4.executeUpdate();
		 */

		// Query query5 = em.createQuery("DELETE FROM rel_profile_values rpv
		// WHERE profile_id = :profile_id");
		// query5.setParameter("profile_id", obj.getProfileId());
		// query5.executeUpdate();

		if (obj.getReports() != null) {
			for (Report item : obj.getReports()) {
				RelProfileReports newObj = new RelProfileReports();
				newObj.setProfileId(obj.getProfileId());
				newObj.setReportId(item.getReportId());
				newObj.setCreateDt(new Timestamp((new Date()).getTime()));
				em.persist(newObj);
			}
		}

		if (obj.getMarkets() != null) {
			for (MarketResolutionDetail item : obj.getMarkets()) {
				RelProfileMarket newObj = new RelProfileMarket();
				newObj.setProfileId(obj.getProfileId());
				newObj.setMarketId(item.getMarketId());
				em.persist(newObj);
			}
		}

		if (obj.getRetailers() != null) {
			for (Retailer item : obj.getRetailers()) {

				RelProfileRetailer newObj = new RelProfileRetailer();
				newObj.setProfileId(obj.getProfileId());
				newObj.setReailerId(item.getRetailerId());
				em.persist(newObj);

			}
		}

		if (obj.getCommercialStructDetails() != null) {
			for (CommercialStructDetail item : obj.getCommercialStructDetails()) {
				RelProfileCommercialStruct newObj = new RelProfileCommercialStruct();
				newObj.setProfileId(obj.getProfileId());
				newObj.setCommercialStructId(item.getCommercialStructId());
				newObj.setFormatId(item.getFormatId());
				em.persist(newObj);

			}
		}

		if(obj.getCatValues() !=null){
			for(CatValue item : obj.getCatValues()){
				RelProfileValue newObj = new RelProfileValue();
				newObj.setValueId(item.getValueId());
				newObj.setProfileId(obj.getProfileId());
				em.persist(newObj);
			}
		}

		return 1;
	}

	@Override
	@Transactional(readOnly = false)
	public int delete(Profile obj) {
		Query query1 = em.createQuery("DELETE FROM rel_profile_reports r WHERE profile_id = :profile_id");
		query1.setParameter("profile_id", obj.getProfileId());
		query1.executeUpdate();

		Query query2 = em.createQuery("DELETE FROM rel_profile_markets m WHERE profile_id = :profile_id");
		query2.setParameter("profile_id", obj.getProfileId());
		query2.executeUpdate();

		Query query3 = em.createQuery("DELETE FROM cat_profiles WHERE profile_id = :profile_id");
		query3.setParameter("profile_id", obj.getProfileId());
		query3.executeUpdate();

		Query query4 = em.createQuery("DELETE FROM rel_profile_commercial_structs pr WHERE profile_id = :profile_id");
		query4.setParameter("profile_id", obj.getProfileId());
		query4.executeUpdate();

		return 1;

	}

	@Override
	public List<Profile> findByUserId(int id) {
		TypedQuery<Profile> query = em.createQuery(
				"SELECT p FROM cat_profiles p, rel_user_profiles r WHERE p.profileId = r.profileId AND r.userId = :user_id",
				Profile.class);
		query.setParameter("user_id", id);
		return query.getResultList();
	}

	@Override
	@Transactional(readOnly = false)
	public int updateStatus(Profile obj) {
		
		Boolean active = obj.isActive();
		int profileId = obj.getProfileId();
	
		Query query = em.createQuery("UPDATE cat_profiles SET active = :active WHERE profileId = :profileId");
		query.setParameter("active", active);
		query.setParameter("profileId", profileId);
		em.flush();
		return query.executeUpdate();
	}
	
	
	@Override
	public List<Profile> findAllActives() {
		StringBuilder builder = new StringBuilder();
		builder.append("SELECT p FROM cat_profiles p WHERE p.isActive = true order by id");
		TypedQuery<Profile> query = em.createQuery(builder.toString(), Profile.class);
		return query.getResultList();
	}
}
