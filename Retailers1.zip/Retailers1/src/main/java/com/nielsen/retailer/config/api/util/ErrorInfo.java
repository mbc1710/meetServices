package com.nielsen.retailer.config.api.util;

import com.nielsen.retailer.commons.api.exceptions.AbstractErrorInfo;
import com.nielsen.retailer.commons.api.exceptions.ErrorSeverity;

public class ErrorInfo extends AbstractErrorInfo {

	public ErrorInfo(String errorId, String description, ErrorSeverity severity) {
		super(errorId, description, severity);
	}

	private static final MessageService MESSAGE_SOURCE = new MessageServiceImpl();

	public static final AbstractErrorInfo APPLICATION_PARAMETER_REQUEST_ERROR = new ErrorInfo(
			"APPLICATION_PARAMETER_REQUEST_ERROR", MESSAGE_SOURCE.getMessage("api.commons.exceptions.1000"),
			ErrorSeverity.ERROR);

	public static final AbstractErrorInfo APPLICATION_VALDIATION_ERROR = new ErrorInfo("APPLICATION_VALDIATION_ERROR",
			MESSAGE_SOURCE.getMessage("api.commons.exceptions.1001"), ErrorSeverity.ERROR);

	public static final AbstractErrorInfo APPLICATION_UNKNOWN_ERROR = new ErrorInfo("APPLICATION_UNKNOWN_ERROR",
			MESSAGE_SOURCE.getMessage("api.commons.exceptions.1002"), ErrorSeverity.ERROR);

	public static final AbstractErrorInfo AUTHORIZATION_ERROR = new ErrorInfo("AUTHORIZATION_ERROR",
			MESSAGE_SOURCE.getMessage("api.commons.exceptions.1003"), ErrorSeverity.WARNING);

	public static final AbstractErrorInfo APPLICATION_UNKNOWN_ERROR_TRANSACTION = new ErrorInfo(
			"APPLICATION_UNKNOWN_ERROR_TRANSACTION", MESSAGE_SOURCE.getMessage("api.commons.exceptions.1004"),
			ErrorSeverity.ERROR);

}