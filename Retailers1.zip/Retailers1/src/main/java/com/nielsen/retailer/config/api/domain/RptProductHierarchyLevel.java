package com.nielsen.retailer.config.api.domain;

import java.io.Serializable;
import java.util.List;

public class RptProductHierarchyLevel implements Serializable {

	private static final long serialVersionUID = 1L;

	private String description;
	private String levelId;

	private List<SelectedProductHierarchy> detail;

	public RptProductHierarchyLevel() {
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<SelectedProductHierarchy> getDetail() {
		return detail;
	}

	public void setDetail(List<SelectedProductHierarchy> detail) {
		this.detail = detail;
	}

	public String getLevelId() {
		return levelId;
	}

	public void setLevelId(String levelId) {
		this.levelId = levelId;
	}

}
