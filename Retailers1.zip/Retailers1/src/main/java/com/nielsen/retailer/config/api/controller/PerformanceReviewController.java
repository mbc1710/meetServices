package com.nielsen.retailer.config.api.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.nielsen.retailer.commons.api.utils.Response;
import com.nielsen.retailer.config.api.domain.CatValue;
import com.nielsen.retailer.config.api.domain.ParamCatValue;
import com.nielsen.retailer.config.api.domain.RptCommercialStrunct;
import com.nielsen.retailer.config.api.domain.RptProductHierarchy;
import com.nielsen.retailer.config.api.domain.SelectedProductHierarchy;
import com.nielsen.retailer.config.api.service.PerformanceReviewService;
import com.nielsen.retailer.config.api.util.MessageService;

import ch.qos.logback.classic.BasicConfigurator;

@CrossOrigin
@RestController
@RequestMapping(value = "/retailer-config-api")
public class PerformanceReviewController {

	final static Logger logger = LoggerFactory.getLogger(BasicConfigurator.class);
	@Autowired
	private MessageService messageSource;

	@Autowired
	private PerformanceReviewService reviewService;

	@RequestMapping(value = { "/performance-review-headers/{serviceId}/{retailerId}/{reportId}" }, method = {
			RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<RptProductHierarchy>>> getPerformanceReviewHeader(
			@PathVariable(name = "serviceId", required = true) int serviceId,
			@PathVariable(name = "retailerId", required = true) int retailerId,
			@PathVariable(name = "reportId", required = true) int reportId) {

		List<RptProductHierarchy> list = reviewService.getPerformanceReviewHeader(serviceId, retailerId, reportId);
		Response<List<RptProductHierarchy>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.commercialStructDetail.messages.1000");
		}

		response = new Response<List<RptProductHierarchy>>(list, msg);
		return new ResponseEntity<Response<List<RptProductHierarchy>>>(response,
				HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/performance-review/{reportId}/{retailerId}/{userId}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<RptCommercialStrunct>>> getCommercialStructDetailById(
			@PathVariable(name = "reportId", required = true) int reportId,
			@PathVariable(name = "retailerId", required = true) int retailerId,
			@PathVariable(name = "userId", required = true) int userId) {

		List<RptCommercialStrunct> list = reviewService.getCommercialStruct(reportId, retailerId, userId);
		Response<List<RptCommercialStrunct>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.commercialStructDetail.messages.1000");
		}

		response = new Response<List<RptCommercialStrunct>>(list, msg);
		return new ResponseEntity<Response<List<RptCommercialStrunct>>>(response,
				HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/performance-review-cat" }, method = { RequestMethod.POST })
	public @ResponseBody ResponseEntity<Response<List<CatValue>>> getCommercialStructDetailById(
			@RequestBody(required = true) ParamCatValue paramCatValue) {
		List<CatValue> list = reviewService.getSelectByTypeId(paramCatValue.getServiceId(), paramCatValue.getReportId(),
				paramCatValue.getUserId(), paramCatValue.getValueTypes());
		Response<List<CatValue>> response;
		String msg = "";
		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.commercialStructDetail.messages.1000");
		}
		response = new Response<List<CatValue>>(list, msg);
		return new ResponseEntity<Response<List<CatValue>>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/performance-review-hierarchy/{serviceId}/{retailerId}/{reportId}" }, method = {
			RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<RptProductHierarchy>>> getAllCatalogPerformanceReviewHierarchy(
			@PathVariable(name = "serviceId", required = true) int serviceId,
			@PathVariable(name = "retailerId", required = true) int retailerId,
			@PathVariable(name = "reportId", required = true) int reportId) {

		List<RptProductHierarchy> list = reviewService.getAllCatalogPerformanceReviewHierarchy(serviceId, retailerId,
				reportId);
		Response<List<RptProductHierarchy>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.commercialStructDetail.messages.1000");
		}

		response = new Response<List<RptProductHierarchy>>(list, msg);
		return new ResponseEntity<Response<List<RptProductHierarchy>>>(response,
				HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = {
			"/performance-review-level-cero-hierarchy/{serviceId}/{retailerId}/{reportId}" }, method = {
					RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<Integer>> getLevelProductHierarchy(
			@PathVariable(name = "serviceId", required = true) int serviceId,
			@PathVariable(name = "retailerId", required = true) int retailerId,
			@PathVariable(name = "reportId", required = true) int reportId) {

		Integer result = reviewService.getLevelCeroProductHierarchy(serviceId, retailerId, reportId);
		Response<Integer> response;
		String msg = "";

		if (result == -1) {
			msg = messageSource.getMessage("api.commercialStructDetail.messages.1000");
		}

		response = new Response<Integer>(result, msg);
		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/performance-review-category/{serviceId}/{code}/{retailerId}/{reportId}" }, method = {
			RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<SelectedProductHierarchy>>> getReviewCategory(
			@PathVariable(name = "serviceId", required = true) int serviceId,
			@PathVariable(name = "code", required = true) String code,
			@PathVariable(name = "retailerId", required = true) int retailerId,
			@PathVariable(name = "reportId", required = true) int reportId) {

		List<SelectedProductHierarchy> list = reviewService.getReviewCategory(serviceId, code, retailerId, reportId);
		Response<List<SelectedProductHierarchy>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.commercialStructDetail.messages.1000");
		}

		response = new Response<List<SelectedProductHierarchy>>(list, msg);
		return new ResponseEntity<Response<List<SelectedProductHierarchy>>>(response,
				HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = {
			"/performance-review-manufacturers/{serviceId}/{code}/{retailerId}/{reportId}" }, method = {
					RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<SelectedProductHierarchy>>> getManufacturers(
			@PathVariable(name = "serviceId", required = true) int serviceId,
			@PathVariable(name = "code", required = true) String code,
			@PathVariable(name = "retailerId", required = true) int retailerId,
			@PathVariable(name = "reportId", required = true) int reportId) {

		List<SelectedProductHierarchy> list = reviewService.getManufacturers(serviceId, code, retailerId, reportId);
		Response<List<SelectedProductHierarchy>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.commercialStructDetail.messages.1000");
		}

		response = new Response<List<SelectedProductHierarchy>>(list, msg);
		return new ResponseEntity<Response<List<SelectedProductHierarchy>>>(response,
				HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = {
			"/performance-review-manufacturers-by-product/{serviceId}/{productId}/{code}/{retailerId}/{reportId}﻿" }, method = {
					RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<SelectedProductHierarchy>>> getManufacturersId(
			@PathVariable(name = "serviceId", required = true) int serviceId,
			@PathVariable(name = "productId", required = true) int productId,
			@PathVariable(name = "code", required = true) String code,
			@PathVariable(name = "retailerId", required = true) int retailerId,
			@PathVariable(name = "reportId", required = true) int reportId) {

		List<SelectedProductHierarchy> list = reviewService.getManufacturersId(serviceId, productId, code, retailerId,
				reportId);
		Response<List<SelectedProductHierarchy>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.commercialStructDetail.messages.1000");
		}

		response = new Response<List<SelectedProductHierarchy>>(list, msg);
		return new ResponseEntity<Response<List<SelectedProductHierarchy>>>(response,
				HttpStatus.valueOf(response.getStatus()));
	}

}
