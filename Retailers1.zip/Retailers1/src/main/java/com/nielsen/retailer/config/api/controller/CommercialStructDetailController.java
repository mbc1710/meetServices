package com.nielsen.retailer.config.api.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.nielsen.retailer.commons.api.utils.Response;
import com.nielsen.retailer.config.api.domain.CommercialStructDetail;
import com.nielsen.retailer.config.api.service.CommercialStructDetailService;
import com.nielsen.retailer.config.api.util.MessageService;

import ch.qos.logback.classic.BasicConfigurator;

@CrossOrigin
@RestController
@RequestMapping(value = "/retailer-config-api")
public class CommercialStructDetailController {

	final static Logger logger = LoggerFactory.getLogger(BasicConfigurator.class);
	@Autowired
	private MessageService messageSource;

	@Autowired
	private CommercialStructDetailService csds;

	@RequestMapping(value = { "/commercial-struct-detail" }, method = { RequestMethod.PUT })
	public @ResponseBody ResponseEntity<Response<Integer>> updateCommercialStructDetail(
			@RequestBody CommercialStructDetail csd) {
		String msg = "";
		int result = csds.updateCommercialStructDetail(csd);
		Response<Integer> response;

		if (result != 1) {
			msg = messageSource.getMessage("api.commercialStructDetail.messages.1002");
		} else {
			msg = messageSource.getMessage("api.commercialStructDetail.messages.1005");
		}

		response = new Response<Integer>(result, msg);

		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/commercial-struct-detail/{commercialStructId}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<CommercialStructDetail>>> getCommercialStructDetailById(
			@PathVariable(name = "commercialStructId", required = true) int commercialStructId) {

		List<CommercialStructDetail> list = csds.getCommercialStructDetails(commercialStructId);
		Response<List<CommercialStructDetail>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.commercialStructDetail.messages.1000");
		}

		response = new Response<List<CommercialStructDetail>>(list, msg);
		return new ResponseEntity<Response<List<CommercialStructDetail>>>(response,
				HttpStatus.valueOf(response.getStatus()));
	}
	
	@RequestMapping(value = { "/commercial-struct-detail-catalog/{reportId}/{retailerId}/{userId}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<CommercialStructDetail>>> getCommercialStructDetailCat(
			@PathVariable(name = "reportId", required = true) int reportId,
			@PathVariable(name = "retailerId", required = true) int retailerId,
			@PathVariable(name = "userId", required = true) int userId) {

		List<CommercialStructDetail> list = csds.getCommercialStructDetailCat(reportId, retailerId, userId);
		Response<List<CommercialStructDetail>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.commercialStructDetail.messages.1000");
		}

		response = new Response<List<CommercialStructDetail>>(list, msg);
		return new ResponseEntity<Response<List<CommercialStructDetail>>>(response,
				HttpStatus.valueOf(response.getStatus()));
	}
	
	@RequestMapping(value = { "/commercial-struct-detail-by-retailers" }, method = { RequestMethod.POST })
	public @ResponseBody ResponseEntity<Response<List<CommercialStructDetail>>> getCommercialStructDetailByRetailer(
			@RequestBody int[] retailerIds) {

		List<CommercialStructDetail> list = csds.getCommercialStructDetailsByRetailers(retailerIds);
		Response<List<CommercialStructDetail>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.commercialStructDetail.messages.1000");
		}

		response = new Response<List<CommercialStructDetail>>(list, msg);
		return new ResponseEntity<Response<List<CommercialStructDetail>>>(response,
				HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/commercial-struct-detail/{commercialStructId}" }, method = { RequestMethod.PUT })
	public @ResponseBody ResponseEntity<Response<Integer>> updateCommercialStructDetail(
			@PathVariable(name = "commercialStructId") int commercialStructId,
			@RequestBody(required = true) List<CommercialStructDetail> details) {
		String msg = "";
		int result = csds.updateCommercialStructDetail(commercialStructId, details);

		Response<Integer> response;

		if (result != 1) {
			msg = messageSource.getMessage("api.commercialStructDetail.messages.1003");
		} else {
			msg = messageSource.getMessage("api.commercialStructDetail.messages.1006");
		}

		response = new Response<Integer>(result, msg);

		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/commercial-struct-detail/" }, method = { RequestMethod.POST })
	public @ResponseBody ResponseEntity<Response<Integer>> createCommercialStructDetail(
			@RequestBody CommercialStructDetail csd) {
		String msg = "";
		int result = csds.updateCommercialStructDetail(csd);
		Response<Integer> response;

		if (result != 1) {
			msg = messageSource.getMessage("api.commercialStructDetail.messages.1001");
		} else {
			msg = messageSource.getMessage("api.commercialStructDetail.messages.1004");
		}

		response = new Response<Integer>(result, msg);

		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}

}
