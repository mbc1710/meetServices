package com.nielsen.retailer.config.api.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nielsen.retailer.config.api.dao.CountryDao;
import com.nielsen.retailer.config.api.dao.MarketResolutionDetailDao;
import com.nielsen.retailer.config.api.dao.ServiceByCountryDao;
import com.nielsen.retailer.config.api.dao.impl.CommercialStructCategoryDaoImpl;
import com.nielsen.retailer.config.api.dao.impl.JdbcDaoImpl;
import com.nielsen.retailer.config.api.dao.impl.JdbcImpalaDaoImpl;
import com.nielsen.retailer.config.api.dao.impl.RetailerDaoImpl;
import com.nielsen.retailer.config.api.domain.CommercialStructCategory;
import com.nielsen.retailer.config.api.domain.Country;
import com.nielsen.retailer.config.api.domain.EnumParameterTypeOfImpala;
import com.nielsen.retailer.config.api.domain.MarketResolutionDetail;
import com.nielsen.retailer.config.api.domain.Retailer;
import com.nielsen.retailer.config.api.domain.SelectedWeek;
import com.nielsen.retailer.config.api.domain.ServiceByCountry;

@Service
public class PromptAddHocService {

	@Autowired
	private CountryDao countryDao;

	@Autowired
	private ServiceByCountryDao serviceByCountryDao;

	@Autowired
	private RetailerDaoImpl retailerDaoImpl;

	@Autowired
	private MarketResolutionDetailDao marketResolutionDetailDao;

	@Autowired
	private CommercialStructCategoryDaoImpl categoryDaoImpl;
	
	@Autowired
	private JdbcDaoImpl jdbcDaoImpl;

	@Autowired
	private JdbcImpalaDaoImpl jdbcImpalaDaoImpl;


	public List<Country> getCountries(int userId, int reportId) {
		return countryDao.findAllByUser(userId, reportId);
	}

	public List<ServiceByCountry> getServices(int countryId, int userId, int reportId) {
		return serviceByCountryDao.findByCountryUser(countryId, userId, reportId);
	}

	public List<Retailer> getRetailers(int serviceId, int userId) {
		return retailerDaoImpl.findByUser(userId, serviceId);
	}

	public List<MarketResolutionDetail> getSharedMarkets(int serviceId, int userId, int retailerId) {
		return marketResolutionDetailDao.findByUserIdNoTotal(userId, retailerId, serviceId);
	}

	public List<MarketResolutionDetail> getTotalMarkets(int serviceId, int userId, int marketId) {
		return marketResolutionDetailDao.findByUserProfileIdIsTotal(userId, serviceId, marketId);
	}

	public List<CommercialStructCategory> getCategories(int retailerId, int userId) {
		return categoryDaoImpl.findByRetailerIdAndUserId(retailerId, userId);
	}

	public List<SelectedWeek> getWeeks() {
		return null;
	}
	
	
	public int saveParameterWeekImpala(List<Object> weeks) {
		List<Object[]> listWeeks = new ArrayList<>();

		weeks.stream().forEach((record) -> {
			if (weeks instanceof SelectedWeek) {
				Object[] parameter = new Object[] { EnumParameterTypeOfImpala.Manufacturer.getId(),
						((SelectedProductHierarchy) record).getProductId() };
				listWeeks.add(parameter);
			}
		});

		int selectionId = jdbcDaoImpl.nextSelectionId();

		jdbcImpalaDaoImpl.saveParameterToImpala(selectionId, listWeeks);
		return selectionId;
	}
	
}
