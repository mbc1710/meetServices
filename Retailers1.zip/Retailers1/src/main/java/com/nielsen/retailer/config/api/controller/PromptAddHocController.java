package com.nielsen.retailer.config.api.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.nielsen.retailer.commons.api.utils.Response;
import com.nielsen.retailer.config.api.domain.CommercialStructCategory;
import com.nielsen.retailer.config.api.domain.Country;
import com.nielsen.retailer.config.api.domain.MarketResolutionDetail;
import com.nielsen.retailer.config.api.domain.Retailer;
import com.nielsen.retailer.config.api.domain.ServiceByCountry;
import com.nielsen.retailer.config.api.service.PromptAddHocService;
import com.nielsen.retailer.config.api.util.MessageService;

import ch.qos.logback.classic.BasicConfigurator;

@CrossOrigin
@RestController
@RequestMapping(value = "/retailer-config-api")
public class PromptAddHocController {

	final static Logger logger = LoggerFactory.getLogger(BasicConfigurator.class);

	@Autowired
	private MessageService messageSource;

	@Autowired
	private PromptAddHocService promptAddHocService;

	@RequestMapping(value = { "/prompt-addhoc-countrie/{userId}/{reportId}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<Country>>> getCountries(
			@PathVariable(name = "userId", required = true) int userId,
			@PathVariable(name = "reportId", required = true) int reportId) {

		List<Country> list = promptAddHocService.getCountries(userId, reportId);
		Response<List<Country>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.promptAddHoc.messages.1000");
		}

		response = new Response<List<Country>>(list, msg);
		return new ResponseEntity<Response<List<Country>>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/prompt-addhoc-service/{countryId}/{userId}/{reportId}" }, method = {
			RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<ServiceByCountry>>> getServices(
			@PathVariable(name = "countryId", required = true) int countryId,
			@PathVariable(name = "userId", required = true) int userId,
			@PathVariable(name = "reportId", required = true) int reportId) {
		List<ServiceByCountry> services = promptAddHocService.getServices(countryId, userId, reportId);
		Response<List<ServiceByCountry>> response;
		String msg = "";

		if (!(services != null && services.size() > 0)) {
			msg = messageSource.getMessage("api.promptAddHoc.messages.1000");
		}

		response = new Response<List<ServiceByCountry>>(services, msg);
		return new ResponseEntity<Response<List<ServiceByCountry>>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/prompt-addhoc-retailer/{serviceId}/{userId}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<Retailer>>> getRetailers(
			@PathVariable(name = "serviceId", required = true) int serviceId,
			@PathVariable(name = "userId", required = true) int userId) {
		final String msg = messageSource.getMessage("api.promptAddHoc.messages.1000");
		List<Retailer> list = promptAddHocService.getRetailers(serviceId, userId);
		Response<List<Retailer>> response;

		if (list == null) {
			response = new Response<List<Retailer>>(list, msg);
		} else {
			response = new Response<List<Retailer>>(list);
		}

		return new ResponseEntity<Response<List<Retailer>>>(response, HttpStatus.valueOf(response.getStatus()));

	}

	@RequestMapping(value = { "/prompt-addhoc-shared-market/{serviceId}/{userId}/{retailerId}" }, method = {
			RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<MarketResolutionDetail>>> getSharedMarkets(
			@PathVariable(name = "userId", required = true) int userId,
			@PathVariable(name = "serviceId", required = true) int serviceId,
			@PathVariable(name = "retailerId", required = true) int retailerId) {

		List<MarketResolutionDetail> list = promptAddHocService.getSharedMarkets(serviceId, userId, retailerId);
		Response<List<MarketResolutionDetail>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.promptAddHoc.messages.1000");
		}

		response = new Response<List<MarketResolutionDetail>>(list, msg);
		return new ResponseEntity<Response<List<MarketResolutionDetail>>>(response,
				HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/prompt-addhoc-total-market/{serviceId}/{userId}/{marketId}" }, method = {
			RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<MarketResolutionDetail>>> getTotalMarkets(
			@PathVariable(name = "userId", required = true) int userId,
			@PathVariable(name = "serviceId", required = true) int serviceId,
			@PathVariable(name = "marketId", required = true) int marketId) {

		List<MarketResolutionDetail> list = promptAddHocService.getTotalMarkets(serviceId, userId, marketId);
		Response<List<MarketResolutionDetail>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.promptAddHoc.messages.1000");
		}

		response = new Response<List<MarketResolutionDetail>>(list, msg);
		return new ResponseEntity<Response<List<MarketResolutionDetail>>>(response,
				HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/prompt-addhoc-category/{retailerId}/{userId}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<CommercialStructCategory>>> getCategories(
			@PathVariable(name = "retailerId", required = true) int retailerId,
			@PathVariable(name = "userId", required = true) int userId) {

		List<CommercialStructCategory> list = promptAddHocService.getCategories(retailerId, userId);
		Response<List<CommercialStructCategory>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.promptAddHoc.messages.1000");
		}

		response = new Response<List<CommercialStructCategory>>(list, msg);
		return new ResponseEntity<Response<List<CommercialStructCategory>>>(response,
				HttpStatus.valueOf(response.getStatus()));
	}
	
	@RequestMapping(value = { "/sprompt-addhoc-parameter-week" }, method = { RequestMethod.POST })
	public @ResponseBody ResponseEntity<Response<Integer>> saveParameterWeekImpala(
			@RequestBody List<Object> week) {
		String msg = "";
		Response<Integer> response;

		int result = promptAddHocService.saveParameterWeekImpala(week);

		if (result != 1) {
			msg = messageSource.getMessage("api.promptAddHoc.messages.1000");
		} else {
			msg = messageSource.getMessage("api.supplierReview.messages.1007");
		}

		response = new Response<Integer>(result, msg);

		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}

}
