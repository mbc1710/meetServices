package com.nielsen.retailer.config.api.dao.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nielsen.retailer.config.api.dao.ProductHierarchyDao;
import com.nielsen.retailer.config.api.domain.RptProductHierarchy;
import com.nielsen.retailer.config.api.domain.SelectedProductHierarchy;

@Repository
@Transactional(readOnly = true)
public class ProductHierarchyDaoImpl implements ProductHierarchyDao {

	@PersistenceContext
	EntityManager em;

	final static Logger logger = LoggerFactory.getLogger(ProductHierarchyDaoImpl.class);

	@Value("${datasource.schema}")
	private String schema;

	@SuppressWarnings("unchecked")
	@Override
	public List<RptProductHierarchy> findByServiceIdAndRetailerId(int serviceId, int retailerId, int reportId) {

		String strQuery = " select phl.prod_hie_lev_id, " + " phl.prod_hier_id, phl.prod_hie_lev_desc " + " from "
				+ schema + ".dim_product_hierarchy ph " + " join " + schema + ".dim_product_hierarchy_level phl on "
				+ " (ph.prod_hier_id = phl.prod_hier_id and ph.country_service_id = phl.country_service_id) " + " join "
				+ schema + ".cat_commercial_structs cs on (cs.retailer_id = :retailerId and cs.commercial_struct_id "
				+ " = ph.prod_hier_id and phl.report_id = ph.report_id) "
				+ " where ph.country_service_id = :serviceId  and phl.report_id = :reportId"
				+ " order by phl.prod_hier_id, phl.prod_hie_lev_id";
		Query query = em.createNativeQuery(strQuery);
		query.setParameter("serviceId", serviceId);
		query.setParameter("retailerId", retailerId);
		query.setParameter("reportId", reportId);

		List<Object[]> results = query.getResultList();
		List<RptProductHierarchy> details = new ArrayList<>();

		results.stream().forEach((record) -> {
			RptProductHierarchy newObj = new RptProductHierarchy();
			newObj.setDescription((record[2] == null ? "" : (String) record[2]));
			newObj.setHierarchyId((record[1] == null ? 0 : (int) record[1]));
			newObj.setLevelId((record[0] == null ? 0 : (int) record[0]));
			details.add(newObj);
		});

		return details;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<SelectedProductHierarchy> findByHierarchyIdAndLevelId(int serviceId, int hierarchyId, int levelId,
			int reportId) {

		String strQuery = " select lph.parent_prod_id, p.product_id, p.product_desc "
				+ "from lkp_product_hierarchy lph  "
				+ "join dim_product p on (lph.product_id = p.product_id and lph.country_service_id = p.country_service_id and p.report_id = lph.report_id)"
				+ "where lph.prod_hier_id = :hierarchyId " + "and lph.prod_hie_lev_id = :levelId "
				+ "and lph.country_service_id = :serviceId and lph.report_id = :reportId";
		Query query = em.createNativeQuery(strQuery);
		query.setParameter("hierarchyId", hierarchyId);
		query.setParameter("levelId", levelId);
		query.setParameter("serviceId", serviceId);
		query.setParameter("reportId", reportId);

		List<Object[]> results = query.getResultList();
		List<SelectedProductHierarchy> details = new ArrayList<>();

		results.stream().forEach((record) -> {
			SelectedProductHierarchy newObj = new SelectedProductHierarchy();
			newObj.setDescription((record[2] == null ? "" : (String) record[2]));
			newObj.setProductId((record[1] == null ? 0 : (int) record[1]));
			newObj.setParentId((record[0] == null ? 0 : (int) record[0]));
			details.add(newObj);
		});

		return details;
	}

	@SuppressWarnings("unchecked")
	@Override
	public SelectedProductHierarchy findLevelCeroByServiceIdAndRetailerId(int serviceId, int retailerId, int reportId) {

		String strQuery = " select lph.parent_prod_id, p.product_id, p.product_desc" + " from " + schema
				+ ".lkp_product_hierarchy lph " + " join " + schema
				+ ".dim_product p on (lph.product_id = p.product_id and lph.country_service_id = p.country_service_id and p.report_id = lph.report_id) "
				+ "join " + schema
				+ ".cat_commercial_structs cs on (cs.retailer_id = :retailerId and cs.commercial_struct_id "
				+ " = lph.prod_hier_id) "
				+ " where lph.prod_hie_lev_id = :levelId AND lph.country_service_id = :serviceId and lph.report_id = :reportId";
		Query query = em.createNativeQuery(strQuery);
		query.setParameter("serviceId", serviceId);
		query.setParameter("retailerId", retailerId);
		query.setParameter("levelId", 0);
		query.setParameter("reportId", reportId);

		List<Object[]> results = query.getResultList();
		SelectedProductHierarchy detail = null;

		if (results.size() > 0) {
			Object[] record = results.get(0);
			SelectedProductHierarchy newObj = new SelectedProductHierarchy();
			newObj.setDescription((record[2] == null ? "" : (String) record[2]));
			newObj.setProductId((record[1] == null ? 0 : (int) record[1]));
			newObj.setParentId((record[0] == null ? 0 : (int) record[0]));
			detail = newObj;
		}
		;

		return detail;
	}

	@SuppressWarnings("unchecked")
	@Override
	public SelectedProductHierarchy findLevelCeroByServiceIdAndRetailerAndHiearchyCode(int serviceId, int retailerId,
			String hierarchyCode, int reportId) {
		String strQuery = " select hierarchy_code, product_id from " + schema + " .rel_suplier_review_hierarchies r, "
				+ schema + " .lkp_product_hierarchy ph " + " where " + " r.prod_hier_id = ph.prod_hier_id "
				+ " and r.retailer_id = :retailerId " + " and r.hierarchy_code = :hierarchyCode "
				+ " and ph.country_service_id = :serviceId " + " and ph.level_id = 0 and ph.report_id = :reportId";
		Query query = em.createNativeQuery(strQuery);
		query.setParameter("serviceId", serviceId);
		query.setParameter("hierarchyCode", hierarchyCode);
		query.setParameter("retailerId", retailerId);
		query.setParameter("reportId", reportId);

		List<Object[]> results = query.getResultList();
		SelectedProductHierarchy detail = null;
		if (results.size() > 0) {
			Object[] record = results.get(0);
			SelectedProductHierarchy newObj = new SelectedProductHierarchy();
			newObj.setProductId((record[1] == null ? 0 : (int) record[1]));
			newObj.setHierarchyCode((record[0] == null ? "" : record[0]) + "");
			detail = newObj;
		}
		return detail;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<RptProductHierarchy> findPerformanceReviewHeader(int serviceId, int retailerId, int reportId) {
		StringBuilder strQuery = new StringBuilder();
		strQuery.append("select phl.prod_hie_lev_id levelId, phl.prod_hie_lev_desc description ")
				.append("from " + schema + ".dim_product_hierarchy ph ")
				.append("join " + schema + ".dim_product_hierarchy_level phl on (ph.prod_hier_id = phl.prod_hier_id ")
				.append("and ph.country_service_id = phl.country_service_id and ph.report_id = phl.report_id) ")
				.append("join " + schema + ".cat_commercial_structs cs on (cs.retailer_id = :retailerId ")
				.append("and cs.commercial_struct_id = ph.prod_hier_id) ")
				.append("where ph.country_service_id = :serviceId and phl.report_id = :reportId")
				.append("order by phl.prod_hier_id, phl.prod_hie_lev_id ");

		Query query = em.createNativeQuery(strQuery.toString());
		query.setParameter("serviceId", serviceId);
		query.setParameter("retailerId", retailerId);
		query.setParameter("reportId", reportId);

		List<Object[]> results = query.getResultList();
		List<RptProductHierarchy> r = new ArrayList<>();
		for (Object[] objects : results) {
			RptProductHierarchy rpt = new RptProductHierarchy();
			rpt.setLevelId(Integer.parseInt(objects[0] + ""));
			rpt.setDescription(objects[1] + "");
			r.add(rpt);
		}
		return r;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<SelectedProductHierarchy> findManufacturers(int serviceId, String code, int hierarchyId, int retailerId,
			int reportId) {

		String strQuery = " select DISTINCT lph.parent_prod_id, p.product_id, p.product_desc " + " from " + schema
				+ ".lkp_product_hierarchy lph " + " join " + schema
				+ ".dim_product p on (lph.product_id = p.product_id and lph.country_service_id = p.country_service_id and p.report_id = lph.report_id) "
				+ " join " + schema
				+ ".rel_suplier_review_hierarchies srh on (lph.prod_hier_id = srh.prod_hier_id and srh.retailer_id = :retailerId) "
				+ " join " + schema + ".cat_services cs on (p.country_service_id = cs.service_id) "
				+ " where service_id = :serviceId and srh.hierarchy_code = :code and lph.prod_hie_lev_id = :hierarchyId  and lph.report_id = :reportId";
		System.out.println(strQuery);
		Query query = em.createNativeQuery(strQuery);
		query.setParameter("serviceId", serviceId);
		query.setParameter("code", code);
		query.setParameter("hierarchyId", hierarchyId);
		query.setParameter("retailerId", retailerId);
		query.setParameter("reportId", reportId);

		List<Object[]> results = query.getResultList();
		List<SelectedProductHierarchy> details = new ArrayList<>();

		results.stream().forEach((record) -> {
			SelectedProductHierarchy newObj = new SelectedProductHierarchy();
			newObj.setDescription((record[2] == null ? "" : (String) record[2]));
			newObj.setProductId((record[1] == null ? 0 : (int) record[1]));
			newObj.setParentId((record[0] == null ? 0 : (int) record[0]));
			details.add(newObj);
		});

		return details;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<SelectedProductHierarchy> findManufacturersId(int serviceId, String code, int hierarchyId,
			int productId, int retailerId, int reportId) {

		String strQuery = " select DISTINCT lph.parent_prod_id, p.product_id, p.product_desc " + " from " + schema
				+ ".lkp_product_hierarchy lph " + " join " + schema
				+ ".dim_product p on (lph.product_id = p.product_id and lph.country_service_id = p.country_service_id and p.report_id = lph.report_id) "
				+ " join " + schema
				+ ".rel_suplier_review_hierarchies srh on (lph.prod_hier_id = srh.prod_hier_id and srh.retailer_id = :retailerId) "
				+ " join " + schema + ".cat_services cs on (p.country_service_id = cs.service_id) "
				+ " where service_id = :serviceId and srh.hierarchy_code = :code and lph.prod_hie_lev_id = :hierarchyId and lph.report_id = :reportId "
				+ " and lph.prod_hier_id = :productId ";
		Query query = em.createNativeQuery(strQuery);
		query.setParameter("serviceId", serviceId);
		query.setParameter("code", code);
		query.setParameter("hierarchyId", hierarchyId);
		query.setParameter("productId", productId);
		query.setParameter("retailerId", retailerId);
		query.setParameter("reportId", reportId);

		List<Object[]> results = query.getResultList();
		List<SelectedProductHierarchy> details = new ArrayList<>();

		results.stream().forEach((record) -> {
			SelectedProductHierarchy newObj = new SelectedProductHierarchy();
			newObj.setDescription((record[2] == null ? "" : (String) record[2]));
			newObj.setProductId((record[1] == null ? 0 : (int) record[1]));
			newObj.setParentId((record[0] == null ? 0 : (int) record[0]));
			details.add(newObj);
		});

		return details;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<SelectedProductHierarchy> getProductId(int productId, String hierarchyCode, int serviceId,
			int retailerId, int reportId) {
		String strQuery = "select DISTINCT lph.parent_prod_id, p.product_id, p.product_desc " + "from " + schema
				+ ".lkp_product_hierarchy lph " + "join " + schema
				+ ".dim_product p on (lph.product_id = p.product_id and lph.country_service_id = p.country_service_id and p.report_id = lph.report_id) "
				+ "join " + schema + ".rel_suplier_review_hierarchies srh on (lph.prod_hier_id = srh.prod_hier_id) "
				+ "where lph.prod_hie_lev_id =:productId and srh.hierarchy_code =:hierarchyCode and p.country_service_id =:serviceId and "
				+ "srh.retailer_id =:retailerId and lph.report_id = :reportId";
		Query query = em.createNativeQuery(strQuery);
		query.setParameter("productId", productId);
		query.setParameter("hierarchyCode", hierarchyCode);
		query.setParameter("serviceId", serviceId);
		query.setParameter("retailerId", retailerId);
		query.setParameter("reportId", reportId);

		List<Object[]> results = query.getResultList();
		List<SelectedProductHierarchy> details = new ArrayList<>();

		results.stream().forEach((record) -> {
			SelectedProductHierarchy newObj = new SelectedProductHierarchy();
			newObj.setDescription((record[2] == null ? "" : (String) record[2]));
			newObj.setProductId((record[1] == null ? 0 : (int) record[1]));
			newObj.setParentId((record[0] == null ? 0 : (int) record[0]));
			details.add(newObj);
		});

		return details;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<SelectedProductHierarchy> getProductlevelId(int levelId, int serviceId, int retailerId, int reportId) {
		String strQuery = "select DISTINCT lph.parent_prod_id, p.product_id, p.product_desc " + " from " + schema
				+ ".lkp_product_hierarchy lph " + " join " + schema
				+ ".dim_product p on (lph.product_id = p.product_id and lph.country_service_id = p.country_service_id and p.report_id = lph.report_id) "
				+ " join " + schema
				+ ".rel_suplier_review_hierarchies srh on (lph.prod_hier_id = srh.prod_hier_id and srh.retailer_id = :retailerId) "
				+ " where  lph.prod_hie_lev_id = :levelId AND p.country_service_id = :serviceId and lph.report_id = :reportId";
		Query query = em.createNativeQuery(strQuery);
		query.setParameter("levelId", levelId);
		query.setParameter("serviceId", serviceId);
		query.setParameter("retailerId", retailerId);
		query.setParameter("reportId", reportId);

		List<Object[]> results = query.getResultList();
		List<SelectedProductHierarchy> details = new ArrayList<>();

		results.stream().forEach((record) -> {
			SelectedProductHierarchy newObj = new SelectedProductHierarchy();
			newObj.setDescription((record[2] == null ? "" : (String) record[2]));
			newObj.setProductId((record[1] == null ? 0 : (int) record[1]));
			newObj.setParentId((record[0] == null ? 0 : (int) record[0]));
			details.add(newObj);
		});

		return details;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<SelectedProductHierarchy> getProductDescription(int serviceId, String hierarchyCode, int retailerId,
			int reportId) {
		String strQuery = " select DISTINCT lph.parent_prod_id, p.product_id, p.product_desc " + " from " + schema
				+ ".lkp_product_hierarchy lph " + " join " + schema
				+ ".dim_product p on (lph.product_id = p.product_id and lph.country_service_id = p.country_service_id and p.report_id = lph.report_id) "
				+ " join " + schema
				+ ".rel_suplier_review_hierarchies srh on (lph.prod_hier_id = srh.prod_hier_id and srh.retailer_id = :retailerId) "
				+ " where srh.hierarchy_code = :hierarchyCode AND p.country_service_id = :serviceId and lph.report_id = :reportId";
		Query query = em.createNativeQuery(strQuery);
		query.setParameter("hierarchyCode", hierarchyCode);
		query.setParameter("serviceId", serviceId);
		query.setParameter("retailerId", retailerId);
		query.setParameter("reportId", reportId);

		List<Object[]> results = query.getResultList();
		List<SelectedProductHierarchy> details = new ArrayList<>();

		results.stream().forEach((record) -> {
			SelectedProductHierarchy newObj = new SelectedProductHierarchy();
			newObj.setDescription((record[2] == null ? "" : (String) record[2]));
			newObj.setProductId((record[1] == null ? 0 : (int) record[1]));
			newObj.setParentId((record[0] == null ? 0 : (int) record[0]));
			details.add(newObj);
		});

		return details;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<SelectedProductHierarchy> getByDescriptions(int serviceId, String hierarchyCode, int retailerId,
			String[] descriptions, int reportId) {
		List<String> desc = new ArrayList<>();

		for (String record : descriptions) {
			desc.add("'" + record.trim().toUpperCase() + "'");
		}

		String strQuery = " select DISTINCT lph.parent_prod_id, p.product_id, p.product_desc " + " from " + schema
				+ ".lkp_product_hierarchy lph " + " join " + schema
				+ ".dim_product p on (lph.product_id = p.product_id and lph.country_service_id = p.country_service_id and p.report_id = lph.report_id) "
				+ " join " + schema + ".rel_suplier_review_hierarchies srh on "
				+ " (lph.prod_hier_id = srh.prod_hier_id and srh.retailer_id = :retailerId) "
				+ " where srh.hierarchy_code = :hierarchyCode "
				+ " AND p.country_service_id = :serviceId and lph.report_id = :reportId"
				+ " and upper(p.product_desc)  in  ("
				+ (Arrays.toString(desc.toArray()).replace("[", "").replace("]", "")) + ")";
		System.out.println(strQuery);
		Query query = em.createNativeQuery(strQuery);
		query.setParameter("hierarchyCode", hierarchyCode);
		query.setParameter("serviceId", serviceId);
		query.setParameter("retailerId", retailerId);
		query.setParameter("reportId", reportId);

		List<Object[]> results = query.getResultList();
		List<SelectedProductHierarchy> details = new ArrayList<>();

		results.stream().forEach((record) -> {
			SelectedProductHierarchy newObj = new SelectedProductHierarchy();
			newObj.setDescription((record[2] == null ? "" : (String) record[2]));
			newObj.setProductId((record[1] == null ? 0 : (int) record[1]));
			newObj.setParentId((record[0] == null ? 0 : (int) record[0]));
			details.add(newObj);
		});

		return details;
	}

}
