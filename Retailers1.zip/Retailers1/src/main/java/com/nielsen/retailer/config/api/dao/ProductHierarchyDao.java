package com.nielsen.retailer.config.api.dao;

import java.util.List;

import com.nielsen.retailer.config.api.domain.RptProductHierarchy;
import com.nielsen.retailer.config.api.domain.SelectedProductHierarchy;

public interface ProductHierarchyDao {
	public List<RptProductHierarchy> findByServiceIdAndRetailerId(int serviceId, int retailerId, int reportId);

	public List<SelectedProductHierarchy> findByHierarchyIdAndLevelId(int serviceId, int hierarchyId, int levelId,
			int reportId);

	public List<SelectedProductHierarchy> findManufacturers(int serviceId, String code, int hierarchyId, int retailerId,
			int reportId);

	public List<SelectedProductHierarchy> findManufacturersId(int serviceId, String code, int hierarchyId,
			int productId, int retailerId, int reportId);

	public List<RptProductHierarchy> findPerformanceReviewHeader(int serviceId, int retailerId, int reportId);

	public SelectedProductHierarchy findLevelCeroByServiceIdAndRetailerId(int serviceId, int retailerId, int reportId);

	SelectedProductHierarchy findLevelCeroByServiceIdAndRetailerAndHiearchyCode(int serviceId, int retailerId,
			String hierarchyCode, int reportId);

	public List<SelectedProductHierarchy> getProductId(int levelId, String hierarchyCode, int serviceId, int retailerId,
			int reportId);

	public List<SelectedProductHierarchy> getProductlevelId(int levelId, int serviceId, int retailerId, int reportId);

	public List<SelectedProductHierarchy> getProductDescription(int serviceId, String hierarchyCode, int retailerId,
			int reportId);

	public List<SelectedProductHierarchy> getByDescriptions(int serviceId, String hierarchyCode, int retailerId,
			String[] descriptions, int reportId);

}
