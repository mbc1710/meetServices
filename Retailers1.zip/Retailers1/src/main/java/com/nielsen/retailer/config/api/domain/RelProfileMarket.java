package com.nielsen.retailer.config.api.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "rel_profile_markets")
@Table(name = "rel_profile_markets", schema = "mars_config")
public class RelProfileMarket implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "profile_id")
	private int profileId;

	@Id
	@Column(name = "market_id")
	private int marketId;

	public int getProfileId() {
		return profileId;
	}

	public void setProfileId(int profileId) {
		this.profileId = profileId;
	}

	public int getMarketId() {
		return marketId;
	}

	public void setMarketId(int marketId) {
		this.marketId = marketId;
	}

}
