package com.nielsen.retailer.config.api.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.nielsen.retailer.config.api.domain.MarketType;

@Repository()
public interface MarketTypeDao extends JpaRepository<MarketType, Integer> {

	@Query(value = "SELECT mt FROM cat_market_types mt WHERE mt.active = true")
	public List<MarketType> findAllMartektTypesIsActive();
}
