package com.nielsen.retailer.config.api.controller;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.nielsen.retailer.commons.api.utils.Response;
import com.nielsen.retailer.config.api.domain.Profile;
import com.nielsen.retailer.config.api.service.ProfileService;
import com.nielsen.retailer.config.api.util.MessageService;

import ch.qos.logback.classic.BasicConfigurator;

@CrossOrigin
@RestController
@RequestMapping(value = "/retailer-config-api")
public class ProfileController {
	final static Logger logger = LoggerFactory.getLogger(BasicConfigurator.class);

	@Autowired
	private MessageService messageSource;

	@Autowired
	private ProfileService profileService;

	@RequestMapping(value = { "/profile" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<Profile>>> getProfiles() {

		Response<List<Profile>> response;
		String msg = "";
		List<Profile> profiles = profileService.getProfiles();

		if (!(profiles != null && profiles.size() > 0)) {
			msg = messageSource.getMessage("api.profile.messages.1000");
		}

		response = new Response<List<Profile>>(profiles, msg);
		return new ResponseEntity<Response<List<Profile>>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/profile-is-Active" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<Profile>>> getProfilesIsActive() {

		Response<List<Profile>> response;
		String msg = "";
		List<Profile> profiles = profileService.getProfilesIsActive();

		if (!(profiles != null && profiles.size() > 0)) {
			msg = messageSource.getMessage("api.profile.messages.1000");
		}

		response = new Response<List<Profile>>(profiles, msg);
		return new ResponseEntity<Response<List<Profile>>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/profile-by-service/{serviceId}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<Profile>>> getProfilesByServiceId(@PathVariable("serviceId") int serviceId) {
		Response<List<Profile>> response;
		String msg = "";
		List<Profile> profiles = profileService.getProfilesByService(serviceId);
		
		if (!(profiles != null && profiles.size() > 0)) {
			msg = messageSource.getMessage("api.profile.messages.1000");
		}

		response = new Response<List<Profile>>(profiles, msg);
		return new ResponseEntity<Response<List<Profile>>>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@RequestMapping(value = { "/profile-by-services" }, method = { RequestMethod.POST })
	public @ResponseBody ResponseEntity<Response<List<Profile>>> getProfilesByServicesId(
			@RequestBody int[] servicesId) {
		logger.info("ids to search ... ", Arrays.toString(servicesId));
		Response<List<Profile>> response;
		String msg = "";
		List<Profile> profiles = profileService.getProfilesByServices(servicesId); 
		
		if (!(profiles != null && profiles.size() > 0)) {
			msg = messageSource.getMessage("api.profile.messages.1004");
		}else{
			msg = messageSource.getMessage("api.profile.messages.1008");
		}

		response = new Response<List<Profile>>(profiles, msg);
		return new ResponseEntity<Response<List<Profile>>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/profile/{profile_id}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<Profile>> getProfileById(
			@PathVariable(name = "profile_id", required = true) int id) {
		final String msg = messageSource.getMessage("api.profile.messages.1000");
		Profile profile = profileService.getProfileById(id);
		Response<Profile> response;

		if (profile == null) {
			response = new Response<Profile>(profile, msg);
		} else {
			response = new Response<Profile>(profile);
		}

		return new ResponseEntity<Response<Profile>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/profile" }, method = { RequestMethod.POST })
	public @ResponseBody ResponseEntity<Response<Integer>> createProfile(@RequestBody Profile profile) {
		String msg = "";
		logger.info("Retailers del profile... " + profile.getRetailers());
		int result = profileService.createProfile(profile);
		Response<Integer> response;

		if (result != 1) {
			msg = messageSource.getMessage("api.profile.messages.1001");
		} else {
			msg = messageSource.getMessage("api.profile.messages.1005");
		}

		response = new Response<Integer>(result, msg);

		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/profile" }, method = { RequestMethod.PUT })
	public @ResponseBody ResponseEntity<Response<Integer>> updateProfile(@RequestBody Profile profile) {
		String msg = "";
		int result = profileService.updateProfile(profile);
		Response<Integer> response;

		if (result != 1) {
			msg = messageSource.getMessage("api.profile.messages.1002");
		} else {
			msg = messageSource.getMessage("api.profile.messages.1006");
		}

		response = new Response<Integer>(result, msg);

		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@RequestMapping(value = { "/profile-status" }, method = { RequestMethod.PUT })
	public @ResponseBody ResponseEntity<Response<Integer>> updateProfileStatus(@RequestBody Profile profile) {
		String msg = "";
		int result = profileService.updateProfileStatus(profile);
		Response<Integer> response;
	if (result != 1) {
			msg = messageSource.getMessage("api.user.messages.1002");
		} else {
			msg = messageSource.getMessage("api.user.messages.1006");
		}

		response = new Response<Integer>(result, msg);

		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/profile" }, method = { RequestMethod.DELETE })
	public @ResponseBody ResponseEntity<Response<Integer>> deleteProfile(@RequestBody Profile profile) {
		String msg = "";
		int result = profileService.deleteProfile(profile);
		Response<Integer> response;

		if (result != 1) {
			msg = messageSource.getMessage("api.profile.messages.1003");
		} else {
			msg = messageSource.getMessage("api.profile.messages.1007");
		}

		response = new Response<Integer>(result, msg);

		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}
}
