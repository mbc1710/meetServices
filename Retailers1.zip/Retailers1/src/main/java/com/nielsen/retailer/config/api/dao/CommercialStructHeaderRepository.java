package com.nielsen.retailer.config.api.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.nielsen.retailer.config.api.domain.CommercialStructHeader;

@Repository
public interface CommercialStructHeaderRepository extends JpaRepository<CommercialStructHeader, Integer> {

	@Query(value = "FROM cat_commercial_struct_headers CSH WHERE commercialStructId = :commercialStructId")
	public CommercialStructHeader findById(@Param("commercialStructId") int commercialStructId);

	@Query(value = "SELECT DISTINCT CSH "
			+ " FROM cat_commercial_struct_headers CSH, "
			+ " cat_commercial_structs CS, "
			+ " rel_profile_retailers RPR, "
			+ " rel_user_profiles RUP, "
			+ " rel_profile_reports RPRS "
			+ " WHERE CSH.commercialStructId = CS.commercialStructId "
			+ " AND CS.active = true "
			+ " AND CS.retailer = RPR.retailerId "
			+ " AND RPR.profileId = RUP.profileId "
			+ " AND RUP.profileId = RPRS.profileId "
			+ " AND CS.retailer.retailerId = :retailerId "
			+ " AND RPRS.reportId = :reportId"
			+ " AND RUP.userId = :userId ")
	public CommercialStructHeader findByRetailerId(
			@Param("retailerId") int retailerId,
			@Param("reportId") int reportId,
			@Param("userId") int userId);
}

