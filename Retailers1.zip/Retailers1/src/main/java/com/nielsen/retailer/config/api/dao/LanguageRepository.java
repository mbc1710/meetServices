package com.nielsen.retailer.config.api.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
import com.nielsen.retailer.config.api.domain.Language;

@Repository()
public interface LanguageRepository extends JpaRepository<Language, Integer> {

	@Query(value = "SELECT l FROM cat_languages l")
	public List<Language> selectAll();

}
