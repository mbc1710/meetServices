package com.nielsen.retailer.config.api.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nielsen.retailer.config.api.dao.CountryDao;
import com.nielsen.retailer.config.api.domain.Country;

@Service
public class CountryServices {

	@Autowired
	private CountryDao countriesDao;

	public List<Country> getCountries() {
		return countriesDao.findAll();
	}
	
	public List<Country> getCountriesIsActive() {
		return countriesDao.findAllIsActive();
	}

	public List<Country> getCountriesByUser(int userId, int reportId) {
		return countriesDao.findAllByUser(userId, reportId);
	}

	
	public Country getCountryById(int id) {
		return countriesDao.findById(id);
	}

	public int deleteCountry(Country countries) {
		return countriesDao.delete(countries);
	}

	public int createCountry(Country countries) {
		return countriesDao.create(countries);
	}

	public int updateCountry(Country countries) {
		return countriesDao.update(countries);
	}
	
	public int updateCountriesStatus(Country country) {
		return countriesDao.updateStatus(country);
	}
	

}
