package com.nielsen.retailer.config.api.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nielsen.retailer.config.api.domain.MarketResolution;

@Repository
@Transactional(readOnly = true)
public interface MarketResolutionDao extends JpaRepository<MarketResolution, Integer> {

	@Query(value = "SELECT mr FROM cat_market_resolutions mr WHERE mr.marketTypeId in (:typeId)")
	public List<MarketResolution> findAllByMarketType(@Param("typeId") int ... typeId);
	
	@Query(value = "SELECT mr.* FROM mars_config.cat_market_resolutions mr, mars_config.cat_market_definitions md, mars_config.cat_services s "
			+ " WHERE mr.definition_id = md.definition_id and s.service_id = md.service_id and s.service_id = :serviceId "
			+ "and s.is_active = true and mr.type_id = :typeId", nativeQuery = true)
	public List<MarketResolution> findAllMarketByServiceIdAndTypeId(@Param("serviceId") int serviceId, @Param("typeId") int typeId);
	
	@Query(value = "SELECT mr FROM cat_market_resolutions mr WHERE mr.marketTypeId in (:typeId) and active = true")
	public List<MarketResolution> findAllByMarketTypeIsActive(@Param("typeId") int ... typeId);

	@Query(value = "SELECT mr FROM cat_market_resolutions mr WHERE mr.resolutionId = :resolutionId")
	public MarketResolution findById(@Param("resolutionId") int resolutionId);
}
