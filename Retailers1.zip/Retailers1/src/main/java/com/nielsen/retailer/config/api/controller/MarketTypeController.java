package com.nielsen.retailer.config.api.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.nielsen.retailer.commons.api.utils.Response;
import com.nielsen.retailer.config.api.domain.MarketType;
import com.nielsen.retailer.config.api.service.MarketTypeService;
import com.nielsen.retailer.config.api.util.MessageService;

import ch.qos.logback.classic.BasicConfigurator;

@CrossOrigin
@RestController
@RequestMapping(value = "/retailer-config-api")
public class MarketTypeController {

	final static Logger logger = LoggerFactory.getLogger(BasicConfigurator.class);

	@Autowired
	private MarketTypeService marketTypeService;

	@Autowired
	private MessageService messageSource;

	@RequestMapping(value = { "/market-type-is-active" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<MarketType>>> getMarketTypes() {

		List<MarketType> list = marketTypeService.getAllMarketTypesIsActive();
		Response<List<MarketType>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.marketType.messages.1000");
		}

		response = new Response<List<MarketType>>(list, msg);
		return new ResponseEntity<Response<List<MarketType>>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/market-type" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<MarketType>>> getAllMarketTypes() {

		List<MarketType> list = marketTypeService.getAllMarketTypes();
		Response<List<MarketType>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.marketType.messages.1000");
		}

		response = new Response<List<MarketType>>(list, msg);
		return new ResponseEntity<Response<List<MarketType>>>(response, HttpStatus.valueOf(response.getStatus()));
	}
	

}
