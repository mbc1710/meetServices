package com.nielsen.retailer.config.api.domain;

public class ParamCatValue {

	private int serviceId;
	private int reportId;
	private int userId;
	private int languageId;
	private int groupId;
	private Integer[] valueTypes;
	
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public int getReportId() {
		return reportId;
	}
	public void setReportId(int reportId) {
		this.reportId = reportId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getLanguageId() {
		return languageId;
	}
	public void setLanguageId(int languageId) {
		this.languageId = languageId;
	}
	public Integer[] getValueTypes() {
		return valueTypes;
	}
	public void setValueTypes(Integer[] valueTypes) {
		this.valueTypes = valueTypes;
	}
	public int getGroupId() {
		return groupId;
	}
	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}
	
	
	
}
