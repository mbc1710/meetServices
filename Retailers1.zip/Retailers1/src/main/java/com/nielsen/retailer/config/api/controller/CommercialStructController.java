package com.nielsen.retailer.config.api.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.nielsen.retailer.commons.api.utils.Response;
import com.nielsen.retailer.config.api.domain.CommercialStruct;
import com.nielsen.retailer.config.api.service.CommercialStructService;
import com.nielsen.retailer.config.api.util.MessageService;

import ch.qos.logback.classic.BasicConfigurator;

@CrossOrigin
@RestController
@RequestMapping(value = "/retailer-config-api")
public class CommercialStructController {

	final static Logger logger = LoggerFactory.getLogger(BasicConfigurator.class);

	@Autowired
	private CommercialStructService commercialStructController;

	@Autowired
	private MessageService messageSource;

	@RequestMapping(value = { "/commercial-struct-by-service/{serviceId}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<CommercialStruct>>> getCommercialStructs(
			@PathVariable(name = "serviceId", required = true) int serviceId) {

		List<CommercialStruct> list = commercialStructController.getCommercialStructs(serviceId);
		Response<List<CommercialStruct>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.commercialStruct.messages.1000");
		}

		response = new Response<List<CommercialStruct>>(list, msg);
		return new ResponseEntity<Response<List<CommercialStruct>>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/commercial-struct/{commercialStructId}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<CommercialStruct>> getCommercialStructById(
			@PathVariable(name = "commercialStructId", required = true) int commercialStructId) {

		final String msg = messageSource.getMessage("api.commercialStruct.messages.1000");
		CommercialStruct obj = commercialStructController.getCommercialStructById(commercialStructId);
		Response<CommercialStruct> response;

		if (obj == null) {
			response = new Response<CommercialStruct>(obj, msg);
		} else {
			response = new Response<CommercialStruct>(obj);
		}

		response = new Response<CommercialStruct>(obj, "");
		return new ResponseEntity<Response<CommercialStruct>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/commercial-struct-without-detail/{commercial_struct_id}" }, method = {RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<CommercialStruct>> getCommercialStructByIdWithoutDetail(
			@PathVariable(name = "commercial_struct_id", required = true) int commercialStructId) {

		final String msg = messageSource.getMessage("api.commercialStruct.messages.1000");
		CommercialStruct obj = commercialStructController.getCommercialStructByIdWithOutDetail(commercialStructId);
		Response<CommercialStruct> response;

		if (obj == null) {
			response = new Response<CommercialStruct>(obj, msg);
		} else {
			response = new Response<CommercialStruct>(obj);
		}

		response = new Response<CommercialStruct>(obj, "");
		return new ResponseEntity<Response<CommercialStruct>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/commercial-struct/{serviceId}" }, method = { RequestMethod.POST })
	public @ResponseBody ResponseEntity<Response<Integer>> createCommercialStruct(
			@PathVariable(name = "serviceId", required = true) int serviceId,
			@RequestBody(required = true) CommercialStruct commercialStruct) throws Exception {
		String msg = "";
		int result = commercialStructController.create(commercialStruct);

		Response<Integer> response;

		if (result != 1) {
			msg = messageSource.getMessage("api.commercialStruct.messages.1001");
		} else {
			msg = messageSource.getMessage("api.commercialStruct.messages.1004");
		}

		response = new Response<Integer>(result, msg);

		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/commercial-struct" }, method = { RequestMethod.PUT })
	public @ResponseBody ResponseEntity<Response<Integer>> updateCommercialStruct(
			@RequestBody(required = true) CommercialStruct commercialStruct) {
		String msg = "";
		int result = commercialStructController.update(commercialStruct);

		Response<Integer> response;

		if (result != 1) {
			msg = messageSource.getMessage("api.commercialStruct.messages.1002");
		} else {
			msg = messageSource.getMessage("api.commercialStruct.messages.1006");
		}

		response = new Response<Integer>(result, msg);

		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/commercial-struct-status" }, method = { RequestMethod.PUT })
	public @ResponseBody ResponseEntity<Response<Integer>> updateCommercialStructStatus(
			@RequestBody(required = true) CommercialStruct commercialStruct) {
		String msg = "";
		int result = commercialStructController.updateCommercialStructStatus(commercialStruct);

		Response<Integer> response;

		if (result != 1) {
			msg = messageSource.getMessage("api.commercialStruct.messages.1002");
		} else {
			msg = messageSource.getMessage("api.commercialStruct.messages.1006");
		}

		response = new Response<Integer>(result, msg);

		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@RequestMapping(value = { "/commercial-struct_update_full" }, method = { RequestMethod.PUT})
	public @ResponseBody ResponseEntity<Response<Integer>> updateFullCommercialStruct(
			@RequestBody(required = true) CommercialStruct commercialStruct) throws Exception {
		String msg = "";
		int result = commercialStructController.updateFull(commercialStruct);

		Response<Integer> response;

		if (result != 1) {
			msg = messageSource.getMessage("api.commercialStruct.messages.1001");
		} else {
			msg = messageSource.getMessage("api.commercialStruct.messages.1004");
		}

		response = new Response<Integer>(result, msg);

		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}
}
