package com.nielsen.retailer.config.api.dao;

import java.util.List;

import com.nielsen.retailer.config.api.domain.Selected;

public interface PerformanceReviewDao {
	public List<Selected> findValuesByTypeId(int serviceId, int userId, int reportId, int typeId);
}
