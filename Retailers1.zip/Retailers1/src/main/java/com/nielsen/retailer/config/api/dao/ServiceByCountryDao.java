package com.nielsen.retailer.config.api.dao;

import java.util.List;

import com.nielsen.retailer.config.api.domain.ServiceByCountry;


public interface ServiceByCountryDao {
	

	public List<ServiceByCountry> findAll();
	
	public List<ServiceByCountry> findAllIsActive();
	
	public List<ServiceByCountry> findByCountry(int countryId);
	
	public List<ServiceByCountry> findByCountryUser(int countryId, int userId, int reportId);

	public ServiceByCountry findById(int id);

	public int update(ServiceByCountry obj);
	
	public int updateStatus(ServiceByCountry obj);

	public int create(ServiceByCountry obj);

	public int delete(ServiceByCountry id);
	
	
	
}
