package com.nielsen.retailer.config.api.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nielsen.retailer.config.api.dao.CommercialStructHeaderRepository;
import com.nielsen.retailer.config.api.domain.CommercialStructHeader;

@Service
public class CommercialStructHeaderService {

	@Autowired
	private CommercialStructHeaderRepository cshr;

	public int update(CommercialStructHeader header) {
		cshr.save(header);
		return 1;
	}

	public CommercialStructHeader getById(int commercialStructId) {
		return cshr.findById(commercialStructId);
	}

	
}
