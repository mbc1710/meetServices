package com.nielsen.retailer.config.api.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.nielsen.retailer.commons.api.utils.Response;
import com.nielsen.retailer.config.api.domain.CatValue;
import com.nielsen.retailer.config.api.domain.ParamCatValue;
import com.nielsen.retailer.config.api.domain.ParamProductRequest;
import com.nielsen.retailer.config.api.domain.SelectedProductHierarchy;
import com.nielsen.retailer.config.api.service.SupplierReviewService;
import com.nielsen.retailer.config.api.util.MessageService;

import ch.qos.logback.classic.BasicConfigurator;

@CrossOrigin
@RestController
@RequestMapping(value = "/retailer-config-api")
public class SupplierReviewController {

	final static Logger logger = LoggerFactory.getLogger(BasicConfigurator.class);
	@Autowired
	private MessageService messageSource;

	@Autowired
	private SupplierReviewService supplierReviewService;

	@RequestMapping(value = { "/supplier-review-save-manufacturers-with-category" }, method = { RequestMethod.POST })
	public @ResponseBody ResponseEntity<Response<Integer>> saveManufacturesWithCategoryToImpala(
			@RequestBody List<Object> manufactures) {
		String msg = "";
		Response<Integer> response;

		int result = supplierReviewService.saveManufacturersWithCategoryToImpala(manufactures);

		if (result != 1) {
			msg = messageSource.getMessage("api.supplierReview.messages.1008");
		} else {
			msg = messageSource.getMessage("api.supplierReview.messages.1007");
		}

		response = new Response<Integer>(result, msg);

		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = {
			"/supplier-review-save-manufacturers-without-category/{serviceId}/{retailerId}/{reportId}" }, method = {
					RequestMethod.POST })
	public @ResponseBody ResponseEntity<Response<List<Integer>>> saveManufacturesWithoutCataegoryToImpala(
			@PathVariable(name = "serviceId", required = true) int serviceId,
			@PathVariable(name = "retailerId", required = true) int retailerId,
			@PathVariable(name = "reportId", required = true) int reportId,
			@RequestBody List<SelectedProductHierarchy> manufactures) throws Exception {
		String msg = "";
		Response<List<Integer>> response;

		List<Integer> result = supplierReviewService.saveManufacturersWithoutCategoryToImpala(serviceId, retailerId,
				manufactures, reportId);

		System.out.println(result.size());
		if ((result != null) | (result.size() <= 1)) {
			msg = messageSource.getMessage("api.supplierReview.messages.1008");
		} else {
			msg = messageSource.getMessage("api.supplierReview.messages.1007");
		}

		response = new Response<List<Integer>>(result, msg);

		return new ResponseEntity<Response<List<Integer>>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = {
			"/supplier-review-hierarchy-zero/{serviceId}/{retailerId}/{hierarchyCode}/{reportId}" }, method = {
					RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<SelectedProductHierarchy>> getHierarchyZero(
			@PathVariable(name = "serviceId", required = true) int serviceId,
			@PathVariable(name = "hierarchyCode", required = true) String hierarchyCode,
			@PathVariable(name = "retailerId", required = true) int retailerId,
			@PathVariable(name = "reportId", required = true) int reportId) {
		String msg = "";
		Response<SelectedProductHierarchy> response;
		SelectedProductHierarchy result = null;
		result = supplierReviewService.getHierarchyZero(serviceId, retailerId, hierarchyCode, reportId);
		if (result != null) {
			msg = messageSource.getMessage("api.supplierReview.messages.1008");
		} else {
			msg = messageSource.getMessage("api.supplierReview.messages.1007");
		}
		response = new Response<SelectedProductHierarchy>(result, msg);
		return new ResponseEntity<Response<SelectedProductHierarchy>>(response,
				HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/supplier-review-facts-periods" }, method = { RequestMethod.POST })
	public @ResponseBody ResponseEntity<Response<List<CatValue>>> getFactsAndPeriods(
			@RequestBody(required = true) ParamCatValue paramCatValue) {

		List<CatValue> list = supplierReviewService.getFactsAndPeriods(paramCatValue.getServiceId(),
				paramCatValue.getUserId(), paramCatValue.getReportId(), paramCatValue.getGroupId(),
				paramCatValue.getLanguageId(), paramCatValue.getValueTypes());
		Response<List<CatValue>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.commercialStructDetail.messages.1000");
		}

		response = new Response<List<CatValue>>(list, msg);
		return new ResponseEntity<Response<List<CatValue>>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = {
			"/supplier-review-productId/{productId}/{hierarchyCode}/{serviceId}/{retailerId}/{reportId}" }, method = {
					RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<SelectedProductHierarchy>>> getProductsId(
			@PathVariable(name = "productId", required = true) int productId,
			@PathVariable(name = "hierarchyCode", required = true) String hierarchyCode,
			@PathVariable(name = "serviceId", required = true) int serviceId,
			@PathVariable(name = "retailerId", required = true) int retailerId,
			@PathVariable(name = "reportId", required = true) int reportId) {

		List<SelectedProductHierarchy> list = this.supplierReviewService.getProductId(productId, hierarchyCode,
				serviceId, retailerId, reportId);
		Response<List<SelectedProductHierarchy>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.commercialStructDetail.messages.1000");
		}

		response = new Response<List<SelectedProductHierarchy>>(list, msg);
		return new ResponseEntity<Response<List<SelectedProductHierarchy>>>(response,
				HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/supplier-review-product-by-description/{reportId}" }, method = { RequestMethod.POST })
	public @ResponseBody ResponseEntity<Response<SelectedProductHierarchy>> geProductIdByDescripcion(
			@PathVariable(name = "reportId", required = true) int reportId,
			@RequestBody(required = true) ParamProductRequest request) {

		SelectedProductHierarchy list = this.supplierReviewService.getProductInHierarchyByDescription(
				request.getDescripcion(), request.getHierarchyCode(), request.getServiceId(), request.getRetailerId(),
				reportId);
		Response<SelectedProductHierarchy> response;
		String msg = "";
		response = new Response<SelectedProductHierarchy>(list, msg);
		return new ResponseEntity<Response<SelectedProductHierarchy>>(response,
				HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = {
			"/supplier-review-product-levelid/{levelId}/{serviceId}/{retailerId}/{reportId}" }, method = {
					RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<SelectedProductHierarchy>>> getProductAndHerarchy(
			@PathVariable(name = "levelId", required = true) int levelId,
			@PathVariable(name = "serviceId", required = true) int serviceId,
			@PathVariable(name = "retailerId", required = true) int retailerId,
			@PathVariable(name = "reportId", required = true) int reportId) {

		List<SelectedProductHierarchy> list = this.supplierReviewService.getProductAndHerarchy(levelId, serviceId,
				retailerId, reportId);
		Response<List<SelectedProductHierarchy>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.commercialStructDetail.messages.1000");
		}

		response = new Response<List<SelectedProductHierarchy>>(list, msg);
		return new ResponseEntity<Response<List<SelectedProductHierarchy>>>(response,
				HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = {
			"/supplier-review-product-hierarchycode/{serviceId}/{hierarchyCode}/{retailerId}/{reportId}" }, method = {
					RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<SelectedProductHierarchy>>> getProductAndHerarchyCode(
			@PathVariable(name = "serviceId", required = true) int serviceId,
			@PathVariable(name = "hierarchyCode", required = true) String hierarchyCode,
			@PathVariable(name = "retailerId", required = true) int retailerId,
			@PathVariable(name = "reportId", required = true) int reportId) {

		List<SelectedProductHierarchy> list = this.supplierReviewService.getProductAndHerarchyCode(serviceId,
				hierarchyCode, retailerId, reportId);
		Response<List<SelectedProductHierarchy>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.commercialStructDetail.messages.1000");
		}

		response = new Response<List<SelectedProductHierarchy>>(list, msg);
		return new ResponseEntity<Response<List<SelectedProductHierarchy>>>(response,
				HttpStatus.valueOf(response.getStatus()));
	}

}
