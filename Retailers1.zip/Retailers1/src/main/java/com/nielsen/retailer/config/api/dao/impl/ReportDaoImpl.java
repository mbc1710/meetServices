package com.nielsen.retailer.config.api.dao.impl;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nielsen.retailer.config.api.dao.ReportDao;
import com.nielsen.retailer.config.api.domain.Report;

@Repository
@Transactional(readOnly = true)
public class ReportDaoImpl implements ReportDao {

	@PersistenceContext
	EntityManager em;

	final static Logger logger = LoggerFactory.getLogger(ProfileDaoImpl.class);

	@Override
	public List<Report> findAll() {
		TypedQuery<Report> query = em.createQuery("SELECT r from cat_reports r", Report.class);
		return query.getResultList();
	}

	@Override
	public List<Report> findAllIsActive() {
		TypedQuery<Report> query = em.createQuery("SELECT r from cat_reports r where r.active = true ", Report.class);
		return query.getResultList();
	}

	@Override
	public List<Report> findByProfile(int profileId) {
		// TODO Auto-generated method stub
		TypedQuery<Report> query = em.createQuery(
				"SELECT r FROM cat_reports r, rel_profile_reports rp WHERE r.reportId = rp.reportId AND rp.profileId = :profileId",
				Report.class);
		query.setParameter("profileId", profileId);
		return query.getResultList();
	}

	@Override
	public Report findById(int id) {
		TypedQuery<Report> query = em.createQuery("SELECT r FROM cat_reports r WHERE reports_id = :reports_id",
				Report.class);
		query.setParameter("reports_id", id);
		List<Report> list = query.getResultList();
		return (list == null || list.size() == 0) ? null : list.get(0);
	}

	@Override
	public List<Report> findByService(int id) {
		// TODO Auto-generated method stub
		TypedQuery<Report> query = em.createQuery("SELECT r FROM cat_reports r WHERE r.serviceId = :serviceId",
				Report.class);
		query.setParameter("serviceId", id);
		return query.getResultList();
	}

	@Override
	@Transactional(readOnly = false)
	public int update(Report obj) {
		obj.setUpdateDt(new Timestamp((new Date()).getTime()));
		em.merge(obj);
		return 1;
	}
	
	@Override
	@Transactional(readOnly = false)
	public int updateStatus(Report obj) {
		
		Boolean active = obj.isActive();
		int reportId = obj.getReportId();
	
		Query query = em.createQuery("UPDATE cat_reports SET active = :active WHERE reportId = :reportId");
		query.setParameter("active", active);
		query.setParameter("reportId", reportId);
		em.flush();
		return query.executeUpdate();
	}

	@Override
	public int create(Report obj) {
		obj.setCreateDt(new Timestamp((new Date()).getTime()));
		obj.setUpdateDt(new Timestamp((new Date()).getTime()));
		em.persist(obj);

		return 1;
	}

	@Override
	@Transactional(readOnly = false)
	public int delete(Report id) {
		Query query = em.createQuery("DELETE FROM cat_reports WHERE report_id = :report_id");
		query.setParameter("report_id", id.getReportId());
		return query.executeUpdate();
	}

	@Override
	public List<Report> findByUser(int userId) {
		TypedQuery<Report> query = em.createQuery(
				"SELECT distinct r FROM cat_reports r, rel_profile_reports pr, rel_user_profiles up WHERE r.reportId = pr.reportId AND up.profileId = pr.profileId AND up.userId = :userId",
				Report.class);
		query.setParameter("userId", userId);
		return query.getResultList();
	}

}
