package com.nielsen.retailer.config.api.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nielsen.retailer.config.api.domain.CommercialStructDetail;

@Repository
@Transactional(readOnly = true)
public interface CommercialStructDetailRepository extends JpaRepository<CommercialStructDetail, Integer> {
	@Query(value = "SELECT mtr FROM cat_commercial_struct_details mtr "
			+ "WHERE mtr.commercialStructId in ( select cs.commercialStructId from cat_commercial_structs cs "
			+ "WHERE cs.retailer.retailerId in (:retailerIds)  )")
	public List<CommercialStructDetail> findByRetailersId(@Param("retailerIds") int... retailerIds);

	@Query(value = "SELECT DISTINCT r FROM cat_commercial_struct_details r, rel_profile_commercial_structs rp "
			+ "WHERE r.commercialStructId = rp.commercialStructId AND r.formatId =  rp.formatId AND rp.profileId = :profileId")
	public List<CommercialStructDetail> findByProfile(@Param("profileId") int profileId);
	
	

}
