package com.nielsen.retailer.config.api.domain;

public enum EnumParameterTypeOfImpala {
	Manufacturer(1), Week(2);
	EnumParameterTypeOfImpala(int id) {
		this.id = id;
	}

	private int id;

	public int getId() {
		return id;
	}
}
