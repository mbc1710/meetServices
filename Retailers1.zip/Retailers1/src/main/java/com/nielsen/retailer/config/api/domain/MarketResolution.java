package com.nielsen.retailer.config.api.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "cat_market_resolutions")
@Table(name = "cat_market_resolutions", schema = "mars_config")
public class MarketResolution implements Serializable {

	private static final long serialVersionUID = -927627248920484991L;

	@Id
	@Column(name = "resolution_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int resolutionId;

	@Column(name = "resolution_nm")
	private String resolutionNm;

	@Column(name = "create_dt")
	private Timestamp createDt;

	@Column(name = "update_dt")
	private Timestamp updateDt;

	@Column(name = "type_id")
	private int marketTypeId;

	@Column(name = "definition_id")
	private int definitionId;

	@Column(name = "is_active")
	private boolean active;

	public int getResolutionId() {
		return resolutionId;
	}

	public void setResolutionId(int resolutionId) {
		this.resolutionId = resolutionId;
	}

	public String getResolutionNm() {
		return resolutionNm;
	}

	public void setResolutionNm(String resolutionNm) {
		this.resolutionNm = resolutionNm;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}

	public int getDefinitionId() {
		return definitionId;
	}

	public void setDefinitionId(int definitionId) {
		this.definitionId = definitionId;
	}


	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public int getMarketTypeId() {
		return marketTypeId;
	}

	public void setMarketTypeId(int marketTypeId) {
		this.marketTypeId = marketTypeId;
	}

}
