package com.nielsen.retailer.config.api.dao;

import java.util.List;

import com.nielsen.retailer.config.api.domain.RelUserProfiles;

public interface RelUserProfilesDao {

	public List<RelUserProfiles> findAllByUser(int id);

	public RelUserProfiles findById(int userId, int prfileId);

	public int create(RelUserProfiles obj);

	public int delete(RelUserProfiles id);

	public int deleteAllByUser(int id);
}
