package com.nielsen.retailer.config.api.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMethod;

import com.nielsen.retailer.commons.api.utils.Response;
import com.nielsen.retailer.config.api.domain.FileRetailer;
import com.nielsen.retailer.config.api.domain.Retailer;
import com.nielsen.retailer.config.api.service.RetailerService;
import com.nielsen.retailer.config.api.util.MessageService;

import ch.qos.logback.classic.BasicConfigurator;

@CrossOrigin
@RestController
@RequestMapping(value = "/retailer-config-api")
public class RetailerController {

	final static Logger logger = LoggerFactory.getLogger(BasicConfigurator.class);

	@Autowired
	private RetailerService retailerService;

	@Autowired
	private MessageService messageSource;

	@RequestMapping(value = { "/retailer-by-service/{serviceId}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<Retailer>>> getRetailersByService(
			@PathVariable(name = "serviceId", required = true) int serviceId) {

		List<Retailer> list = retailerService.getRetailer(serviceId);
		Response<List<Retailer>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.retailer.messages.1000");
		}

		response = new Response<List<Retailer>>(list, msg);
		return new ResponseEntity<Response<List<Retailer>>>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@RequestMapping(value = { "/retailer-by-service-is-active/{serviceId}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<Retailer>>> getRetailersByServiceIsActive(
			@PathVariable(name = "serviceId", required = true) int serviceId) {

		List<Retailer> list = retailerService.getRetailerIsActive(serviceId);
		Response<List<Retailer>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.retailer.messages.1000");
		}

		response = new Response<List<Retailer>>(list, msg);
		return new ResponseEntity<Response<List<Retailer>>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/retailer/{retailerId}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<Retailer>>> getRetailerById(
			@PathVariable(name = "retailerId", required = true) int retailerId) {

		List<Retailer> list = retailerService.getRetailerById(retailerId);
		Response<List<Retailer>> response;
		String msg = "";

		if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.retailer.messages.1000");
		}
		response = new Response<List<Retailer>>(list, msg);
		return new ResponseEntity<Response<List<Retailer>>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/retailer" }, method = { RequestMethod.POST })
	public @ResponseBody ResponseEntity<Response<Integer>> createRetailer(@RequestBody Retailer retailer) {

		String msg = "";
		int result = retailerService.createRetailer(retailer);
		Response<Integer> response;

		if (result != 1) {
			msg = messageSource.getMessage("api.retailer.messages.1001");
		} else {
			msg = messageSource.getMessage("api.retailer.messages.1004");
		}

		response = new Response<Integer>(result, msg);

		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@RequestMapping(value = { "/retailer-markets" }, method = { RequestMethod.POST })
	public @ResponseBody ResponseEntity<Response<List<Retailer>>> retailerByMarkets(@RequestBody int[] marketsIds) {

		String msg = "";
		List<Retailer> list = retailerService.findByMarkets(marketsIds);
		Response<List<Retailer>> response;
				if (!(list != null && list.size() > 0)) {
			msg = messageSource.getMessage("api.retailer.messages.1000");
		}
		response = new Response<List<Retailer>>(list, msg);
		return new ResponseEntity<Response<List<Retailer>>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/retailer-batch/{serviceId}" }, method = { RequestMethod.POST })
	public @ResponseBody ResponseEntity<Response<Integer>> createRetailer(@PathVariable("serviceId") int serviceId,
			@RequestBody List<FileRetailer> records) {
		String msg = "";
		int result = retailerService.createRetailers(serviceId, records);
		Response<Integer> response;

		if (result != 1) {
			msg = messageSource.getMessage("api.retailer.messages.1002");
		} else {
			msg = messageSource.getMessage("api.retailer.messages.1005");
		}

		response = new Response<Integer>(result, msg);

		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/retailer" }, method = { RequestMethod.PUT })
	public @ResponseBody ResponseEntity<Response<Integer>> updateRetailerById(@RequestBody Retailer retailer) {
		String msg = "";
		int result = retailerService.updateRetailerById(retailer);
		Response<Integer> response;

		if (result != 1) {
			msg = messageSource.getMessage("api.retailer.messages.1003");
		} else {
			msg = messageSource.getMessage("api.retailer.messages.1006");
		}

		response = new Response<Integer>(result, msg);
		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@RequestMapping(value = { "/retailer-status" }, method = { RequestMethod.PUT })
	public @ResponseBody ResponseEntity<Response<Integer>> updateRetailerStatus(@RequestBody Retailer retailer) {
		String msg = "";
		int result = retailerService.updateRetailerStatus(retailer);
		Response<Integer> response;
	if (result != 1) {
			msg = messageSource.getMessage("api.user.messages.1002");
		} else {
			msg = messageSource.getMessage("api.user.messages.1006");
		}

		response = new Response<Integer>(result, msg);

		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/retailer-by-user/{userId}/{countryId}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<Retailer>>> getRetailerByUserId(
			@PathVariable(name = "userId", required = true) int userId,
			@PathVariable(name = "countryId", required = true) int countryId ){
		final String msg = messageSource.getMessage("api.retailer.messages.1000");
		List<Retailer> list = retailerService.getRetailerByUserId(userId,countryId);
		Response<List<Retailer>> response;
		
		if(list == null){
			response = new Response<List<Retailer>>(list, msg);
		}else{
			response = new Response<List<Retailer>>(list);
		}
		
		return new ResponseEntity<Response<List<Retailer>>>(response,  HttpStatus.valueOf(response.getStatus()));
		
	}
	
	@RequestMapping(value = { "/retailer-by-user-hierarchy/{userId}/{countryId}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<Retailer>>> getRetailerByUserIdAndCountryHyerarchy(
			@PathVariable(name = "userId", required = true) int userId,
			@PathVariable(name = "countryId", required = true) int countryId ){
		final String msg = messageSource.getMessage("api.retailer.messages.1000");
		List<Retailer> list = retailerService.getRetailerByUserIdAndCountryHyerarchy(userId,countryId);
		Response<List<Retailer>> response;
		
		if(list == null){
			response = new Response<List<Retailer>>(list, msg);
		}else{
			response = new Response<List<Retailer>>(list);
		}
		
		return new ResponseEntity<Response<List<Retailer>>>(response,  HttpStatus.valueOf(response.getStatus()));
		
	}
	
}