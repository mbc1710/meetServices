package com.nielsen.retailer.config.api.dao;

import java.util.List;

import com.nielsen.retailer.config.api.domain.CommercialStructDetail;
import com.nielsen.retailer.config.api.domain.Selected;

public interface CommercialStructDetailDao {

	public int update(CommercialStructDetail obj);

	public int create(CommercialStructDetail obj);

	public int deleteByCommercialStructId(int commercialStructId);

	public List<CommercialStructDetail> findByCommercialStructId(int commercialStructId);

	public CommercialStructDetail findByCommercialStructIdAndFormatId(int commercialStructId, int formatId);

	public int updateAllByCommercialStructId(int commercialStructId);

	public List<Selected> findByLevel4(int commercialStructId, int retailerId, int reportId, int userId);

	public List<Selected> findByLevel3(int commercialStructId, int retailerId, int reportId, int userId);

	public List<Selected> findByLevel2(int commercialStructId, int retailerId, int reportId, int userId);

	public List<Selected> findByLevel1(int commercialStructId, int retailerId, int reportId, int userId);
	
	public List<CommercialStructDetail> findByCommercialStructCat(int retailerId, int reportId, int userId);

}
