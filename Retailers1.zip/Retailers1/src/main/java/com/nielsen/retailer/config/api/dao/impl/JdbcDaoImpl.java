package com.nielsen.retailer.config.api.dao.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nielsen.retailer.config.api.domain.CommercialStructDetail;

@Repository()
public class JdbcDaoImpl {

	@Autowired
	@Qualifier("postgresJdbcTemplate")
	private JdbcTemplate jdbcTemplate;

	@Value("${datasource.schema}")
	private String schema;

	final static Logger logger = LoggerFactory.getLogger(JdbcDaoImpl.class);

	public Integer InsertCommercialStrucDetail(CommercialStructDetail obj) {
		Integer out = -1;
		out = jdbcTemplate.update(
				"INSERT INTO " + schema
						+ ".cat_commercial_struct_details (commercial_struct_id,format_id,format_nm,infact_nm,level_1,level_2,level_3,is_active) "
						+ "VALUES (?,?,?,?,?,?,?,?)",
				new Object[] { obj.getCommercialStructId(), obj.getFormatId(), obj.getFormatNm(), obj.getInfactNm(),
						obj.getLevel1(), obj.getLevel2(), obj.getLevel3(), obj.isActive() });
		return out;
	}

	public int InsertCommercialStrucDetail(List<Object[]> obj) {
		jdbcTemplate.batchUpdate("INSERT INTO " + schema
				+ ".cat_commercial_struct_details (commercial_struct_id,format_id,format_nm,infact_nm,level_1,level_2,level_3,is_active) "
				+ "VALUES (?,?,?,?,?,?,?,?)", obj);
		return 1;
	}

	public int nextSelectionId() {

		String select = "SELECT nextval('" + schema + ".sq_selection_id')";
		int selectionId = (Integer) jdbcTemplate.queryForObject(select, Integer.class);

		return selectionId;
	}

}
