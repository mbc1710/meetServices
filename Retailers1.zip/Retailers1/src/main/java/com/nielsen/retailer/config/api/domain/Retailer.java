package com.nielsen.retailer.config.api.domain;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity(name = "cat_retailers")
@Table(name = "cat_retailers", schema = "mars_config")
public class Retailer implements Serializable, Comparable<Retailer> {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "retailer_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int retailerId;

	@Column(name = "retailer_nm")
	private String retailerNm;

	@Column(name = "is_active")
	private boolean active;

	@Column(name = "service_id")
	private int serviceId;

	@Column(name = "retailer_external_id")
	private int retailerExternalId;
	
	@ManyToMany
	@JoinTable(name="rel_market_retailer",joinColumns=@JoinColumn(name = "retailer_id"),
				inverseJoinColumns=@JoinColumn(name = "market_id"), schema="mars_config")
	private Set<MarketResolutionDetail> markets;

	public Retailer() {
	}

	public int getRetailerId() {
		return retailerId;
	}

	public void setRetailerId(int retailerId) {
		this.retailerId = retailerId;
	}

	public String getRetailerNm() {
		return retailerNm;
	}

	public void setRetailerNm(String retailerNm) {
		this.retailerNm = retailerNm;
	}


	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public int getServiceId() {
		return serviceId;
	}

	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}

	public int getRetailerExternalId() {
		return retailerExternalId;
	}

	public void setRetailerExternalId(int retailerExternalId) {
		this.retailerExternalId = retailerExternalId;
	}

	@Override
	public int compareTo(Retailer o) {
		if (retailerId == o.getRetailerId())
			return 0;
		else if (retailerId > o.getRetailerId())
			return 1;
		else
			return -1;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj instanceof Retailer) {
			Retailer retailer = (Retailer) obj;
			return retailerExternalId == retailer.getRetailerExternalId() ? true : false;
		}
		return false;
	}

	@Override
	public int hashCode() {
		return retailerExternalId;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Retailer [retailerId=");
		builder.append(retailerId);
		builder.append(", retailerNm=");
		builder.append(retailerNm);
		builder.append(", isActive=");
		builder.append(active);
		builder.append(", serviceId=");
		builder.append(serviceId);
		builder.append(", retailerExternalId=");
		builder.append(retailerExternalId);
		builder.append("]");
		return builder.toString();
	}

	public Set<MarketResolutionDetail> getMarkets() {
		return markets;
	}

	public void setMarkets(Set<MarketResolutionDetail> markets) {
		this.markets = markets;
	}

}
