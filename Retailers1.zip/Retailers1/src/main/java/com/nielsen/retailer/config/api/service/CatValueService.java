package com.nielsen.retailer.config.api.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nielsen.retailer.config.api.dao.CatValueDao;
import com.nielsen.retailer.config.api.domain.CatValue;

@Service
public class CatValueService {

	@Autowired
	private CatValueDao catValueDao;
	
	private static final int FACT = 1;
	private static final int PERIOD = 2;
	private static final String FACT_STR = "fact";
	private static final String PERIOD_STR = "period";
	
	
	public Map<String, List<CatValue>> getByReportAndService(int reportId, int serviceId, int languageId) {
		Map<String, List<CatValue>> returnData = new HashMap<>();
		for (CatValue catValue : this.catValueDao.findByReportAndService(reportId, serviceId, languageId)) {
			if (!returnData.containsKey(FACT_STR)) {
				returnData.put(FACT_STR, new ArrayList<>());
			}
			if (!returnData.containsKey(PERIOD_STR)) {
				returnData.put(PERIOD_STR, new ArrayList<>());
			}
			if (catValue.getValueTypeId() == FACT) {
				returnData.get(FACT_STR).add(catValue);
			} else if (catValue.getValueTypeId() == PERIOD) {
				returnData.get(PERIOD_STR).add(catValue);
			}
		}
		return returnData;
	}

}
