package com.nielsen.retailer.config.api.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.data.repository.query.Param;

import com.nielsen.retailer.config.api.domain.Retailer;

@Repository
public interface RetailerRepository extends JpaRepository<Retailer, Integer> {

	@Query(value = "SELECT r FROM cat_retailers r WHERE r.retailerId = :retailerId")
	public List<Retailer> findRetailerById(@Param("retailerId") int retailerId);
	
	@Query(value =" "
			+ "select r.* from mars_config.cat_profiles p "
			+ "inner join mars_config.rel_profile_retailers pr on p.profile_id = pr.profile_id "
			+ "inner join mars_config.cat_retailers r on r.retailer_id = pr.retailer_id "
			+ "where pr.profile_id = :profileId", nativeQuery = true)
	public List<Retailer> findByProfile(@Param("profileId") int profileId);
	
	@Query(value = "SELECT distinct(r) FROM cat_retailers r inner join r.markets m WHERE m.marketId in (:marketsId)")
	public List<Retailer> findRetailerByMarket(@Param("marketsId") int ... marketsId);

}
