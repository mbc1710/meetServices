package com.nielsen.retailer.config.api.domain;

import java.io.Serializable;
import java.util.Map;

public class Selected implements Serializable {

	private static final long serialVersionUID = 1L;

	private String level;

	private String leveldown;

	private Map<String, String> urls;

	public Selected() {
	}

	public Selected(String level, String leveldown) {
		this.level = level;
		this.leveldown = leveldown;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getLeveldown() {
		return leveldown;
	}

	public void setLeveldown(String leveldown) {
		this.leveldown = leveldown;
	}

	public Map<String, String> getUrls() {
		return urls;
	}

	public void setUrls(Map<String, String> urls) {
		this.urls = urls;
	}

}
