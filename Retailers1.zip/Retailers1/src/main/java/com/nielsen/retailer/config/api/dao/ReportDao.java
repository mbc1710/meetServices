package com.nielsen.retailer.config.api.dao;

import java.util.List;

import com.nielsen.retailer.config.api.domain.Report;

public interface ReportDao {

	public List<Report> findAll();

	public List<Report> findAllIsActive();
	
	public Report findById(int id);

	public int update(Report obj);
	
	public int updateStatus(Report obj);

	public int create(Report obj);

	public int delete(Report id);

	public List<Report> findByService(int id);

	public List<Report> findByProfile(int profileId);

	public List<Report> findByUser(int userId);

}
