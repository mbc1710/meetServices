package com.nielsen.retailer.config.api.service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nielsen.retailer.config.api.dao.CommercialStructDetailDao;
import com.nielsen.retailer.config.api.dao.CommercialStructDetailRepository;
import com.nielsen.retailer.config.api.domain.CommercialStructDetail;

@Service
public class CommercialStructDetailService {

	@Autowired
	private CommercialStructDetailDao commercialStructDetailDao;

	@Autowired
	private CommercialStructDetailRepository commercialStructDetailRepository;

	public int updateCommercialStructDetail(CommercialStructDetail commercialStructDetail) {
		return commercialStructDetailDao.update(commercialStructDetail);
	}

	public int updateCommercialStructDetail(int commercialStructId, List<CommercialStructDetail> list) {
		Set<CommercialStructDetail> details = new HashSet<>(1);
		commercialStructDetailDao.updateAllByCommercialStructId(commercialStructId);
		for (CommercialStructDetail item : list) {
			CommercialStructDetail obj = null;
			obj = commercialStructDetailDao.findByCommercialStructIdAndFormatId(commercialStructId, item.getFormatId());
			if (obj != null) {
				obj.setFormatNm(item.getFormatNm());
				obj.setInfactNm(item.getInfactNm());
				obj.setLevel1(item.getLevel1());
				obj.setLevel2(item.getLevel2());
				obj.setLevel3(item.getLevel3());
				obj.setActive(true);
			} else {
				obj = new CommercialStructDetail();
				obj.setCommercialStructId(commercialStructId);
				obj.setFormatNm(item.getFormatNm());
				obj.setInfactNm(item.getInfactNm());
				obj.setLevel1(item.getLevel1());
				obj.setLevel2(item.getLevel2());
				obj.setLevel3(item.getLevel3());
				obj.setActive(true);
			}
			details.add(obj);
		}
		if (details.size() > 0) {
			commercialStructDetailRepository.save(details);
		}
		return 1;
	}

	public List<CommercialStructDetail> getCommercialStructDetails(int commercialStructId) {
		return commercialStructDetailDao.findByCommercialStructId(commercialStructId);
	}

	public List<CommercialStructDetail> getCommercialStructDetailCat(int reportId,int retailerId,int userId) {
		return commercialStructDetailDao.findByCommercialStructCat(reportId, retailerId, userId);
	}

	
	public int createCommertialStructDetail(CommercialStructDetail commercialStructDetail) {
		commercialStructDetail.setActive(true);
		return commercialStructDetailDao.create(commercialStructDetail);
	}

	public List<CommercialStructDetail> getCommercialStructDetailsByRetailers(int... retailerIds) {
		return commercialStructDetailRepository.findByRetailersId(retailerIds);
	}
	
	

	
	
	

}
