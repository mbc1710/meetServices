package com.nielsen.retailer.config.api.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "rel_user_profiles")
@Table(name = "rel_user_profiles", schema = "mars_config")
public class RelUserProfiles implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "profile_id")
	private int profileId;

	@Id
	@Column(name = "user_id")
	private int userId;

	@Column(name = "create_dt")
	private Timestamp createDt;

	public int getProfileId() {
		return profileId;
	}

	public void setProfileId(int profileId) {
		this.profileId = profileId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RelUserProfiles [profileId=");
		builder.append(profileId);
		builder.append(", userId=");
		builder.append(userId);
		builder.append(", createDt=");
		builder.append(createDt);
		builder.append("]");
		return builder.toString();
	}

}
