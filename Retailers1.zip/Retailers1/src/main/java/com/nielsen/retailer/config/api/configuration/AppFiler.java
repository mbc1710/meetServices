package com.nielsen.retailer.config.api.configuration;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import ch.qos.logback.classic.BasicConfigurator;
import org.slf4j.LoggerFactory;

public class AppFiler implements Filter {

	private final static Logger LOGGER = LoggerFactory.getLogger(BasicConfigurator.class);

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {

	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		final HttpServletResponse response = (HttpServletResponse) res;
		final HttpServletRequest request = (HttpServletRequest) req;
		String email = "empty";

		if (request.getHeader("SM_USER") != null) {
			email = request.getHeader("SM_USER").replaceAll("\"", "");
		}

		Enumeration<String> i = request.getHeaderNames();
		while (i.hasMoreElements()) {
			String element = i.nextElement();
			LOGGER.debug("header: " + element);
			LOGGER.info("header: " + element);

		}
		final Cookie cookie = new Cookie("email", email);
		cookie.setMaxAge(10);
		response.addCookie(cookie);

		chain.doFilter(req, res);

	}

	@Override
	public void destroy() {

	}

}
