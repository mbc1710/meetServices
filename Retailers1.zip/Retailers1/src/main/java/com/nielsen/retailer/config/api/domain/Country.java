package com.nielsen.retailer.config.api.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "cat_countries")
@Table(name = "cat_countries", schema = "mars_config")
public class Country implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "country_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int countryId;

	@Column(name = "country_nm")
	private String countryNm;

	@Column(name = "create_dt")
	private Timestamp createDt;

	@Column(name = "update_dt")
	private Timestamp updateDt;

	@Column(name = "is_active")
	private boolean active;

	@Column(name = "code_iso")
	private String codeIso;

	@Column(name = "short_nm")
	private String shortNm;

	public int getCountryId() {
		return countryId;
	}

	public void setCountryId(int countryId) {
		this.countryId = countryId;
	}

	public String getCountryNm() {
		return countryNm;
	}

	public void setCountryNm(String countryNm) {
		this.countryNm = countryNm;
	}

	public Timestamp getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Timestamp createDt) {
		this.createDt = createDt;
	}

	public Timestamp getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(Timestamp updateDt) {
		this.updateDt = updateDt;
	}


	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getCodeIso() {
		return codeIso;
	}

	public void setCodeIso(String codeIso) {
		this.codeIso = codeIso;
	}

	public String getShortNm() {
		return shortNm;
	}

	public void setShortNm(String shortNm) {
		this.shortNm = shortNm;
	}

	@Override
	public String toString() {
		return "Country [countryId=" + countryId + ", countryNm=" + countryNm + ", createDt=" + createDt + ", updateDt="
				+ updateDt + ", isActive=" + active + ", codeIso=" + codeIso + ", shortNm=" + shortNm + "]";
	}
	
	

}
