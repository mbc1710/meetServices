package com.nielsen.retailer.config.api.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.nielsen.retailer.config.api.dao.ReportDao;
import com.nielsen.retailer.config.api.domain.Report;

@Service
public class ReportService {

	@Autowired
	private ReportDao reportsDao;

	public List<Report> getReport() {
		return reportsDao.findAll();
	}
	
	public List<Report> getReportIsActive() {
		return reportsDao.findAllIsActive();
	}

	public Report getReportById(int id) {
		return reportsDao.findById(id);
	}

	public int createReport(Report report) {
		return reportsDao.create(report);
	}

	public int updateReport(Report report) {
		return reportsDao.update(report);
	}
	
	public int updateReportStatus(Report report) {
		return reportsDao.updateStatus(report);
	}

	public int deleteReport(Report report) {
		return reportsDao.delete(report);
	}

	public List<Report> getReportByService(int id) {
		return reportsDao.findByService(id);
	}

	public List<Report> getReportsByUserId(int userId) {
		return reportsDao.findByUser(userId);
	}
}
