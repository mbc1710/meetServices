package com.nielsen.retailer.config.api.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nielsen.retailer.config.api.dao.CommercialStructDao;
import com.nielsen.retailer.config.api.domain.CommercialStruct;

@Repository
public class CommercialStructDaoImpl implements CommercialStructDao {

	@PersistenceContext
	EntityManager em;

	final static Logger logger = LoggerFactory.getLogger(CommercialStructDaoImpl.class);

	@Override
	public List<CommercialStruct> findByService(int serviceId) {
		TypedQuery<CommercialStruct> query = em.createQuery(
				" SELECT ce FROM cat_commercial_structs ce, cat_retailers r "
			  + " WHERE ce.retailer.retailerId = r.retailerId AND r.active = true "
			  + " AND r.serviceId = :serviceId order by 1 ",
				CommercialStruct.class);
		query.setParameter("serviceId", serviceId);
		return query.getResultList();
	}

	@Override
	public CommercialStruct findById(int id) {
		TypedQuery<CommercialStruct> query = em.createQuery(
				"SELECT ce FROM cat_commercial_structs ce WHERE ce.commercialStructId = :commercialStructId order by id",
				CommercialStruct.class);
		query.setParameter("commercialStructId", id);
		List<CommercialStruct> list = query.getResultList();

		return (list == null || list.size() == 0) ? null : list.get(0);
	}
	
	@Override
	@Transactional(readOnly = false)
	public int updateStatus(CommercialStruct obj) {
		
		Boolean active = obj.isActive();
		int commercialStructId = obj.getCommercialStructId();
	
		Query query = em.createQuery("UPDATE cat_commercial_structs SET active = :active WHERE commercialStructId = :commercialStructId");
		query.setParameter("active", active);
		query.setParameter("commercialStructId", commercialStructId);
		em.flush();
		return query.executeUpdate();
	}
	
	@Override
	public CommercialStruct findByRetailerId(int retailerId) {
		TypedQuery<CommercialStruct> query = em.createQuery(
				"SELECT ce FROM cat_commercial_structs ce WHERE ce.retailer.retailerId = :retailerId order by id",
				CommercialStruct.class);
		query.setParameter("retailerId", retailerId);
		List<CommercialStruct> list = query.getResultList();

		return (list == null || list.size() == 0) ? null : list.get(0);
	}

	@Override
	public int update(CommercialStruct obj) {
		em.merge(obj);
		return 1;
	}

	@Override
	public int create(CommercialStruct obj) {
		em.persist(obj);
		return 1;
	}

}
