package com.nielsen.retailer.config.api.domain;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity(name = "cat_values")
@Table(name = "cat_values", schema = "mars_config")
public class CatValue implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "report_id")
	private int reportId;

	@Column(name = "service_id")
	private int serviceId;

	@Id
	@Column(name = "value_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int valueId;

	@Column(name = "value_external")
	private String valueExternal;

	@Column(name = "value_nm")
	private String valueNm;

	@Column(name = "value_type_id")
	private int valueTypeId;

	@Column(name = "tag_id")
	private int tagId;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "objValue")
	private List<CatValueUrl> urls;

	public CatValue() {
	}

	public int getReportId() {
		return reportId;
	}

	public void setReportId(int reportId) {
		this.reportId = reportId;
	}

	public int getServiceId() {
		return serviceId;
	}

	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}

	public int getValueId() {
		return valueId;
	}

	public void setValueId(int valueId) {
		this.valueId = valueId;
	}

	public String getValueExternal() {
		return valueExternal;
	}

	public void setValueExternal(String valueExternal) {
		this.valueExternal = valueExternal;
	}

	public String getValueNm() {
		return valueNm;
	}

	public void setValueNm(String valueNm) {
		this.valueNm = valueNm;
	}

	public int getValueTypeId() {
		return valueTypeId;
	}

	public void setValueTypeId(int valueType) {
		this.valueTypeId = valueType;
	}

	public int getTagId() {
		return tagId;
	}

	public void setTagId(int tagId) {
		this.tagId = tagId;
	}

	public List<CatValueUrl> getUrls() {
		return urls;
	}

	public void setUrls(List<CatValueUrl> urls) {
		this.urls = urls;
	}

	@Override
	public String toString() {
		return "CatValue [reportId=" + reportId + ", serviceId=" + serviceId + ", valueId=" + valueId
				+ ", valueExternal=" + valueExternal + ", valueNm=" + valueNm + ", valueType=" + valueTypeId
				+ ", tagId=" + tagId + "]";
	}

}
