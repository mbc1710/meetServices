package com.nielsen.retailer.config.api.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.nielsen.retailer.commons.api.utils.Response;
import com.nielsen.retailer.config.api.domain.User;
import com.nielsen.retailer.config.api.service.UserService;
import com.nielsen.retailer.config.api.util.MessageService;

import ch.qos.logback.classic.BasicConfigurator;

@CrossOrigin
@RestController
@RequestMapping(value = "/retailer-config-api")
public class UserController {

	final static Logger logger = LoggerFactory.getLogger(BasicConfigurator.class);

	@Autowired
	private MessageService messageSource;

	@Autowired
	private UserService userService;

	@RequestMapping(value = { "/user" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<List<User>>> getUsers() {

		List<User> users = userService.getUsers();
		Response<List<User>> response;
		String msg = "";

		if (!(users != null && users.size() > 0)) {
			msg = messageSource.getMessage("api.user.messages.1000");
		}

		response = new Response<List<User>>(users, msg);
		return new ResponseEntity<Response<List<User>>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/user/{user_id}" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<User>> getUserById(
			@PathVariable(name = "user_id", required = true) int id) {
		final String msg = messageSource.getMessage("api.user.messages.1000");
		User user = userService.getUserById(id);
		Response<User> response;

		if (user == null) {
			response = new Response<User>(user, msg);
		} else {
			response = new Response<User>(user);
		}

		return new ResponseEntity<Response<User>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/user-by-email" }, method = { RequestMethod.GET })
	public @ResponseBody ResponseEntity<Response<User>> getUserByEmail(@RequestHeader String email) {
		
		String msg ="";
		User user = userService.getUserByEmail(email);
		Response<User> response;

		if (user == null) {
			msg = messageSource.getMessage("api.user.messages.1004");
		} else {
			msg = messageSource.getMessage("api.user.messages.1008");
		}

		response = new Response<User>(user, msg);
		return new ResponseEntity<Response<User>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/user" }, method = { RequestMethod.POST })
	public @ResponseBody ResponseEntity<Response<Integer>> createUser(@RequestBody User user) {
		String msg = "";
		int result = userService.createUser(user);
		Response<Integer> response;

		if (result != 1) {
			msg = messageSource.getMessage("api.user.messages.1001");
		} else {
			msg = messageSource.getMessage("api.user.messages.1005");
		}

		response = new Response<Integer>(result, msg);

		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/user" }, method = { RequestMethod.PUT })
	public @ResponseBody ResponseEntity<Response<Integer>> updateUser(@RequestBody User user) {
		String msg = "";
		int result = userService.updateUser(user);
		Response<Integer> response;

		if (result != 1) {
			msg = messageSource.getMessage("api.user.messages.1002");
		} else {
			msg = messageSource.getMessage("api.user.messages.1006");
		}

		response = new Response<Integer>(result, msg);

		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}
	
	@RequestMapping(value = { "/user-status" }, method = { RequestMethod.PUT })
	public @ResponseBody ResponseEntity<Response<Integer>> updateUserStatus(@RequestBody User user) {
		String msg = "";
		int result = userService.updateUserStatus(user);
		Response<Integer> response;
	if (result != 1) {
			msg = messageSource.getMessage("api.user.messages.1002");
		} else {
			msg = messageSource.getMessage("api.user.messages.1006");
		}

		response = new Response<Integer>(result, msg);

		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}

	@RequestMapping(value = { "/user" }, method = { RequestMethod.DELETE })
	public @ResponseBody ResponseEntity<Response<Integer>> deleteUser(@RequestBody User user) {
		String msg = "";
		int result = userService.deleteUser(user);
		Response<Integer> response;

		if (result != 1) {
			msg = messageSource.getMessage("api.user.messages.1003");
		} else {
			msg = messageSource.getMessage("api.user.messages.1007");
		}

		response = new Response<Integer>(result, msg);

		return new ResponseEntity<Response<Integer>>(response, HttpStatus.valueOf(response.getStatus()));
	}

}
