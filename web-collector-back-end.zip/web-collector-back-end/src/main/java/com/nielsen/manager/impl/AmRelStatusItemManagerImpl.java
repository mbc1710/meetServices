package com.nielsen.manager.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.nielsen.dao.AmRelStatusItemDAO;
import com.nielsen.dto.ItemList;
import com.nielsen.manager.AmRelStatusItemManager;

@Service
public class AmRelStatusItemManagerImpl implements AmRelStatusItemManager{
	
	private AmRelStatusItemDAO amRelStatusItemDAO;

	public AmRelStatusItemManagerImpl(AmRelStatusItemDAO amRelStatusItemDAO) {
		this.amRelStatusItemDAO = amRelStatusItemDAO;
	}
	
	public List<ItemList> getItems(Long ciId, Integer periodId){
		return this.amRelStatusItemDAO.getItemsList(ciId, periodId);
		
	}

}
