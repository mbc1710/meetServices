package com.nielsen.manager;

import java.util.List;

import com.nielsen.dto.ItemList;

public interface AmRelStatusItemManager {
	public List<ItemList> getItems(Long ciId, Integer periodId);

}
