package com.nielsen.manager.impl;

import org.springframework.stereotype.Service;

import com.nielsen.dao.AmRelStoreConversationDAO;
import com.nielsen.manager.AmRelStoreConversationManager;

@Service
public class AmRelStoreConversationManagerImpl implements AmRelStoreConversationManager{
	
	private AmRelStoreConversationDAO amRelStoreConversationDAO;

	public AmRelStoreConversationManagerImpl(AmRelStoreConversationDAO amRelStoreConversationDAO) {
		this.amRelStoreConversationDAO = amRelStoreConversationDAO;
	}
	
	public int saveConversation(Integer countryId, Long ciId, String conversationMsg, Integer userId) {
		return this.amRelStoreConversationDAO.insertConversation(countryId, ciId, conversationMsg, userId);
	}

}
