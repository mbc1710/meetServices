package com.nielsen.manager.impl;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nielsen.dao.AmRelStatusStoreDAO;
import com.nielsen.manager.AmRelStatusStoreManager;

@Service

public class AmRelStatusStoreManagerImpl implements AmRelStatusStoreManager{

	private AmRelStatusStoreDAO amRelStatusStoreDAO;

	public AmRelStatusStoreManagerImpl(AmRelStatusStoreDAO amRelStatusStoreDAO) {
		this.amRelStatusStoreDAO = amRelStatusStoreDAO;
	}
	@Transactional
	public void updateStatusStore(Integer newSatusId, Long ciId, Integer periodId){
		this.amRelStatusStoreDAO.updateStatusStore(newSatusId, ciId, periodId);
	}
}
