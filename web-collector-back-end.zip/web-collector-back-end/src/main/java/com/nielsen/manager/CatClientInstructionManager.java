package com.nielsen.manager;

import java.util.List;

import com.nielsen.dto.CatClientInstruction;
import com.nielsen.dto.CiCatClientInstruction;

public interface CatClientInstructionManager {

	List<CiCatClientInstruction> listAll();

	CiCatClientInstruction findOneById(Integer id);
	
	public List<CatClientInstruction> listAllByCountryIdAndUserId(Integer countryId, String userId);
}
