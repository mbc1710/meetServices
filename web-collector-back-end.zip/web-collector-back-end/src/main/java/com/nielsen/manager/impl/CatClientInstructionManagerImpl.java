package com.nielsen.manager.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.nielsen.dao.CatClientInstructionDAO;
import com.nielsen.dto.CatClientInstruction;
import com.nielsen.dto.CiCatClientInstruction;
import com.nielsen.dto.CiCatCountry;
import com.nielsen.manager.CatClientInstructionManager;
@Service
public class CatClientInstructionManagerImpl implements CatClientInstructionManager {
	
	private CatClientInstructionDAO catClientInstructionDAO;

	public CatClientInstructionManagerImpl(CatClientInstructionDAO catClientInstructionDAO) {
		this.catClientInstructionDAO = catClientInstructionDAO;
	}

	@Override
	public List<CiCatClientInstruction> listAll() {
		
		//return catClientInstructionDAO.findAll();
		return null;
	}

	@Override
	public CiCatClientInstruction findOneById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public List<CatClientInstruction> listAllByCountryIdAndUserId(Integer countryId, String userId){
		return catClientInstructionDAO.findAllByCountryIdAndUserId(countryId, userId);
	}

}
