package com.nielsen.manager;

import java.util.List;

import com.nielsen.dto.RdDimPeriod;

public interface DimPeriodManager {

	List<RdDimPeriod> listAll();

	RdDimPeriod findOneById(Integer id);
	
	public List<RdDimPeriod> listAllByCiId(Long ciId);
}
