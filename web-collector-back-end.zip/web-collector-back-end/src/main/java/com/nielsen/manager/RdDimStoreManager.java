package com.nielsen.manager;

import java.util.List;

import com.nielsen.dto.StoreList;

public interface RdDimStoreManager {

	public List<StoreList> findStores(Integer countryId, Long ciId, Integer statusId, Integer periodId);
}
