package com.nielsen.manager.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.nielsen.dao.RdDimStoreDAO;
import com.nielsen.dao.TestDAO;
import com.nielsen.dto.StoreList;
import com.nielsen.manager.RdDimStoreManager;

@Service
public class RdDimStoreManagerImpl implements RdDimStoreManager{
	
	private RdDimStoreDAO rdDimStoreDAO;
	private TestDAO testDAO;

	public RdDimStoreManagerImpl(RdDimStoreDAO rdDimStoreDAO, TestDAO testDAO) {
		this.rdDimStoreDAO = rdDimStoreDAO;
		this.testDAO = testDAO;
	}
	
	public List<StoreList> findStores(Integer countryId, Long ciId, Integer statusId, Integer periodId){
		this.testDAO.test();
		return rdDimStoreDAO.findAllByCountryAndCIAndPeriodAndStatusId(countryId, ciId, statusId, periodId);
	}
}
