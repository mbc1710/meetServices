package com.nielsen.manager.impl;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.nielsen.dao.CatStatusStoreDAO;
import com.nielsen.dto.AmCatStatusStore;
import com.nielsen.manager.CatStatusStoreManager;

@Service
public class CatStatusStoreManagerImpl implements CatStatusStoreManager {

	private CatStatusStoreDAO catStatusStoreDAO;
	
	public CatStatusStoreManagerImpl(CatStatusStoreDAO catStatusStoreDAO) {
		this.catStatusStoreDAO = catStatusStoreDAO;
	}
	@Override
	public List<AmCatStatusStore> findAll() {
		return catStatusStoreDAO.findAll(new Sort(Sort.Direction.ASC, "statusDesc"));
	}

	@Override
	public AmCatStatusStore findOneById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

}
