package com.nielsen.manager.impl;


import org.springframework.stereotype.Service;

import com.nielsen.dao.SecCatUserDAO;
import com.nielsen.dto.SecCatUser;
import com.nielsen.manager.SecCatUserManager;

@Service
public class SecCatUserManagerImpl implements SecCatUserManager {
	
	private SecCatUserDAO secCatUserDAO ;

	public SecCatUserManagerImpl(SecCatUserDAO secCatUserDAO) {
		this.secCatUserDAO = secCatUserDAO;
	}
	
	public SecCatUser login(String userId, String pwd){
		return this.secCatUserDAO.findAllByUserIdAndPwd(userId, pwd);
	}

}
