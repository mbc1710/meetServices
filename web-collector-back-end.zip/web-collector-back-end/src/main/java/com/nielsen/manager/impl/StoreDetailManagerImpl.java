package com.nielsen.manager.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.nielsen.dao.StoreDetailDAO;
import com.nielsen.dto.StoreDetailList;
import com.nielsen.manager.StoreDetailManager;

@Service
public class StoreDetailManagerImpl implements StoreDetailManager {

	private StoreDetailDAO storeDetailJdbcTemplateDAO;

	public StoreDetailManagerImpl(StoreDetailDAO storeDetailJdbcTemplateDAO) {
		this.storeDetailJdbcTemplateDAO = storeDetailJdbcTemplateDAO;
	}
	
	public List<StoreDetailList> getStoreDetails(Long ciId, Integer periodId, Integer storeId){
		return this.storeDetailJdbcTemplateDAO.getStoreDetails(ciId, periodId, storeId);
		
	}
}
