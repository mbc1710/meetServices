package com.nielsen.manager.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.nielsen.dao.DimPeriodDAO;
import com.nielsen.dto.RdDimPeriod;
import com.nielsen.manager.DimPeriodManager;
@Service
public class DimPeriodManagerImpl implements DimPeriodManager {
	
	private DimPeriodDAO dimPeriodDAO;

	public DimPeriodManagerImpl(DimPeriodDAO dimPeriodDAO) {
		this.dimPeriodDAO = dimPeriodDAO;
	}

	@Override
	public List<RdDimPeriod> listAll() {
		return dimPeriodDAO.findAll();
	}

	@Override
	public RdDimPeriod findOneById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public List<RdDimPeriod> listAllByCiId(Long ciId) {
		return dimPeriodDAO.findAllByCiId(ciId);
	}

}
