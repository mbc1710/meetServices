package com.nielsen.manager;

import java.util.List;

import com.nielsen.dto.AmCatStatusStore;

public interface CatStatusStoreManager {

	List<AmCatStatusStore> findAll();

	AmCatStatusStore findOneById(Integer id);
}
