package com.nielsen.manager;

public interface AmRelStatusStoreManager {
	
	public void updateStatusStore(Integer newSatusId, Long ciId, Integer periodId);

}
