package com.nielsen.manager;

import java.util.List;

import com.nielsen.dto.CatCountry;

public interface CatCountryManager {
	
	List<CatCountry> findAll();

	Object findOneById(Integer id);
	
	public List<CatCountry> findAllByUserId(String userId);
}
