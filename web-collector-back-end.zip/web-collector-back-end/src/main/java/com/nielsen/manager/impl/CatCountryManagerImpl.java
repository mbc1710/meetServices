package com.nielsen.manager.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.nielsen.dao.CatCountryDAO;
import com.nielsen.dto.CatCountry;
import com.nielsen.manager.CatCountryManager;
@Service
public class CatCountryManagerImpl implements CatCountryManager {
	
	private CatCountryDAO catCountryDAO;

	public CatCountryManagerImpl(CatCountryDAO catCountryDAO) {
		this.catCountryDAO = catCountryDAO;
	}

	@Override
	public List<CatCountry> findAll() {
		return catCountryDAO.findAll();
		//return null;
	}

	@Override
	public Object findOneById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}
	public List<CatCountry> findAllByUserId(String userId) {
		return catCountryDAO.listByUserId(userId);
	}
	

}
