package com.nielsen.manager;

import com.nielsen.dto.SecCatUser;

public interface SecCatUserManager {
	
	public SecCatUser login(String userId, String pwd);

}
