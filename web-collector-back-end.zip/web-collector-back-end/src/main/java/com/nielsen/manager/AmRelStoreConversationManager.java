package com.nielsen.manager;

public interface AmRelStoreConversationManager {

	public int saveConversation(Integer countryId, Long ciId, String conversationMsg, Integer userId);
}
