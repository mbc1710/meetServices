package com.nielsen.configuration;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;

@Configuration
public class DBConfiguration {

	@Primary 
	@Bean(name = "postgresDb")
	@ConfigurationProperties(prefix = "spring.datasource")
	public DataSource postgresDataSource() {
		return DataSourceBuilder.create().build();
	}

	@Primary
	@Bean(name = "postgresJdbcTemplate")
	public JdbcTemplate postgresJdbcTemplate(@Qualifier("postgresDb") DataSource dsPostgres) {
		return new JdbcTemplate(dsPostgres);
	}

	@Bean(name = "impalaDb")
	@ConfigurationProperties(prefix = "spring.datasource.impala")
	public DataSource impalaDataSource() {
		return DataSourceBuilder.create().build();
	}

	@Bean(name = "impalaJdbcTemplate")
	public JdbcTemplate impalaJdbcTemplate(@Qualifier("impalaDb") DataSource dsImpala) {
		return new JdbcTemplate(dsImpala);
	}

}
