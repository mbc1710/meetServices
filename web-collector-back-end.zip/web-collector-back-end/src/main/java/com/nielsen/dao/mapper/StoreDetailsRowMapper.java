package com.nielsen.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.nielsen.dto.StoreDetailList;

public class StoreDetailsRowMapper implements RowMapper<StoreDetailList>{
	
	@Override
	public StoreDetailList mapRow(ResultSet rs, int rowNum) throws SQLException {
		StoreDetailList storeDetailList = new StoreDetailList();
		storeDetailList.setCiId(rs.getInt("ciId"));
		storeDetailList.setPeriodId(rs.getInt("periodId"));
		storeDetailList.setStoreId(rs.getInt("storeId"));
		storeDetailList.setCharId(rs.getInt("charId"));
		storeDetailList.setCharValId(rs.getInt("charValId"));
		storeDetailList.setCharName(rs.getString("charName"));
		storeDetailList.setCharValName(rs.getString("charValName"));
		return storeDetailList;
	}

}
