package com.nielsen.dao.impl;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nielsen.dao.StoreDetailDAO;
import com.nielsen.dao.mapper.StoreDetailsRowMapper;
import com.nielsen.dto.StoreDetailList;

@Repository
public class StoreDetailDAOImpl implements StoreDetailDAO{

	private JdbcTemplate jdbcTemplate;

	public StoreDetailDAOImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public List<StoreDetailList> getStoreDetails(Long ciId, Integer periodId, Integer storeId) {
		String sql = "select a.ci_id ciId, b.period_id periodId, a.store_id storeid, b.char_id charId, "
				+ " b.char_val_id charValId, c.char_name charName, d.char_val_name charValName "
				+ " from so_rd.rd_dim_store a " + "  inner join so_rd.rd_rel_store_char_val b "
				+ "  on a.ci_id = b.ci_id " + "  and a.store_id = b.store_id "
				+ "  INNER JOIN so_rd.rd_cat_store_char c " + "  on b.ci_id = c.ci_id " + "  and b.char_id = c.char_id "
				+ "  inner join so_rd.rd_cat_store_char_val d " + "  on b.ci_id = d.ci_id "
				+ "  and b.char_id = d.char_id " + "  and b.char_val_id = d.char_val_id " + " where a.ci_id = " + ciId
				+ " and b.period_id = " + periodId + " and a.store_id = " + storeId;
		return this.jdbcTemplate.query(sql, new StoreDetailsRowMapper());
	}
}
