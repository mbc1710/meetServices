package com.nielsen.dao;

import java.util.List;

import com.nielsen.dto.StoreList;

public interface RdDimStoreDAO {

	public List<StoreList> findAllByCountryAndCIAndPeriodAndStatusId(Integer countryId, Long ci_id, Integer statusId, Integer periodId);

}
