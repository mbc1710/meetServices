package com.nielsen.dao;

import java.util.List;

import com.nielsen.dto.StoreDetailList;

public interface StoreDetailDAO {
	
	public List<StoreDetailList> getStoreDetails(Long ciId, Integer periodId, Integer storeId);

}
