package com.nielsen.dao;

import java.util.List;

import com.nielsen.dto.CatClientInstruction;


public interface CatClientInstructionDAO {
	
	List<CatClientInstruction> findAllByCountryIdAndUserId(Integer countryId, String userId);

}
