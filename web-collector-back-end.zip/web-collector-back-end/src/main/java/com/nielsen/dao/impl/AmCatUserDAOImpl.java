package com.nielsen.dao.impl;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nielsen.dao.AmCatUserDAO;
import com.nielsen.dao.mapper.AnalystListRowMapper;
import com.nielsen.dto.AnalystList;

@Repository
public class AmCatUserDAOImpl implements AmCatUserDAO {

	private JdbcTemplate jdbcTemplate;

	public AmCatUserDAOImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public List<AnalystList> getAnalysts() {
		String sql = "select a.user_id userId, a.user_name userName, b.user_role_desc userRoleDesc"
				+ " from so_web_collector.am_cat_user a " + "     inner join so_web_collector.am_cat_role b "
				+ "  on a.user_role_id = b.user_role_id " + " where a.active = true " + " and b.active = true";
		return this.jdbcTemplate.query(sql, new AnalystListRowMapper());
	}

}
