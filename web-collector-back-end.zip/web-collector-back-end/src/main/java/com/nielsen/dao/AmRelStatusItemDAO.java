package com.nielsen.dao;

import java.util.List;
import com.nielsen.dto.ItemList;

public interface AmRelStatusItemDAO {
	
	public List<ItemList> getItemsList(Long ciId, Integer periodId);
	

}
