package com.nielsen.dao;

public interface TestDAO {
	public void test();

}
