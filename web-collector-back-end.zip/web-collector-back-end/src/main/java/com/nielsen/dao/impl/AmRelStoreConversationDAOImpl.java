package com.nielsen.dao.impl;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nielsen.dao.AmRelStoreConversationDAO;

@Repository
public class AmRelStoreConversationDAOImpl implements AmRelStoreConversationDAO {

	private JdbcTemplate jdbcTemplate;

	public AmRelStoreConversationDAOImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public int insertConversation(Integer countryId, Long ciId, String conversationMsg, Integer userId) {
		String sql = "insert into so_web_collector.am_rel_store_conversation(country_id, ci_id, conversation_id, conversation_desc, active, user_id, insert_date) "
				+ " VALUES(?, ?, ?, ?, true, ?, current_timestamp)";
		int converId= this.getMaxConversationId();
		return this.jdbcTemplate.update(sql, new Object[] {countryId, ciId, converId, conversationMsg, userId});

	}
	private int getMaxConversationId(){
		String sql = "select COALESCE(max(conversation_id), 0) + 1 from so_web_collector.am_rel_store_conversation";
		return this.jdbcTemplate.queryForObject(sql, Integer.class);
	}
}
