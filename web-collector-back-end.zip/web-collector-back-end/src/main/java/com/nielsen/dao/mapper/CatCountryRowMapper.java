package com.nielsen.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.nielsen.dto.CatCountry;

public class CatCountryRowMapper implements RowMapper<CatCountry>{

	@Override
	public CatCountry mapRow(ResultSet rs, int arg1) throws SQLException {
		CatCountry ciCatCountry = new CatCountry();
		ciCatCountry.setCountryId(rs.getInt("countryId"));
		ciCatCountry.setCountryDesc(rs.getString("countryDesc"));
		return ciCatCountry;
	}

}
