package com.nielsen.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.nielsen.dto.ItemList;

public class ItemListRowMapper implements RowMapper<ItemList>{

	@Override
	public ItemList mapRow(ResultSet rs, int rowNum) throws SQLException {
		ItemList itemList = new ItemList();
		itemList.setBarCode(rs.getString("barCode"));
		itemList.setCiId(rs.getLong("ciId"));
		itemList.setCountryId(rs.getInt("countryId"));
		itemList.setItemName(rs.getString("itemName"));
		return itemList;
	}

}
