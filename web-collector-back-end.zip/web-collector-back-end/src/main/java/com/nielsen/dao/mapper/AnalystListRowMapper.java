package com.nielsen.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.nielsen.dto.AnalystList;

public class AnalystListRowMapper implements RowMapper<AnalystList> {

	@Override
	public AnalystList mapRow(ResultSet rs, int rowNum) throws SQLException {
		AnalystList analystList = new AnalystList();
		analystList.setUserId(rs.getString("userId"));
		analystList.setUserName(rs.getString("userName"));
		analystList.setUserRoleDesc(rs.getString("userRoleDesc"));
		return analystList;
	}
}
