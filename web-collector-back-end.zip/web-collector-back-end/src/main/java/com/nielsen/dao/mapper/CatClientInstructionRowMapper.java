package com.nielsen.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.nielsen.dto.CatClientInstruction;

public class CatClientInstructionRowMapper implements RowMapper<CatClientInstruction>{

	@Override
	public CatClientInstruction mapRow(ResultSet rs, int arg1) throws SQLException {
		CatClientInstruction catClientInstruction = new CatClientInstruction();
		catClientInstruction.setClientId(rs.getInt("clientId"));
		catClientInstruction.setCountryId(rs.getInt("countryId"));
		catClientInstruction.setDescription(rs.getString("description"));
		catClientInstruction.setId(rs.getLong("id"));
		catClientInstruction.setServiceId(rs.getInt("serviceId"));
		catClientInstruction.setRoleId(rs.getInt("roleId"));
		return catClientInstruction;
	}

}
