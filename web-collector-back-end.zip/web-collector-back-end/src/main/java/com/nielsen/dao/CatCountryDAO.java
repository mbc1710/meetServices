package com.nielsen.dao;

import java.util.List;

import com.nielsen.dto.CatCountry;

public interface CatCountryDAO  {

	public List<CatCountry> listByUserId(String userId);
	public List<CatCountry> findAll();

}
