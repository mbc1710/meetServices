package com.nielsen.dao.impl;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nielsen.dao.TestDAO;

@ConfigurationProperties("classpath:application-dev.properties")
@Repository
public class TestDaAOImpl implements TestDAO{
	
	private JdbcTemplate jdbcTemplate;

	public TestDaAOImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public void test(){
		System.out.println("Entré");
		jdbcTemplate.execute("select * from rel_TransferSetPeriodTransfer");
	}

}
