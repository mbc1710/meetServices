package com.nielsen.dao.impl;

import org.springframework.jdbc.core.JdbcTemplate;

public class SecUserDAOImpl {
	
	private JdbcTemplate jdbcTemplate;
	
	public SecUserDAOImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public void doLogin(String userId, String pwd){
		String sql = " select count(1) "
				+ " from so_security.sec_cat_user  "
				+ " where user_id = " + userId
				+ "  and psw = " + pwd;
		
		
	}

}
