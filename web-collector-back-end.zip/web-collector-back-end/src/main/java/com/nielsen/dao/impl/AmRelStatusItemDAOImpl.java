package com.nielsen.dao.impl;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nielsen.dao.AmRelStatusItemDAO;
import com.nielsen.dao.mapper.ItemListRowMapper;
import com.nielsen.dto.ItemList;

@Repository
public class AmRelStatusItemDAOImpl implements AmRelStatusItemDAO{

	private JdbcTemplate jdbcTemplate;

	public AmRelStatusItemDAOImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public List<ItemList> getItemsList(Long ciId, Integer periodId) {
		String sql = "select a.country_id, a.ci_id, b.bar_code, b.item_name "
				+ " from so_web_collector.am_rel_status_item a " + "     inner join so_rd.rd_dim_item b "
				+ "     on a.ci_id = b.ci_id " + "     and a.barcode = b.bar_code " + " where a.ci_id = ? "
				+ " and period_id = ? ";
		return this.jdbcTemplate.query(sql, new ItemListRowMapper(), new Object[]{ciId, periodId});
	}

}
