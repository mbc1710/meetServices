package com.nielsen.dao.impl;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nielsen.dao.CatCountryDAO;
import com.nielsen.dao.mapper.CatCountryRowMapper;
import com.nielsen.dto.CatCountry;

@Repository
public class CatCountryDAOImpl implements CatCountryDAO {
	
	private JdbcTemplate jdbcTemplate;

	public CatCountryDAOImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	public List<CatCountry> listByUserId(String userId){
		String sql = "select a.country_id countryId, a.country_desc countryDesc "
				+ "from public.ci_cat_country a inner join so_security.sec_rel_user_role b on a.country_id = b.country_id "
			       +" where b.user_id = '" +  userId + "'";
		return this.jdbcTemplate.query(sql, new CatCountryRowMapper());
	}
	public List<CatCountry> findAll(){
		String sql = "select a.country_id countryId, a.country_desc countryDesc "
				+ "from public.ci_cat_country a ";
		return this.jdbcTemplate.query(sql, new CatCountryRowMapper());
	}
	

}
