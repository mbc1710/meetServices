package com.nielsen.dao;

public interface AmRelStatusStoreDAO {

	int updateStatusStore(Integer newStatusId, Long ciId, Integer periodId);

}
