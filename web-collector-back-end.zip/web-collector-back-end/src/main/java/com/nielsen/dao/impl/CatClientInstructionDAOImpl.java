package com.nielsen.dao.impl;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nielsen.dao.CatClientInstructionDAO;
import com.nielsen.dao.mapper.CatClientInstructionRowMapper;
import com.nielsen.dto.CatClientInstruction;

@Repository
public class CatClientInstructionDAOImpl implements CatClientInstructionDAO{

	private JdbcTemplate jdbcTemplate;

	public CatClientInstructionDAOImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public List<CatClientInstruction> findAllByCountryIdAndUserId(Integer countryId, String userId) {
		String sql = "select a.ci_id id, a.service_id serviceId, a.client_id clientId, a.country_id countryId, a.ci_desc description, role_id roleId"
				+ " from public.ci_cat_client_instruction a "
				+ " inner join so_security.sec_rel_user_role b " + "    on a.ci_id = b.ci_id "
				+ " where a.active = true " + " and b.user_id = '"+ userId +"' and a.country_id=" + countryId;
		return this.jdbcTemplate.query(sql,new CatClientInstructionRowMapper());

	}

}
