package com.nielsen.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nielsen.dto.SecCatUser;

public interface SecCatUserDAO extends JpaRepository<SecCatUser, Integer> {

	SecCatUser findAllByUserIdAndPwd(String userId, String pwd);
}
