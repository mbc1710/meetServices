package com.nielsen.dao;

import java.util.List;

import com.nielsen.dto.AnalystList;

public interface AmCatUserDAO  {
	
	public List<AnalystList> getAnalysts();

}
