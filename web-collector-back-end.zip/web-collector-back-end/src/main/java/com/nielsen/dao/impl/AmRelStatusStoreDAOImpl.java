package com.nielsen.dao.impl;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nielsen.dao.AmRelStatusStoreDAO;

@Repository
public class AmRelStatusStoreDAOImpl implements AmRelStatusStoreDAO{

	private JdbcTemplate jdbcTemplate;

	public AmRelStatusStoreDAOImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public int updateStatusStore(Integer newStatusId, Long ciId, Integer periodId) {
		String sql = "UPDATE so_web_collector.am_rel_status_store SET status_id = ? "
				+ "where ci_id = ? and period_id = ?";
		return this.jdbcTemplate.update(sql, new Object[] { newStatusId, ciId, periodId });

	}

}
