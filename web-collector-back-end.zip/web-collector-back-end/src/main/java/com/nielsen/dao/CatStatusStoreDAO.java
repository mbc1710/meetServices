package com.nielsen.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nielsen.dto.AmCatStatusStore;

public interface CatStatusStoreDAO extends JpaRepository<AmCatStatusStore, Integer> {

}
