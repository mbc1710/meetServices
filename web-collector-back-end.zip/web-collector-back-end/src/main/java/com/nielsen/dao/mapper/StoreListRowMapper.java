package com.nielsen.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.jdbc.core.RowMapper;

import com.nielsen.dto.StoreList;

public class StoreListRowMapper implements RowMapper<StoreList>{

	@Override
	public StoreList mapRow(ResultSet rs, int rowNum) throws SQLException {
		StoreList storeList = new StoreList();
		storeList.setAuditDate(this.convertStringToDate(rs.getInt("auditDate")));
		storeList.setAuditorName(rs.getString("auditorName"));
		storeList.setCiId(rs.getInt("ciId"));
		storeList.setCountryId(rs.getInt("countryId"));
		storeList.setStatusDesc(rs.getString("statusDesc"));
		storeList.setStatusId(rs.getInt("statusId"));
		storeList.setStoreId(rs.getInt("storeId"));
		storeList.setStoreName(rs.getString("storeName"));
		storeList.setUserName(rs.getString("userName"));
		storeList.setPeriodId(rs.getInt("periodId"));
		return storeList;
	}
	@SuppressWarnings("deprecation")
	private String convertStringToDate(int date){
		String dateS = String.valueOf(date);
		Integer day = Integer.parseInt(dateS.substring(4));
		Integer year = Integer.parseInt(dateS.substring(0,2));
		Integer month = Integer.parseInt(dateS.substring(2, 4));
		month = month - 1 ;
		SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy");
		Date dat =  new Date();
		dat.setYear(year+100);
		dat.setMonth(month);
		dat.setDate(day);
		return sdf.format(dat);
	}

}
