package com.nielsen.dao;

public interface AmRelStoreConversationDAO {
	
	public int insertConversation(Integer countryId, Long ciId, String conversationMsg, Integer userId);

}
