package com.nielsen.dao.impl;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nielsen.dao.RdDimStoreDAO;
import com.nielsen.dao.mapper.StoreListRowMapper;
import com.nielsen.dto.StoreList;

@Repository
public class RdDimStoreDAOImpl implements RdDimStoreDAO {

	private JdbcTemplate jdbcTemplate;

	public RdDimStoreDAOImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public List<StoreList> findAllByCountryAndCIAndPeriodAndStatusId(Integer countryId, Long ci_id, Integer statusId, Integer periodId) {
		String sqlStatus = "" ;
		if(statusId != -1){
			sqlStatus = " and a.status_id = " + statusId;
		}
		String sql = "select a.ci_id ciId, a.country_id countryId, a.auditdate auditDate, a.store_id storeId, b.store_name storeName, "
				+ " a.status_id statusId, c.status_desc statusDesc, a.auditorName auditorName, d.user_name userName, a.period_id periodId "
				+ " from so_web_collector.rel_status_store_temp a " + " inner join so_rd.rd_dim_store b "
				+ " on a.ci_id = b.ci_id " + " and a.store_id = b.store_id    "
				+ " inner join so_web_collector.am_cat_status_store c " + " on a.status_id = c.status_id "
				+ " inner join so_web_collector.am_cat_user d " + " on a.analyst_id = d.user_id "
				+ " where a.country_id = " + countryId + " and a.ci_id = " + ci_id + " and a.period_id = " + periodId;
		sql = sql + sqlStatus;

		return this.jdbcTemplate.query(sql, new StoreListRowMapper());
	}
}
