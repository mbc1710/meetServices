package com.nielsen.controller.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nielsen.dto.AmCatStatusStore;
import com.nielsen.manager.CatStatusStoreManager;

@RestController
@CrossOrigin
@RequestMapping("/web-collector/status-store")
public class ApiCatStatusStoreController {
	
	private final CatStatusStoreManager catStatusStoreManager;

	@Autowired
	ApiCatStatusStoreController(CatStatusStoreManager catStatusStoreManager) {
		this.catStatusStoreManager = catStatusStoreManager;
	}
	
	@RequestMapping(method = RequestMethod.GET)
	public List<AmCatStatusStore> list() {	
		return this.catStatusStoreManager.findAll();
	}

}
