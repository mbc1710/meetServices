package com.nielsen.controller.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nielsen.dto.RdDimPeriod;
import com.nielsen.manager.DimPeriodManager;

@RestController
@CrossOrigin
@RequestMapping("/web-collector/period")
public class ApiDimPeriodController {
	
	private DimPeriodManager dimPeriodManager;

	@Autowired
	public ApiDimPeriodController(DimPeriodManager dimPeriodManager) {
		this.dimPeriodManager = dimPeriodManager;
	}	
	@RequestMapping(method = RequestMethod.GET)
	public List<RdDimPeriod> getAll() {	
		return this.dimPeriodManager.listAll();
	}
	@RequestMapping(method = RequestMethod.GET, value = "/{ciId}")
	public List<RdDimPeriod> getByCountryId(@PathVariable Long ciId) {	
		return this.dimPeriodManager.listAllByCiId(ciId);
	}
	

}
