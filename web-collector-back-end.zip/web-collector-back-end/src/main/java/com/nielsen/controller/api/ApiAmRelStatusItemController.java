package com.nielsen.controller.api;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nielsen.dto.ItemList;
import com.nielsen.manager.AmRelStatusItemManager;

@RestController
@CrossOrigin
@RequestMapping("/web-collector/item")
public class ApiAmRelStatusItemController {

	private AmRelStatusItemManager amRelStatusItemManager;

	public ApiAmRelStatusItemController(AmRelStatusItemManager amRelStatusItemManager) {
		this.amRelStatusItemManager = amRelStatusItemManager;
	}
	@RequestMapping(method = RequestMethod.GET, value="/ciId/{ciId}/periodId/{periodId}")
	public List<ItemList> getItems(@PathVariable Long ciId, @PathVariable Integer periodId){
		return this.amRelStatusItemManager.getItems(ciId, periodId);
	}
}
