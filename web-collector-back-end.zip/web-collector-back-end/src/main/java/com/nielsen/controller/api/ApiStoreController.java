package com.nielsen.controller.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nielsen.dto.StoreDetailList;
import com.nielsen.dto.StoreList;
import com.nielsen.manager.RdDimStoreManager;
import com.nielsen.manager.StoreDetailManager;

@RestController
@CrossOrigin
@RequestMapping("/web-collector/store")
public class ApiStoreController {

	private RdDimStoreManager rdDimStoreManager;
	private StoreDetailManager storeDetailManager;

	@Autowired
	public ApiStoreController(RdDimStoreManager rdDimStoreManager, StoreDetailManager storeDetailManager) {
		this.rdDimStoreManager = rdDimStoreManager;
		this.storeDetailManager = storeDetailManager;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/countryId/{countryId}/ciId/{ciId}/periodId/{periodId}/statusId/{statusId}")
	public List<StoreList> getStores(@PathVariable Integer countryId, @PathVariable Long ciId,
			@PathVariable Integer periodId, @PathVariable Integer statusId) {
		return this.rdDimStoreManager.findStores(countryId, ciId, statusId, periodId);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/detail/ciId/{ciId}/periodId/{periodId}/storeId/{storeId}")
	public List<StoreDetailList> getStoreDetail(@PathVariable Long ciId, @PathVariable Integer periodId,
			@PathVariable Integer storeId) {
		return this.storeDetailManager.getStoreDetails(ciId, periodId, storeId);
	}

}
