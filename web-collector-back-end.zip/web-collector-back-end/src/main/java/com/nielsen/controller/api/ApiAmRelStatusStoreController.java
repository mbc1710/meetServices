package com.nielsen.controller.api;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nielsen.manager.AmRelStatusStoreManager;

@RestController
@CrossOrigin
@RequestMapping("/web-collector/status-store")
public class ApiAmRelStatusStoreController {
	
	private AmRelStatusStoreManager amRelStatusStoreManager;

	public ApiAmRelStatusStoreController(AmRelStatusStoreManager amRelStatusStoreManager) {
		this.amRelStatusStoreManager = amRelStatusStoreManager;
	}
	//Integer newSatusId, Long ciId, Integer periodId
	@RequestMapping(method = RequestMethod.PUT, value="/newStatusId/{newSatusId}/ciId/{ciId}/periodId/{periodId}")
	public void updateStatusStore(Integer newSatusId, Long ciId, Integer periodId){
		this.amRelStatusStoreManager.updateStatusStore(newSatusId, ciId, periodId);
	}
}
