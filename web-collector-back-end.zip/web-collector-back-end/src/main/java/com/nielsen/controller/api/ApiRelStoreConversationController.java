package com.nielsen.controller.api;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nielsen.manager.AmRelStoreConversationManager;

@RestController
@CrossOrigin
@RequestMapping("/web-collector/conversation")
public class ApiRelStoreConversationController {
	
	private AmRelStoreConversationManager amRelStoreConversationManager;

	public ApiRelStoreConversationController(AmRelStoreConversationManager amRelStoreConversationManager) {
		this.amRelStoreConversationManager = amRelStoreConversationManager;
	}
	
	@RequestMapping(method = RequestMethod.POST, value="/countryId/{countryId}/ciId/{ciId}/conversationMsg/{conversationMsg}/userId/{userId}")
	public Integer updateStatusStore(@PathVariable Integer countryId, @PathVariable Long ciId, @PathVariable String conversationMsg, @PathVariable Integer userId){
		return this.amRelStoreConversationManager.saveConversation(countryId, ciId, conversationMsg, userId);
	}

}
