package com.nielsen.controller.api;


import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nielsen.dto.SecCatUser;
import com.nielsen.manager.SecCatUserManager;

@RestController
@CrossOrigin
@RequestMapping("/web-collector/user")
public class ApiSecCatUserController {
	
	private SecCatUserManager secCaUserManager;

	public ApiSecCatUserController(SecCatUserManager secCaUserManager) {
		this.secCaUserManager = secCaUserManager;
	}
	@RequestMapping(method = RequestMethod.GET, value="/login/userId/{userId}/pwd/{pwd}")
	public SecCatUser login(@PathVariable String userId, @PathVariable String pwd){
		return this.secCaUserManager.login(userId, pwd);
	}

}
