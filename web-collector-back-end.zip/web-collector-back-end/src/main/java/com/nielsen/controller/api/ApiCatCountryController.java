package com.nielsen.controller.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nielsen.dto.CatCountry;
import com.nielsen.manager.CatCountryManager;

@RestController
@CrossOrigin
@RequestMapping("/web-collector/country")
public class ApiCatCountryController {
	
	private CatCountryManager catCountryManager;

	@Autowired
	public ApiCatCountryController(CatCountryManager catCountryManager) {
		this.catCountryManager = catCountryManager;
	}
	
	@RequestMapping(method = RequestMethod.GET)
	public List<CatCountry> list() {	
		return this.catCountryManager.findAll();
	}
	@RequestMapping(method = RequestMethod.GET, value="/userId/{userId}/countries")
	public List<CatCountry> listByUserId(@PathVariable String userId) {	
		return this.catCountryManager.findAllByUserId(userId);
	}
	
	
}
