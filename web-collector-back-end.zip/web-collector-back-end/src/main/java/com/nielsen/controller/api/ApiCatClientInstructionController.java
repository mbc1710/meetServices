package com.nielsen.controller.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nielsen.dto.CatClientInstruction;
import com.nielsen.dto.CiCatClientInstruction;
import com.nielsen.manager.CatClientInstructionManager;

@RestController
@CrossOrigin
@RequestMapping("/web-collector/client-instruction")
public class ApiCatClientInstructionController {
	
	private CatClientInstructionManager catClientInstructionManager;

	@Autowired
	public ApiCatClientInstructionController(CatClientInstructionManager catClientInstructionManager) {
		this.catClientInstructionManager = catClientInstructionManager;
	}
	@RequestMapping(method = RequestMethod.GET)
	public List<CiCatClientInstruction> getAll() {	
		return this.catClientInstructionManager.listAll();
	}
	@RequestMapping(method = RequestMethod.GET, value = "/userId/{userId}/countryId/{countryId}")
	public List<CatClientInstruction> getByCountryId(@PathVariable Integer countryId, @PathVariable String userId) {	
		return this.catClientInstructionManager.listAllByCountryIdAndUserId(countryId, userId);
	}
}
