package com.nielsen.dto;

import java.io.Serializable;
import java.math.BigInteger;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "am_data_photo", schema = "so_web_collector")
public class AmDataPhoto implements Serializable{

	private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "key_id")
    private Long keyId;
    @Basic(optional = false)
    @Column(name = "country_id")
    private int countryId;
    @Basic(optional = false)
    @Column(name = "ci_id")
    private long ciId;
    @Basic(optional = false)
    @Column(name = "period_id")
    private BigInteger periodId;
    @Basic(optional = false)
    @Column(name = "store_id")
    private long storeId;
    @Basic(optional = false)
    @Column(name = "photo_id")
    private int photoId;
    @Column(name = "exh_id")
    private long exhId;
    @Column(name = "item_id")
    private long itemId;
    @Basic(optional = false)
    @Column(name = "transferset_id")
    private int transfersetId;
    @Basic(optional = false)
    @Column(name = "url_photo")
    private String urlPhoto;
    
//    @JoinColumn(name = "photo_level_id", referencedColumnName = "photo_level_id")
//    @ManyToOne(optional = false)
//    private AmCatPhotoLevel photoLevelId;
    
    @JoinColumn(name = "status_id", referencedColumnName = "status_id")
    @ManyToOne(optional = false)
    private AmCatStatusPhoto statusId;

    public AmDataPhoto() {
    	
    }

	public Long getKeyId() {
		return keyId;
	}

	public void setKeyId(Long keyId) {
		this.keyId = keyId;
	}

	public int getCountryId() {
		return countryId;
	}

	public void setCountryId(int countryId) {
		this.countryId = countryId;
	}

	public long getCiId() {
		return ciId;
	}

	public void setCiId(long ciId) {
		this.ciId = ciId;
	}

	public BigInteger getPeriodId() {
		return periodId;
	}

	public void setPeriodId(BigInteger periodId) {
		this.periodId = periodId;
	}

	public long getStoreId() {
		return storeId;
	}

	public void setStoreId(long storeId) {
		this.storeId = storeId;
	}

	public int getPhotoId() {
		return photoId;
	}

	public void setPhotoId(int photoId) {
		this.photoId = photoId;
	}

	public long getExhId() {
		return exhId;
	}

	public void setExhId(long exhId) {
		this.exhId = exhId;
	}

	public long getItemId() {
		return itemId;
	}

	public void setItemId(long itemId) {
		this.itemId = itemId;
	}

	public int getTransfersetId() {
		return transfersetId;
	}

	public void setTransfersetId(int transfersetId) {
		this.transfersetId = transfersetId;
	}

	public String getUrlPhoto() {
		return urlPhoto;
	}

	public void setUrlPhoto(String urlPhoto) {
		this.urlPhoto = urlPhoto;
	}

	public AmCatStatusPhoto getStatusId() {
		return statusId;
	}

	public void setStatusId(AmCatStatusPhoto statusId) {
		this.statusId = statusId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (ciId ^ (ciId >>> 32));
		result = prime * result + countryId;
		result = prime * result + (int) (exhId ^ (exhId >>> 32));
		result = prime * result + (int) (itemId ^ (itemId >>> 32));
		result = prime * result + ((keyId == null) ? 0 : keyId.hashCode());
		result = prime * result + ((periodId == null) ? 0 : periodId.hashCode());
		result = prime * result + photoId;
		result = prime * result + ((statusId == null) ? 0 : statusId.hashCode());
		result = prime * result + (int) (storeId ^ (storeId >>> 32));
		result = prime * result + transfersetId;
		result = prime * result + ((urlPhoto == null) ? 0 : urlPhoto.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AmDataPhoto other = (AmDataPhoto) obj;
		if (ciId != other.ciId)
			return false;
		if (countryId != other.countryId)
			return false;
		if (exhId != other.exhId)
			return false;
		if (itemId != other.itemId)
			return false;
		if (keyId == null) {
			if (other.keyId != null)
				return false;
		} else if (!keyId.equals(other.keyId))
			return false;
		if (periodId == null) {
			if (other.periodId != null)
				return false;
		} else if (!periodId.equals(other.periodId))
			return false;
		if (photoId != other.photoId)
			return false;
		if (statusId == null) {
			if (other.statusId != null)
				return false;
		} else if (!statusId.equals(other.statusId))
			return false;
		if (storeId != other.storeId)
			return false;
		if (transfersetId != other.transfersetId)
			return false;
		if (urlPhoto == null) {
			if (other.urlPhoto != null)
				return false;
		} else if (!urlPhoto.equals(other.urlPhoto))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AmDataPhoto [keyId=" + keyId + ", countryId=" + countryId + ", ciId=" + ciId + ", periodId=" + periodId
				+ ", storeId=" + storeId + ", photoId=" + photoId + ", exhId=" + exhId + ", itemId=" + itemId
				+ ", transfersetId=" + transfersetId + ", urlPhoto=" + urlPhoto + ", statusId=" + statusId
				+ ", getKeyId()=" + getKeyId() + ", getCountryId()=" + getCountryId() + ", getCiId()=" + getCiId()
				+ ", getPeriodId()=" + getPeriodId() + ", getStoreId()=" + getStoreId() + ", getPhotoId()="
				+ getPhotoId() + ", getExhId()=" + getExhId() + ", getItemId()=" + getItemId() + ", getTransfersetId()="
				+ getTransfersetId() + ", getUrlPhoto()=" + getUrlPhoto() + ", getStatusId()=" + getStatusId()
				+ ", hashCode()=" + hashCode() + ", getClass()=" + getClass() + ", toString()=" + super.toString()
				+ "]";
	}

}
