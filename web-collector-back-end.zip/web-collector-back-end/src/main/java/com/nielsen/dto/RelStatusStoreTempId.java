package com.nielsen.dto;

import java.io.Serializable;
import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class RelStatusStoreTempId implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Column(name = "auditdate")
	private Integer auditdate;
	
	@Column(name = "auditorname")
	private String auditorname;
	
	@Column(name = "ci_id")
	private long ciId;
	
	@Column(name = "country_id")
	private Integer countryId;
	
	@Column(name = "status_id")
	private Integer statusId;
	
	@Column(name = "store_id")
	private long storeId;

	public RelStatusStoreTempId(){
		
	}



	public Integer getAuditdate() {
		return auditdate;
	}

	public void setAuditdate(Integer auditdate) {
		this.auditdate = auditdate;
	}

	public String getAuditorname() {
		return auditorname;
	}

	public void setAuditorname(String auditorname) {
		this.auditorname = auditorname;
	}

	public long getCiId() {
		return ciId;
	}

	public void setCiId(long ciId) {
		this.ciId = ciId;
	}

	public Integer getCountryId() {
		return countryId;
	}

	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}

	public Integer getStatusId() {
		return statusId;
	}

	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}

	public long getStoreId() {
		return storeId;
	}

	public void setStoreId(long storeId) {
		this.storeId = storeId;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((auditdate == null) ? 0 : auditdate.hashCode());
		result = prime * result + ((auditorname == null) ? 0 : auditorname.hashCode());
		result = prime * result + (int) (ciId ^ (ciId >>> 32));
		result = prime * result + ((countryId == null) ? 0 : countryId.hashCode());
		result = prime * result + ((statusId == null) ? 0 : statusId.hashCode());
		result = prime * result + (int) (storeId ^ (storeId >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RelStatusStoreTempId other = (RelStatusStoreTempId) obj;
		if (auditdate == null) {
			if (other.auditdate != null)
				return false;
		} else if (!auditdate.equals(other.auditdate))
			return false;
		if (auditorname == null) {
			if (other.auditorname != null)
				return false;
		} else if (!auditorname.equals(other.auditorname))
			return false;
		if (ciId != other.ciId)
			return false;
		if (countryId == null) {
			if (other.countryId != null)
				return false;
		} else if (!countryId.equals(other.countryId))
			return false;
		if (statusId == null) {
			if (other.statusId != null)
				return false;
		} else if (!statusId.equals(other.statusId))
			return false;
		if (storeId != other.storeId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "RelStatusStoreTempId [auditdate=" + auditdate + ", auditorname="
				+ auditorname + ", ciId=" + ciId + ", countryId=" + countryId + ", statusId=" + statusId + ", storeId="
				+ storeId + ", getAuditdate()=" + getAuditdate()
				+ ", getAuditorname()=" + getAuditorname() + ", getCiId()=" + getCiId() + ", getCountryId()="
				+ getCountryId() + ", getStatusId()=" + getStatusId() + ", getStoreId()=" + getStoreId()
				+ ", hashCode()=" + hashCode() + ", getClass()=" + getClass() + ", toString()=" + super.toString()
				+ "]";
	}

	
}
