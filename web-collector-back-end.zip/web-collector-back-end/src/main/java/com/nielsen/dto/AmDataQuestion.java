package com.nielsen.dto;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "am_data_question", schema = "so_web_collector" )
public class AmDataQuestion implements Serializable{

	private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "key_id")
    private Long keyId;
    @Column(name = "country_id")
    private Integer countryId;
    @Basic(optional = false)
    @Column(name = "ci_id")
    private long ciId;
    @Basic(optional = false)
    @Column(name = "period_id")
    private int periodId;
    @Basic(optional = false)
    @Column(name = "store_id")
    private long storeId;
    @Column(name = "exh_id")
    private long exhId;
    @Column(name = "cat_id")
    private Integer catId;
    @Column(name = "item_id")
    private long itemId;
    @Column(name = "question_id")
    private Integer questionId;
    @Basic(optional = false)
    @Column(name = "value")
    private String value;
    @Basic(optional = false)
    @Column(name = "question_level_id")
    private int questionLevelId;
    @Basic(optional = false)
    @Column(name = "transferset_id")
    private int transfersetId;
    @Basic(optional = false)
    @Column(name = "iseditable")
    private boolean iseditable;

    public AmDataQuestion() {
    	
    	
    }

	public Long getKeyId() {
		return keyId;
	}

	public void setKeyId(Long keyId) {
		this.keyId = keyId;
	}

	public Integer getCountryId() {
		return countryId;
	}

	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}

	public long getCiId() {
		return ciId;
	}

	public void setCiId(long ciId) {
		this.ciId = ciId;
	}

	public int getPeriodId() {
		return periodId;
	}

	public void setPeriodId(int periodId) {
		this.periodId = periodId;
	}

	public long getStoreId() {
		return storeId;
	}

	public void setStoreId(long storeId) {
		this.storeId = storeId;
	}

	public long getExhId() {
		return exhId;
	}

	public void setExhId(long exhId) {
		this.exhId = exhId;
	}

	public Integer getCatId() {
		return catId;
	}

	public void setCatId(Integer catId) {
		this.catId = catId;
	}

	public long getItemId() {
		return itemId;
	}

	public void setItemId(long itemId) {
		this.itemId = itemId;
	}

	public Integer getQuestionId() {
		return questionId;
	}

	public void setQuestionId(Integer questionId) {
		this.questionId = questionId;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public int getQuestionLevelId() {
		return questionLevelId;
	}

	public void setQuestionLevelId(int questionLevelId) {
		this.questionLevelId = questionLevelId;
	}

	public int getTransfersetId() {
		return transfersetId;
	}

	public void setTransfersetId(int transfersetId) {
		this.transfersetId = transfersetId;
	}

	public boolean isIseditable() {
		return iseditable;
	}

	public void setIseditable(boolean iseditable) {
		this.iseditable = iseditable;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((catId == null) ? 0 : catId.hashCode());
		result = prime * result + (int) (ciId ^ (ciId >>> 32));
		result = prime * result + ((countryId == null) ? 0 : countryId.hashCode());
		result = prime * result + (int) (exhId ^ (exhId >>> 32));
		result = prime * result + (iseditable ? 1231 : 1237);
		result = prime * result + (int) (itemId ^ (itemId >>> 32));
		result = prime * result + ((keyId == null) ? 0 : keyId.hashCode());
		result = prime * result + periodId;
		result = prime * result + ((questionId == null) ? 0 : questionId.hashCode());
		result = prime * result + questionLevelId;
		result = prime * result + (int) (storeId ^ (storeId >>> 32));
		result = prime * result + transfersetId;
		result = prime * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AmDataQuestion other = (AmDataQuestion) obj;
		if (catId == null) {
			if (other.catId != null)
				return false;
		} else if (!catId.equals(other.catId))
			return false;
		if (ciId != other.ciId)
			return false;
		if (countryId == null) {
			if (other.countryId != null)
				return false;
		} else if (!countryId.equals(other.countryId))
			return false;
		if (exhId != other.exhId)
			return false;
		if (iseditable != other.iseditable)
			return false;
		if (itemId != other.itemId)
			return false;
		if (keyId == null) {
			if (other.keyId != null)
				return false;
		} else if (!keyId.equals(other.keyId))
			return false;
		if (periodId != other.periodId)
			return false;
		if (questionId == null) {
			if (other.questionId != null)
				return false;
		} else if (!questionId.equals(other.questionId))
			return false;
		if (questionLevelId != other.questionLevelId)
			return false;
		if (storeId != other.storeId)
			return false;
		if (transfersetId != other.transfersetId)
			return false;
		if (value == null) {
			if (other.value != null)
				return false;
		} else if (!value.equals(other.value))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AmDataQuestion [keyId=" + keyId + ", countryId=" + countryId + ", ciId=" + ciId + ", periodId="
				+ periodId + ", storeId=" + storeId + ", exhId=" + exhId + ", catId=" + catId + ", itemId=" + itemId
				+ ", questionId=" + questionId + ", value=" + value + ", questionLevelId=" + questionLevelId
				+ ", transfersetId=" + transfersetId + ", iseditable=" + iseditable + ", getKeyId()=" + getKeyId()
				+ ", getCountryId()=" + getCountryId() + ", getCiId()=" + getCiId() + ", getPeriodId()=" + getPeriodId()
				+ ", getStoreId()=" + getStoreId() + ", getExhId()=" + getExhId() + ", getCatId()=" + getCatId()
				+ ", getItemId()=" + getItemId() + ", getQuestionId()=" + getQuestionId() + ", getValue()=" + getValue()
				+ ", getQuestionLevelId()=" + getQuestionLevelId() + ", getTransfersetId()=" + getTransfersetId()
				+ ", isIseditable()=" + isIseditable() + ", hashCode()=" + hashCode() + ", getClass()=" + getClass()
				+ ", toString()=" + super.toString() + "]";
	}


}
