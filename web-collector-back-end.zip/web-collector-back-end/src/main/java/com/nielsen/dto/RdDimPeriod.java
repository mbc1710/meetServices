package com.nielsen.dto;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "rd_dim_period", schema = "so_rd")
public class RdDimPeriod implements Serializable{

	private static final long serialVersionUID = 1L;

	 	@EmbeddedId
	    protected RdDimPeriodId RdDimPeriodId;
	    @Basic(optional = false)
	    @Column(name = "period_desc")
	    private String periodDesc;

	    public RdDimPeriod() {
	    	
	    }

		public RdDimPeriodId getRdDimPeriodId() {
			return RdDimPeriodId;
		}

		public void setRdDimPeriodId(RdDimPeriodId rdDimPeriodId) {
			RdDimPeriodId = rdDimPeriodId;
		}

		public String getPeriodDesc() {
			return periodDesc;
		}

		public void setPeriodDesc(String periodDesc) {
			this.periodDesc = periodDesc;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((RdDimPeriodId == null) ? 0 : RdDimPeriodId.hashCode());
			result = prime * result + ((periodDesc == null) ? 0 : periodDesc.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			RdDimPeriod other = (RdDimPeriod) obj;
			if (RdDimPeriodId == null) {
				if (other.RdDimPeriodId != null)
					return false;
			} else if (!RdDimPeriodId.equals(other.RdDimPeriodId))
				return false;
			if (periodDesc == null) {
				if (other.periodDesc != null)
					return false;
			} else if (!periodDesc.equals(other.periodDesc))
				return false;
			return true;
		}

		@Override
		public String toString() {
			return "RdDimPeriod [RdDimPeriodId=" + RdDimPeriodId + ", periodDesc=" + periodDesc
					+ ", getRdDimPeriodId()=" + getRdDimPeriodId() + ", getPeriodDesc()=" + getPeriodDesc()
					+ ", hashCode()=" + hashCode() + ", getClass()=" + getClass() + ", toString()=" + super.toString()
					+ "]";
		}
}
