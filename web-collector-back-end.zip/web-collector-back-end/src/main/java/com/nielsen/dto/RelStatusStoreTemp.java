package com.nielsen.dto;

import java.io.Serializable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "rel_status_store_temp", schema = "so_web_collector")
public class RelStatusStoreTemp implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
    protected RelStatusStoreTempId relStatusStoreTempId;

	public RelStatusStoreTemp(){
		
	}

	public RelStatusStoreTempId getRelStatusStoreTempId() {
		return relStatusStoreTempId;
	}

	public void setRelStatusStoreTempId(RelStatusStoreTempId relStatusStoreTempId) {
		this.relStatusStoreTempId = relStatusStoreTempId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((relStatusStoreTempId == null) ? 0 : relStatusStoreTempId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RelStatusStoreTemp other = (RelStatusStoreTemp) obj;
		if (relStatusStoreTempId == null) {
			if (other.relStatusStoreTempId != null)
				return false;
		} else if (!relStatusStoreTempId.equals(other.relStatusStoreTempId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "RelStatusStoreTemp [relStatusStoreTempId=" + relStatusStoreTempId + ", getRelStatusStoreTempId()="
				+ getRelStatusStoreTempId() + ", hashCode()=" + hashCode() + ", getClass()=" + getClass()
				+ ", toString()=" + super.toString() + "]";
	}
	
}
