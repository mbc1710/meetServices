package com.nielsen.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "am_cat_entity", schema = "so_web_collector")
public class AmCatEntity implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
    @Basic(optional = false)
    @Column(name = "entity_id")
    private Integer entityId;
    @Basic(optional = false)
    @Column(name = "entity_desc")
    private String entityDesc;
    @Basic(optional = false)
    @Column(name = "active")
    private boolean active;
    @Basic(optional = false)
    @Column(name = "insert_date")
    private Date insertDate;
    @Column(name = "update_date")
    private Date updateDate;
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "amCatEntity")
    private Set<AmRelEntityValue> amRelEntityValueCollection;

    public AmCatEntity() {
    	
    }

	public Integer getEntityId() {
		return entityId;
	}

	public void setEntityId(Integer entityId) {
		this.entityId = entityId;
	}

	public String getEntityDesc() {
		return entityDesc;
	}

	public void setEntityDesc(String entityDesc) {
		this.entityDesc = entityDesc;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public Date getInsertDate() {
		return insertDate;
	}

	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public Set<AmRelEntityValue> getAmRelEntityValueCollection() {
		return amRelEntityValueCollection;
	}

	public void setAmRelEntityValueCollection(Set<AmRelEntityValue> amRelEntityValueCollection) {
		this.amRelEntityValueCollection = amRelEntityValueCollection;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (active ? 1231 : 1237);
		result = prime * result + ((entityDesc == null) ? 0 : entityDesc.hashCode());
		result = prime * result + ((entityId == null) ? 0 : entityId.hashCode());
		result = prime * result + ((insertDate == null) ? 0 : insertDate.hashCode());
		result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AmCatEntity other = (AmCatEntity) obj;
		if (active != other.active)
			return false;
		if (entityDesc == null) {
			if (other.entityDesc != null)
				return false;
		} else if (!entityDesc.equals(other.entityDesc))
			return false;
		if (entityId == null) {
			if (other.entityId != null)
				return false;
		} else if (!entityId.equals(other.entityId))
			return false;
		if (insertDate == null) {
			if (other.insertDate != null)
				return false;
		} else if (!insertDate.equals(other.insertDate))
			return false;
		if (updateDate == null) {
			if (other.updateDate != null)
				return false;
		} else if (!updateDate.equals(other.updateDate))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AmCatEntity [entityId=" + entityId + ", entityDesc=" + entityDesc + ", active=" + active
				+ ", insertDate=" + insertDate + ", updateDate=" + updateDate + ", getEntityId()=" + getEntityId()
				+ ", getEntityDesc()=" + getEntityDesc() + ", isActive()=" + isActive() + ", getInsertDate()="
				+ getInsertDate() + ", getUpdateDate()=" + getUpdateDate() + ", hashCode()=" + hashCode()
				+ ", getClass()=" + getClass() + ", toString()=" + super.toString() + "]";
	}

    
    
}
