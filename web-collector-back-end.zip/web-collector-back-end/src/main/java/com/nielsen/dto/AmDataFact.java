package com.nielsen.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "am_data_fact", schema = "so_web_collector")
public class AmDataFact implements Serializable{

	private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "key_id")
    private Long keyId;
    @Basic(optional = false)
    @Column(name = "country_id")
    private int countryId;
    @Basic(optional = false)
    @Column(name = "ci_id")
    private long ciId;
    @Basic(optional = false)
    @Column(name = "period_id")
    private BigInteger periodId;
    @Basic(optional = false)
    @Column(name = "store_id")
    private long storeId;
    @Column(name = "exh_id")
    private long exhId;
    @Column(name = "item_id")
    private long itemId;
    @Basic(optional = false)
    @Column(name = "fact_id")
    private int factId;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Basic(optional = false)
    @Column(name = "value")
    private BigDecimal value;
    @Basic(optional = false)
    @Column(name = "fact_level_id")
    private int factLevelId;
    @Basic(optional = false)
    @Column(name = "transferset_id")
    private int transfersetId;
    @Basic(optional = false)
    @Column(name = "iseditable")
    private boolean iseditable;

    public AmDataFact() {
    	
    }

	public Long getKeyId() {
		return keyId;
	}

	public void setKeyId(Long keyId) {
		this.keyId = keyId;
	}

	public int getCountryId() {
		return countryId;
	}

	public void setCountryId(int countryId) {
		this.countryId = countryId;
	}

	public long getCiId() {
		return ciId;
	}

	public void setCiId(long ciId) {
		this.ciId = ciId;
	}

	public BigInteger getPeriodId() {
		return periodId;
	}

	public void setPeriodId(BigInteger periodId) {
		this.periodId = periodId;
	}

	public long getStoreId() {
		return storeId;
	}

	public void setStoreId(long storeId) {
		this.storeId = storeId;
	}

	public long getExhId() {
		return exhId;
	}

	public void setExhId(long exhId) {
		this.exhId = exhId;
	}

	public long getItemId() {
		return itemId;
	}

	public void setItemId(long itemId) {
		this.itemId = itemId;
	}

	public int getFactId() {
		return factId;
	}

	public void setFactId(int factId) {
		this.factId = factId;
	}

	public BigDecimal getValue() {
		return value;
	}

	public void setValue(BigDecimal value) {
		this.value = value;
	}

	public int getFactLevelId() {
		return factLevelId;
	}

	public void setFactLevelId(int factLevelId) {
		this.factLevelId = factLevelId;
	}

	public int getTransfersetId() {
		return transfersetId;
	}

	public void setTransfersetId(int transfersetId) {
		this.transfersetId = transfersetId;
	}

	public boolean isIseditable() {
		return iseditable;
	}

	public void setIseditable(boolean iseditable) {
		this.iseditable = iseditable;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (ciId ^ (ciId >>> 32));
		result = prime * result + countryId;
		result = prime * result + (int) (exhId ^ (exhId >>> 32));
		result = prime * result + factId;
		result = prime * result + factLevelId;
		result = prime * result + (iseditable ? 1231 : 1237);
		result = prime * result + (int) (itemId ^ (itemId >>> 32));
		result = prime * result + ((keyId == null) ? 0 : keyId.hashCode());
		result = prime * result + ((periodId == null) ? 0 : periodId.hashCode());
		result = prime * result + (int) (storeId ^ (storeId >>> 32));
		result = prime * result + transfersetId;
		result = prime * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AmDataFact other = (AmDataFact) obj;
		if (ciId != other.ciId)
			return false;
		if (countryId != other.countryId)
			return false;
		if (exhId != other.exhId)
			return false;
		if (factId != other.factId)
			return false;
		if (factLevelId != other.factLevelId)
			return false;
		if (iseditable != other.iseditable)
			return false;
		if (itemId != other.itemId)
			return false;
		if (keyId == null) {
			if (other.keyId != null)
				return false;
		} else if (!keyId.equals(other.keyId))
			return false;
		if (periodId == null) {
			if (other.periodId != null)
				return false;
		} else if (!periodId.equals(other.periodId))
			return false;
		if (storeId != other.storeId)
			return false;
		if (transfersetId != other.transfersetId)
			return false;
		if (value == null) {
			if (other.value != null)
				return false;
		} else if (!value.equals(other.value))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AmDataFact [keyId=" + keyId + ", countryId=" + countryId + ", ciId=" + ciId + ", periodId=" + periodId
				+ ", storeId=" + storeId + ", exhId=" + exhId + ", itemId=" + itemId + ", factId=" + factId + ", value="
				+ value + ", factLevelId=" + factLevelId + ", transfersetId=" + transfersetId + ", iseditable="
				+ iseditable + ", getKeyId()=" + getKeyId() + ", getCountryId()=" + getCountryId() + ", getCiId()="
				+ getCiId() + ", getPeriodId()=" + getPeriodId() + ", getStoreId()=" + getStoreId() + ", getExhId()="
				+ getExhId() + ", getItemId()=" + getItemId() + ", getFactId()=" + getFactId() + ", getValue()="
				+ getValue() + ", getFactLevelId()=" + getFactLevelId() + ", getTransfersetId()=" + getTransfersetId()
				+ ", isIseditable()=" + isIseditable() + ", hashCode()=" + hashCode() + ", getClass()=" + getClass()
				+ ", toString()=" + super.toString() + "]";
	}


}
