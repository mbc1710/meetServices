package com.nielsen.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "am_cat_value", schema = "so_web_collector")
public class AmCatValue implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
    @Basic(optional = false)
    @Column(name = "value_id")
    private Integer valueId;
    @Basic(optional = false)
    @Column(name = "value_desc")
    private String valueDesc;
    @Basic(optional = false)
    @Column(name = "active")
    private boolean active;
    @Basic(optional = false)
    @Column(name = "insert_date")
    private Date insertDate;
    @Column(name = "update_date")
    private Date updateDate;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "amCatValue")
    private Set<AmRelEntityValue> amRelEntityValueCollection;

    public AmCatValue() {
    	
    }

	public Integer getValueId() {
		return valueId;
	}

	public void setValueId(Integer valueId) {
		this.valueId = valueId;
	}

	public String getValueDesc() {
		return valueDesc;
	}

	public void setValueDesc(String valueDesc) {
		this.valueDesc = valueDesc;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public Date getInsertDate() {
		return insertDate;
	}

	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public Set<AmRelEntityValue> getAmRelEntityValueCollection() {
		return amRelEntityValueCollection;
	}

	public void setAmRelEntityValueCollection(Set<AmRelEntityValue> amRelEntityValueCollection) {
		this.amRelEntityValueCollection = amRelEntityValueCollection;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (active ? 1231 : 1237);
		result = prime * result + ((amRelEntityValueCollection == null) ? 0 : amRelEntityValueCollection.hashCode());
		result = prime * result + ((insertDate == null) ? 0 : insertDate.hashCode());
		result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
		result = prime * result + ((valueDesc == null) ? 0 : valueDesc.hashCode());
		result = prime * result + ((valueId == null) ? 0 : valueId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AmCatValue other = (AmCatValue) obj;
		if (active != other.active)
			return false;
		if (amRelEntityValueCollection == null) {
			if (other.amRelEntityValueCollection != null)
				return false;
		} else if (!amRelEntityValueCollection.equals(other.amRelEntityValueCollection))
			return false;
		if (insertDate == null) {
			if (other.insertDate != null)
				return false;
		} else if (!insertDate.equals(other.insertDate))
			return false;
		if (updateDate == null) {
			if (other.updateDate != null)
				return false;
		} else if (!updateDate.equals(other.updateDate))
			return false;
		if (valueDesc == null) {
			if (other.valueDesc != null)
				return false;
		} else if (!valueDesc.equals(other.valueDesc))
			return false;
		if (valueId == null) {
			if (other.valueId != null)
				return false;
		} else if (!valueId.equals(other.valueId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AmCatValue [valueId=" + valueId + ", valueDesc=" + valueDesc + ", active=" + active + ", insertDate="
				+ insertDate + ", updateDate=" + updateDate + ", amRelEntityValueCollection="
				+ amRelEntityValueCollection + ", getValueId()=" + getValueId() + ", getValueDesc()=" + getValueDesc()
				+ ", isActive()=" + isActive() + ", getInsertDate()=" + getInsertDate() + ", getUpdateDate()="
				+ getUpdateDate() + ", getAmRelEntityValueCollection()=" + getAmRelEntityValueCollection()
				+ ", hashCode()=" + hashCode() + ", getClass()=" + getClass() + ", toString()=" + super.toString()
				+ "]";
	}
	
    
}
