package com.nielsen.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "am_cat_photo_level", schema = "so_web_collector")
public class AmCatPhotoLevel implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
    @Column(name = "photo_level_id")
    private Short photoLevelId;
    @Column(name = "photo_level_name")
    private String photoLevelName;
    
//    @OneToMany(cascade = CascadeType.ALL, mappedBy = "photoLevelId")
//    private Set<AmDataPhoto> amDataPhotoCollection;

    public AmCatPhotoLevel() {
    	
    }

	public Short getPhotoLevelId() {
		return photoLevelId;
	}

	public void setPhotoLevelId(Short photoLevelId) {
		this.photoLevelId = photoLevelId;
	}

	public String getPhotoLevelName() {
		return photoLevelName;
	}

	public void setPhotoLevelName(String photoLevelName) {
		this.photoLevelName = photoLevelName;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((photoLevelId == null) ? 0 : photoLevelId.hashCode());
		result = prime * result + ((photoLevelName == null) ? 0 : photoLevelName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AmCatPhotoLevel other = (AmCatPhotoLevel) obj;
		if (photoLevelId == null) {
			if (other.photoLevelId != null)
				return false;
		} else if (!photoLevelId.equals(other.photoLevelId))
			return false;
		if (photoLevelName == null) {
			if (other.photoLevelName != null)
				return false;
		} else if (!photoLevelName.equals(other.photoLevelName))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AmCatPhotoLevel [photoLevelId=" + photoLevelId + ", photoLevelName=" + photoLevelName
				+ ", getPhotoLevelId()=" + getPhotoLevelId() + ", getPhotoLevelName()=" + getPhotoLevelName()
				+ ", hashCode()=" + hashCode() + ", getClass()=" + getClass() + ", toString()=" + super.toString()
				+ "]";
	}

}
