package com.nielsen.dto;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "am_rel_status_store", schema = "so_web_collector")
public class AmRelStatusStore implements Serializable{

	private static final long serialVersionUID = 1L;

	@EmbeddedId
    protected AmRelStatusStoreId amRelStatusStoreId;
    @Basic(optional = false)
    @Column(name = "country_id")
    private int countryId;
    @Basic(optional = false)
    @Column(name = "auditor_id")
    private String auditorId;
    @Column(name = "analyst_id")
    private String analystId;
    @Basic(optional = false)
    @Column(name = "transferset_id")
    private int transfersetId;
    @JoinColumn(name = "status_id", referencedColumnName = "status_id")
    @ManyToOne(optional = false)
    private AmCatStatusStore statusId;
    
//    @JoinColumn(name = "conversation_id", referencedColumnName = "conversation_id")
//    @ManyToOne
//    private AmRelStoreConversation conversationId;
    
    public AmRelStatusStore() {
    	
    }

	public AmRelStatusStoreId getAmRelStatusStoreId() {
		return amRelStatusStoreId;
	}

	public void setAmRelStatusStoreId(AmRelStatusStoreId amRelStatusStoreId) {
		this.amRelStatusStoreId = amRelStatusStoreId;
	}

	public int getCountryId() {
		return countryId;
	}

	public void setCountryId(int countryId) {
		this.countryId = countryId;
	}

	public String getAuditorId() {
		return auditorId;
	}

	public void setAuditorId(String auditorId) {
		this.auditorId = auditorId;
	}

	public String getAnalystId() {
		return analystId;
	}

	public void setAnalystId(String analystId) {
		this.analystId = analystId;
	}

	public int getTransfersetId() {
		return transfersetId;
	}

	public void setTransfersetId(int transfersetId) {
		this.transfersetId = transfersetId;
	}

	public AmCatStatusStore getStatusId() {
		return statusId;
	}

	public void setStatusId(AmCatStatusStore statusId) {
		this.statusId = statusId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((amRelStatusStoreId == null) ? 0 : amRelStatusStoreId.hashCode());
		result = prime * result + ((analystId == null) ? 0 : analystId.hashCode());
		result = prime * result + ((auditorId == null) ? 0 : auditorId.hashCode());
		result = prime * result + countryId;
		result = prime * result + ((statusId == null) ? 0 : statusId.hashCode());
		result = prime * result + transfersetId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AmRelStatusStore other = (AmRelStatusStore) obj;
		if (amRelStatusStoreId == null) {
			if (other.amRelStatusStoreId != null)
				return false;
		} else if (!amRelStatusStoreId.equals(other.amRelStatusStoreId))
			return false;
		if (analystId == null) {
			if (other.analystId != null)
				return false;
		} else if (!analystId.equals(other.analystId))
			return false;
		if (auditorId == null) {
			if (other.auditorId != null)
				return false;
		} else if (!auditorId.equals(other.auditorId))
			return false;
		if (countryId != other.countryId)
			return false;
		if (statusId == null) {
			if (other.statusId != null)
				return false;
		} else if (!statusId.equals(other.statusId))
			return false;
		if (transfersetId != other.transfersetId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AmRelStatusStore [amRelStatusStoreId=" + amRelStatusStoreId + ", countryId=" + countryId
				+ ", auditorId=" + auditorId + ", analystId=" + analystId + ", transfersetId=" + transfersetId
				+ ", statusId=" + statusId + ", getAmRelStatusStoreId()=" + getAmRelStatusStoreId()
				+ ", getCountryId()=" + getCountryId() + ", getAuditorId()=" + getAuditorId() + ", getAnalystId()="
				+ getAnalystId() + ", getTransfersetId()=" + getTransfersetId() + ", getStatusId()=" + getStatusId()
				+ ", hashCode()=" + hashCode() + ", getClass()=" + getClass() + ", toString()=" + super.toString()
				+ "]";
	}

	
}
