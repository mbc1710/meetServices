package com.nielsen.dto;

import java.io.Serializable;
import java.math.BigInteger;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class AmRelStatusStoreId implements Serializable{

	private static final long serialVersionUID = 1L;

	@Basic(optional = false)
    @Column(name = "ci_id")
    private long ciId;
    @Basic(optional = false)
    @Column(name = "period_id")
    private BigInteger periodId;
    @Basic(optional = false)
    @Column(name = "store_id")
    private long storeId;

    public AmRelStatusStoreId() {
    	
    }

	public long getCiId() {
		return ciId;
	}

	public void setCiId(long ciId) {
		this.ciId = ciId;
	}

	public BigInteger getPeriodId() {
		return periodId;
	}

	public void setPeriodId(BigInteger periodId) {
		this.periodId = periodId;
	}

	public long getStoreId() {
		return storeId;
	}

	public void setStoreId(long storeId) {
		this.storeId = storeId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (ciId ^ (ciId >>> 32));
		result = prime * result + ((periodId == null) ? 0 : periodId.hashCode());
		result = prime * result + (int) (storeId ^ (storeId >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AmRelStatusStoreId other = (AmRelStatusStoreId) obj;
		if (ciId != other.ciId)
			return false;
		if (periodId == null) {
			if (other.periodId != null)
				return false;
		} else if (!periodId.equals(other.periodId))
			return false;
		if (storeId != other.storeId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AmRelStatusStoreId [ciId=" + ciId + ", periodId=" + periodId + ", storeId=" + storeId + ", getCiId()="
				+ getCiId() + ", getPeriodId()=" + getPeriodId() + ", getStoreId()=" + getStoreId() + ", hashCode()="
				+ hashCode() + ", getClass()=" + getClass() + ", toString()=" + super.toString() + "]";
	}

	
}
