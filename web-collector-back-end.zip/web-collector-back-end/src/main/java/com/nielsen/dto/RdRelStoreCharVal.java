package com.nielsen.dto;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "rd_rel_store_char_val", schema = "so_rd")
public class RdRelStoreCharVal implements Serializable{

	private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected RdRelStoreCharValId rdRelStoreCharValId;
    @Basic(optional = false)
    @Column(name = "char_val_id")
    private long charValId;

    public RdRelStoreCharVal() {
    	
    }

	public RdRelStoreCharValId getRdRelStoreCharValId() {
		return rdRelStoreCharValId;
	}

	public void setRdRelStoreCharValId(RdRelStoreCharValId rdRelStoreCharValId) {
		this.rdRelStoreCharValId = rdRelStoreCharValId;
	}

	public long getCharValId() {
		return charValId;
	}

	public void setCharValId(long charValId) {
		this.charValId = charValId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (charValId ^ (charValId >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RdRelStoreCharVal other = (RdRelStoreCharVal) obj;
		if (charValId != other.charValId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "RdRelStoreCharVal [charValId=" + charValId + ", getCharValId()=" + getCharValId() + ", hashCode()="
				+ hashCode() + ", getClass()=" + getClass() + ", toString()=" + super.toString() + "]";
	}

   
}
