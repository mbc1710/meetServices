package com.nielsen.dto;

import java.io.Serializable;

public class StoreDetailList implements Serializable{

	private static final long serialVersionUID = 1L;
	private Integer ciId;
	private Integer periodId;
	private Integer storeId;
	private Integer charId;
	private Integer charValId;
	private String charName;
	private String charValName;
	
	public Integer getCiId() {
		return ciId;
	}
	public void setCiId(Integer ciId) {
		this.ciId = ciId;
	}
	public Integer getPeriodId() {
		return periodId;
	}
	public void setPeriodId(Integer periodId) {
		this.periodId = periodId;
	}
	public Integer getStoreId() {
		return storeId;
	}
	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}
	public Integer getCharId() {
		return charId;
	}
	public void setCharId(Integer charId) {
		this.charId = charId;
	}
	public Integer getCharValId() {
		return charValId;
	}
	public void setCharValId(Integer charValId) {
		this.charValId = charValId;
	}
	public String getCharName() {
		return charName;
	}
	public void setCharName(String charName) {
		this.charName = charName;
	}
	public String getCharValName() {
		return charValName;
	}
	public void setCharValName(String charValName) {
		this.charValName = charValName;
	}
	
	
}
