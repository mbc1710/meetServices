package com.nielsen.dto;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "am_cat_key_type", schema = "so_web_collector")
public class AmCatKeyType implements Serializable{

	private static final long serialVersionUID = 1L;

    @Basic(optional = false)
    @Column(name = "ci_id")
    private long ciId;
    @Id
    @Basic(optional = false)
    @Column(name = "key_type_id")
    private Integer keyTypeId;
    @Column(name = "key_type_desc")
    private String keyTypeDesc;

    public AmCatKeyType() {
    	
    }

	public long getCiId() {
		return ciId;
	}

	public void setCiId(long ciId) {
		this.ciId = ciId;
	}

	public Integer getKeyTypeId() {
		return keyTypeId;
	}

	public void setKeyTypeId(Integer keyTypeId) {
		this.keyTypeId = keyTypeId;
	}

	public String getKeyTypeDesc() {
		return keyTypeDesc;
	}

	public void setKeyTypeDesc(String keyTypeDesc) {
		this.keyTypeDesc = keyTypeDesc;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (ciId ^ (ciId >>> 32));
		result = prime * result + ((keyTypeDesc == null) ? 0 : keyTypeDesc.hashCode());
		result = prime * result + ((keyTypeId == null) ? 0 : keyTypeId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AmCatKeyType other = (AmCatKeyType) obj;
		if (ciId != other.ciId)
			return false;
		if (keyTypeDesc == null) {
			if (other.keyTypeDesc != null)
				return false;
		} else if (!keyTypeDesc.equals(other.keyTypeDesc))
			return false;
		if (keyTypeId == null) {
			if (other.keyTypeId != null)
				return false;
		} else if (!keyTypeId.equals(other.keyTypeId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AmCatKeyType [ciId=" + ciId + ", keyTypeId=" + keyTypeId + ", keyTypeDesc=" + keyTypeDesc
				+ ", getCiId()=" + getCiId() + ", getKeyTypeId()=" + getKeyTypeId() + ", getKeyTypeDesc()="
				+ getKeyTypeDesc() + ", hashCode()=" + hashCode() + ", getClass()=" + getClass() + ", toString()="
				+ super.toString() + "]";
	}
    
    
}
