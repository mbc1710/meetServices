package com.nielsen.dto;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "am_cat_validations", schema = "so_web_collector")
public class AmCatValidations implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
    protected AmCatValidationsId amCatValidationsId;

	public AmCatValidations(){
		
		
	}
	
	public AmCatValidationsId getAmCatValidationsId() {
		return amCatValidationsId;
	}

	public void setAmCatValidationsId(AmCatValidationsId amCatValidationsId) {
		this.amCatValidationsId = amCatValidationsId;
	}

	
}
