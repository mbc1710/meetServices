package com.nielsen.dto;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "am_rel_store_conversation", schema = "so_web_collector")	
public class AmRelStoreConversation implements Serializable{

	private static final long serialVersionUID = 1L;
	
    @Basic(optional = false)
    @Column(name = "country_id")
    private int countryId;
    @Basic(optional = false)
    @Column(name = "ci_id")
    private long ciId;
    @Column(name = "row_id")
    private long rowId;
    
    @Id
    @Basic(optional = false)
    @Column(name = "conversation_id")
    private long conversationId;
    
    @Basic(optional = false)
    @Column(name = "conversation_desc")
    private String conversationDesc;
    @Basic(optional = false)
    @Column(name = "active")
    private boolean active;
    @Basic(optional = false)
    @Column(name = "user_id")
    private long userId;
    @Basic(optional = false)
    @Column(name = "insert_date")
    private Date insertDate;
    @Column(name = "update_date")
    private Date updateDate;
    
//    @OneToMany(mappedBy = "conversationId")
//    private Set<AmRelStatusStore> amRelStatusStoreCollection;

    public AmRelStoreConversation() {
    	
    	
    }

	public int getCountryId() {
		return countryId;
	}

	public void setCountryId(int countryId) {
		this.countryId = countryId;
	}

	public long getCiId() {
		return ciId;
	}

	public void setCiId(long ciId) {
		this.ciId = ciId;
	}

	public long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public long getConversationId() {
		return conversationId;
	}

	public void setConversationId(long conversationId) {
		this.conversationId = conversationId;
	}

	public String getConversationDesc() {
		return conversationDesc;
	}

	public void setConversationDesc(String conversationDesc) {
		this.conversationDesc = conversationDesc;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public Date getInsertDate() {
		return insertDate;
	}

	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (active ? 1231 : 1237);
		result = prime * result + (int) (ciId ^ (ciId >>> 32));
		result = prime * result + ((conversationDesc == null) ? 0 : conversationDesc.hashCode());
		result = prime * result + (int) (conversationId ^ (conversationId >>> 32));
		result = prime * result + countryId;
		result = prime * result + ((insertDate == null) ? 0 : insertDate.hashCode());
		result = prime * result + (int) (rowId ^ (rowId >>> 32));
		result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
		result = prime * result + (int) (userId ^ (userId >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AmRelStoreConversation other = (AmRelStoreConversation) obj;
		if (active != other.active)
			return false;
		if (ciId != other.ciId)
			return false;
		if (conversationDesc == null) {
			if (other.conversationDesc != null)
				return false;
		} else if (!conversationDesc.equals(other.conversationDesc))
			return false;
		if (conversationId != other.conversationId)
			return false;
		if (countryId != other.countryId)
			return false;
		if (insertDate == null) {
			if (other.insertDate != null)
				return false;
		} else if (!insertDate.equals(other.insertDate))
			return false;
		if (rowId != other.rowId)
			return false;
		if (updateDate == null) {
			if (other.updateDate != null)
				return false;
		} else if (!updateDate.equals(other.updateDate))
			return false;
		if (userId != other.userId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AmRelStoreConversation [countryId=" + countryId + ", ciId=" + ciId + ", rowId=" + rowId
				+ ", conversationId=" + conversationId + ", conversationDesc=" + conversationDesc + ", active=" + active
				+ ", userId=" + userId + ", insertDate=" + insertDate + ", updateDate=" + updateDate
				+ ", getCountryId()=" + getCountryId() + ", getCiId()=" + getCiId() + ", getRowId()=" + getRowId()
				+ ", getConversationId()=" + getConversationId() + ", getConversationDesc()=" + getConversationDesc()
				+ ", isActive()=" + isActive() + ", getUserId()=" + getUserId() + ", getInsertDate()=" + getInsertDate()
				+ ", getUpdateDate()=" + getUpdateDate() + ", hashCode()=" + hashCode() + ", getClass()=" + getClass()
				+ ", toString()=" + super.toString() + "]";
	}

	
}
