package com.nielsen.dto;

import java.io.Serializable;

public class CatCountry implements Serializable{

	private static final long serialVersionUID = 1L;
    private Integer countryId;
    private String countryDesc;
    
	public CatCountry(Integer countryId) {
		this.countryId = countryId;
	}


	public CatCountry() {
	}


	public Integer getCountryId() {
		return countryId;
	}

	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}

	public String getCountryDesc() {
		return countryDesc;
	}

	public void setCountryDesc(String countryDesc) {
		this.countryDesc = countryDesc;
	}
    
}
