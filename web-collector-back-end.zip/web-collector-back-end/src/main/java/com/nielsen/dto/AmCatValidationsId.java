package com.nielsen.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class AmCatValidationsId implements Serializable{

	private static final long serialVersionUID = 1L;

	@Column(name = "ci_id")
	private long ciId;
	@Column(name = "country_id")
	private Integer countryId;
	@Column(name = "key_id")
	private long keyId;
	@Column(name = "key_type_id")
	private Integer keyTypeId;
	@Column(name = "mandatory")
	private Boolean mandatory;
	@Column(name = "reg_exp")
	private String regExp;
	@Column(name = "validation_id")
	private Integer validationId;
	
	public AmCatValidationsId(){
		
		
	}

	public long getCiId() {
		return ciId;
	}

	public void setCiId(long ciId) {
		this.ciId = ciId;
	}

	public Integer getCountryId() {
		return countryId;
	}

	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}

	public long getKeyId() {
		return keyId;
	}

	public void setKeyId(long keyId) {
		this.keyId = keyId;
	}

	public Integer getKeyTypeId() {
		return keyTypeId;
	}

	public void setKeyTypeId(Integer keyTypeId) {
		this.keyTypeId = keyTypeId;
	}

	public Boolean getMandatory() {
		return mandatory;
	}

	public void setMandatory(Boolean mandatory) {
		this.mandatory = mandatory;
	}

	public String getRegExp() {
		return regExp;
	}

	public void setRegExp(String regExp) {
		this.regExp = regExp;
	}

	public Integer getValidationId() {
		return validationId;
	}

	public void setValidationId(Integer validationId) {
		this.validationId = validationId;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (ciId ^ (ciId >>> 32));
		result = prime * result + ((countryId == null) ? 0 : countryId.hashCode());
		result = prime * result + (int) (keyId ^ (keyId >>> 32));
		result = prime * result + ((keyTypeId == null) ? 0 : keyTypeId.hashCode());
		result = prime * result + ((mandatory == null) ? 0 : mandatory.hashCode());
		result = prime * result + ((regExp == null) ? 0 : regExp.hashCode());
		result = prime * result + ((validationId == null) ? 0 : validationId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AmCatValidationsId other = (AmCatValidationsId) obj;
		if (ciId != other.ciId)
			return false;
		if (countryId == null) {
			if (other.countryId != null)
				return false;
		} else if (!countryId.equals(other.countryId))
			return false;
		if (keyId != other.keyId)
			return false;
		if (keyTypeId == null) {
			if (other.keyTypeId != null)
				return false;
		} else if (!keyTypeId.equals(other.keyTypeId))
			return false;
		if (mandatory == null) {
			if (other.mandatory != null)
				return false;
		} else if (!mandatory.equals(other.mandatory))
			return false;
		if (regExp == null) {
			if (other.regExp != null)
				return false;
		} else if (!regExp.equals(other.regExp))
			return false;
		if (validationId == null) {
			if (other.validationId != null)
				return false;
		} else if (!validationId.equals(other.validationId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AmCatValidationsId [ciId=" + ciId + ", countryId=" + countryId + ", keyId=" + keyId + ", keyTypeId="
				+ keyTypeId + ", mandatory=" + mandatory + ", regExp=" + regExp + ", validationId=" + validationId
				+ ", getCiId()=" + getCiId() + ", getCountryId()=" + getCountryId() + ", getKeyId()=" + getKeyId()
				+ ", getKeyTypeId()=" + getKeyTypeId() + ", getMandatory()=" + getMandatory() + ", getRegExp()="
				+ getRegExp() + ", getValidationId()=" + getValidationId() + ", hashCode()=" + hashCode()
				+ ", getClass()=" + getClass() + ", toString()=" + super.toString() + "]";
	}
	
	
}
