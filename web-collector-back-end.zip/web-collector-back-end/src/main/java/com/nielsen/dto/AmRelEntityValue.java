package com.nielsen.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "am_rel_entity_value", schema = "so_web_collector")
public class AmRelEntityValue implements Serializable{

	private static final long serialVersionUID = 1L;

	@EmbeddedId
    protected AmRelEntityValueId amRelEntityValueId;
    @Basic(optional = false)
    @Column(name = "active")
    private boolean active;
    @Basic(optional = false)
    @Column(name = "insert_date")
    private Date insertDate;
    @Column(name = "update_date")
    private Date updateDate;
    @JoinColumn(name = "entity_id", referencedColumnName = "entity_id", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private AmCatEntity amCatEntity;
    @JoinColumn(name = "value_id", referencedColumnName = "value_id", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private AmCatValue amCatValue;

    public AmRelEntityValue() {
    	
    }

	public AmRelEntityValueId getAmRelEntityValueId() {
		return amRelEntityValueId;
	}

	public void setAmRelEntityValueId(AmRelEntityValueId amRelEntityValueId) {
		this.amRelEntityValueId = amRelEntityValueId;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public Date getInsertDate() {
		return insertDate;
	}

	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public AmCatEntity getAmCatEntity() {
		return amCatEntity;
	}

	public void setAmCatEntity(AmCatEntity amCatEntity) {
		this.amCatEntity = amCatEntity;
	}

	public AmCatValue getAmCatValue() {
		return amCatValue;
	}

	public void setAmCatValue(AmCatValue amCatValue) {
		this.amCatValue = amCatValue;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (active ? 1231 : 1237);
		result = prime * result + ((amCatEntity == null) ? 0 : amCatEntity.hashCode());
		result = prime * result + ((amCatValue == null) ? 0 : amCatValue.hashCode());
		result = prime * result + ((amRelEntityValueId == null) ? 0 : amRelEntityValueId.hashCode());
		result = prime * result + ((insertDate == null) ? 0 : insertDate.hashCode());
		result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AmRelEntityValue other = (AmRelEntityValue) obj;
		if (active != other.active)
			return false;
		if (amCatEntity == null) {
			if (other.amCatEntity != null)
				return false;
		} else if (!amCatEntity.equals(other.amCatEntity))
			return false;
		if (amCatValue == null) {
			if (other.amCatValue != null)
				return false;
		} else if (!amCatValue.equals(other.amCatValue))
			return false;
		if (amRelEntityValueId == null) {
			if (other.amRelEntityValueId != null)
				return false;
		} else if (!amRelEntityValueId.equals(other.amRelEntityValueId))
			return false;
		if (insertDate == null) {
			if (other.insertDate != null)
				return false;
		} else if (!insertDate.equals(other.insertDate))
			return false;
		if (updateDate == null) {
			if (other.updateDate != null)
				return false;
		} else if (!updateDate.equals(other.updateDate))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AmRelEntityValue [amRelEntityValueId=" + amRelEntityValueId + ", active=" + active + ", insertDate="
				+ insertDate + ", updateDate=" + updateDate + ", amCatEntity=" + amCatEntity + ", amCatValue="
				+ amCatValue + ", getAmRelEntityValueId()=" + getAmRelEntityValueId() + ", isActive()=" + isActive()
				+ ", getInsertDate()=" + getInsertDate() + ", getUpdateDate()=" + getUpdateDate()
				+ ", getAmCatEntity()=" + getAmCatEntity() + ", getAmCatValue()=" + getAmCatValue() + ", hashCode()="
				+ hashCode() + ", getClass()=" + getClass() + ", toString()=" + super.toString() + "]";
	}
    
    
}
