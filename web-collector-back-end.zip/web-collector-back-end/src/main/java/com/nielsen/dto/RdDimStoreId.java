package com.nielsen.dto;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class RdDimStoreId implements Serializable{

	private static final long serialVersionUID = 1L;

	@Basic(optional = false)
    @Column(name = "ci_id")
    private long ciId;
    @Basic(optional = false)
    @Column(name = "store_id")
    private int storeId;

    public RdDimStoreId() {
    	
    }

	public long getCiId() {
		return ciId;
	}

	public void setCiId(long ciId) {
		this.ciId = ciId;
	}

	public int getStoreId() {
		return storeId;
	}

	public void setStoreId(int storeId) {
		this.storeId = storeId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (ciId ^ (ciId >>> 32));
		result = prime * result + storeId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RdDimStoreId other = (RdDimStoreId) obj;
		if (ciId != other.ciId)
			return false;
		if (storeId != other.storeId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "RdDimStoreId [ciId=" + ciId + ", storeId=" + storeId + ", getCiId()=" + getCiId() + ", getStoreId()="
				+ getStoreId() + ", hashCode()=" + hashCode() + ", getClass()=" + getClass() + ", toString()="
				+ super.toString() + "]";
	}

    
}
