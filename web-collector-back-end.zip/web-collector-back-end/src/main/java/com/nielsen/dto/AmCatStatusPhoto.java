package com.nielsen.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "am_cat_status_photo", schema = "so_web_collector")
public class AmCatStatusPhoto implements Serializable{

	private static final long serialVersionUID = 1L;

    @Id
    @Basic(optional = false)
    @Column(name = "status_id")
    private Integer statusId;
    @Basic(optional = false)
    @Column(name = "status_desc")
    private String statusDesc;
    @Basic(optional = false)
    @Column(name = "active")
    private boolean active;
    @Basic(optional = false)
    @Column(name = "insert_date")
    private Date insertDate;
    @Column(name = "update_date")
    private Date updateDate;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "statusId")
    private Set<AmDataPhoto> amDataPhotoCollection;
    
    public AmCatStatusPhoto() {
    	
    }

	public Integer getStatusId() {
		return statusId;
	}

	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public Date getInsertDate() {
		return insertDate;
	}

	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public Set<AmDataPhoto> getAmDataPhotoCollection() {
		return amDataPhotoCollection;
	}

	public void setAmDataPhotoCollection(Set<AmDataPhoto> amDataPhotoCollection) {
		this.amDataPhotoCollection = amDataPhotoCollection;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (active ? 1231 : 1237);
		result = prime * result + ((amDataPhotoCollection == null) ? 0 : amDataPhotoCollection.hashCode());
		result = prime * result + ((insertDate == null) ? 0 : insertDate.hashCode());
		result = prime * result + ((statusDesc == null) ? 0 : statusDesc.hashCode());
		result = prime * result + ((statusId == null) ? 0 : statusId.hashCode());
		result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AmCatStatusPhoto other = (AmCatStatusPhoto) obj;
		if (active != other.active)
			return false;
		if (amDataPhotoCollection == null) {
			if (other.amDataPhotoCollection != null)
				return false;
		} else if (!amDataPhotoCollection.equals(other.amDataPhotoCollection))
			return false;
		if (insertDate == null) {
			if (other.insertDate != null)
				return false;
		} else if (!insertDate.equals(other.insertDate))
			return false;
		if (statusDesc == null) {
			if (other.statusDesc != null)
				return false;
		} else if (!statusDesc.equals(other.statusDesc))
			return false;
		if (statusId == null) {
			if (other.statusId != null)
				return false;
		} else if (!statusId.equals(other.statusId))
			return false;
		if (updateDate == null) {
			if (other.updateDate != null)
				return false;
		} else if (!updateDate.equals(other.updateDate))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AmCatStatusPhoto [statusId=" + statusId + ", statusDesc=" + statusDesc + ", active=" + active
				+ ", insertDate=" + insertDate + ", updateDate=" + updateDate + ", amDataPhotoCollection="
				+ amDataPhotoCollection + ", getStatusId()=" + getStatusId() + ", getStatusDesc()=" + getStatusDesc()
				+ ", isActive()=" + isActive() + ", getInsertDate()=" + getInsertDate() + ", getUpdateDate()="
				+ getUpdateDate() + ", getAmDataPhotoCollection()=" + getAmDataPhotoCollection() + ", hashCode()="
				+ hashCode() + ", getClass()=" + getClass() + ", toString()=" + super.toString() + "]";
	}

    
    
}

