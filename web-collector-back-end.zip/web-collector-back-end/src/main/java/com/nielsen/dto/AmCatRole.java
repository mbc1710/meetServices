package com.nielsen.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

//@Entity
//@Table(name = "am_cat_role", schema = "so_web_collector")
public class AmCatRole  implements Serializable{

	private static final long serialVersionUID = 1L;
	@Id
	@Column(name="user_role_id")
	private Integer userRoleId;
	@Column(name="user_role_desc")
	private String userRoleDesc;
	@Column(name="active")
	private Boolean active;
	@Column(name="insert_date")
	private Date insertDate;
	@Column(name="update_date")
	private Date updateDate;
	
	public AmCatRole(){
		
	}
	
	public Integer getUserRoleId() {
		return userRoleId;
	}
	public void setUserRoleId(Integer userRoleId) {
		this.userRoleId = userRoleId;
	}
	public String getUserRoleDesc() {
		return userRoleDesc;
	}
	public void setUserRoleDesc(String userRoleDesc) {
		this.userRoleDesc = userRoleDesc;
	}
	public Boolean getActive() {
		return active;
	}
	public void setActive(Boolean active) {
		this.active = active;
	}
	public Date getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((active == null) ? 0 : active.hashCode());
		result = prime * result + ((insertDate == null) ? 0 : insertDate.hashCode());
		result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
		result = prime * result + ((userRoleDesc == null) ? 0 : userRoleDesc.hashCode());
		result = prime * result + ((userRoleId == null) ? 0 : userRoleId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AmCatRole other = (AmCatRole) obj;
		if (active == null) {
			if (other.active != null)
				return false;
		} else if (!active.equals(other.active))
			return false;
		if (insertDate == null) {
			if (other.insertDate != null)
				return false;
		} else if (!insertDate.equals(other.insertDate))
			return false;
		if (updateDate == null) {
			if (other.updateDate != null)
				return false;
		} else if (!updateDate.equals(other.updateDate))
			return false;
		if (userRoleDesc == null) {
			if (other.userRoleDesc != null)
				return false;
		} else if (!userRoleDesc.equals(other.userRoleDesc))
			return false;
		if (userRoleId == null) {
			if (other.userRoleId != null)
				return false;
		} else if (!userRoleId.equals(other.userRoleId))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "CatRole [userRoleId=" + userRoleId + ", userRoleDesc=" + userRoleDesc + ", active=" + active
				+ ", insertDate=" + insertDate + ", updateDate=" + updateDate + ", getUserRoleId()=" + getUserRoleId()
				+ ", getUserRoleDesc()=" + getUserRoleDesc() + ", getActive()=" + getActive() + ", getInsertDate()="
				+ getInsertDate() + ", getUpdateDate()=" + getUpdateDate() + ", hashCode()=" + hashCode()
				+ ", getClass()=" + getClass() + ", toString()=" + super.toString() + "]";
	}
	
}
