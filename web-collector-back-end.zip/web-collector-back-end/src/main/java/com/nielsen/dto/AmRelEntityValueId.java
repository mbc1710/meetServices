package com.nielsen.dto;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class AmRelEntityValueId implements Serializable{

	private static final long serialVersionUID = 1L;

	@Basic(optional = false)
    @Column(name = "entity_id")
    private int entityId;
    @Basic(optional = false)
    @Column(name = "value_id")
    private int valueId;

    public AmRelEntityValueId() {
    	
    }

	public int getEntityId() {
		return entityId;
	}

	public void setEntityId(int entityId) {
		this.entityId = entityId;
	}

	public int getValueId() {
		return valueId;
	}

	public void setValueId(int valueId) {
		this.valueId = valueId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + entityId;
		result = prime * result + valueId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AmRelEntityValueId other = (AmRelEntityValueId) obj;
		if (entityId != other.entityId)
			return false;
		if (valueId != other.valueId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AmRelEntityValueId [entityId=" + entityId + ", valueId=" + valueId + ", getEntityId()=" + getEntityId()
				+ ", getValueId()=" + getValueId() + ", hashCode()=" + hashCode() + ", getClass()=" + getClass()
				+ ", toString()=" + super.toString() + "]";
	}
    
    
}
