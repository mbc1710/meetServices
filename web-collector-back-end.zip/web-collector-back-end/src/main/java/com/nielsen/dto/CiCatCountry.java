package com.nielsen.dto;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "ci_cat_country", schema = "public")
public class CiCatCountry implements Serializable{

	private static final long serialVersionUID = 1L;
	@Id
    @Column(name = "country_id")
    private Integer countryId;
    @Column(name = "country_desc")
    private String countryDesc;
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "countryId")
    @JsonIgnore
    private Set<CiCatClientInstruction> ciCatClientInstructionCollection;
    
    public CiCatCountry() {
    	
    }

	public CiCatCountry(Integer countryId) {
		this.countryId = countryId;
	}


	public Integer getCountryId() {
		return countryId;
	}

	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}

	public String getCountryDesc() {
		return countryDesc;
	}

	public void setCountryDesc(String countryDesc) {
		this.countryDesc = countryDesc;
	}

	public Set<CiCatClientInstruction> getCiCatClientInstructionCollection() {
		return ciCatClientInstructionCollection;
	}

	public void setCiCatClientInstructionCollection(Set<CiCatClientInstruction> ciCatClientInstructionCollection) {
		this.ciCatClientInstructionCollection = ciCatClientInstructionCollection;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((ciCatClientInstructionCollection == null) ? 0 : ciCatClientInstructionCollection.hashCode());
		result = prime * result + ((countryDesc == null) ? 0 : countryDesc.hashCode());
		result = prime * result + ((countryId == null) ? 0 : countryId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CiCatCountry other = (CiCatCountry) obj;
		if (ciCatClientInstructionCollection == null) {
			if (other.ciCatClientInstructionCollection != null)
				return false;
		} else if (!ciCatClientInstructionCollection.equals(other.ciCatClientInstructionCollection))
			return false;
		if (countryDesc == null) {
			if (other.countryDesc != null)
				return false;
		} else if (!countryDesc.equals(other.countryDesc))
			return false;
		if (countryId == null) {
			if (other.countryId != null)
				return false;
		} else if (!countryId.equals(other.countryId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "CiCatCountry [countryId=" + countryId + ", countryDesc=" + countryDesc
				+ ", ciCatClientInstructionCollection=" + ciCatClientInstructionCollection + ", getCountryId()="
				+ getCountryId() + ", getCountryDesc()=" + getCountryDesc() + ", getCiCatClientInstructionCollection()="
				+ getCiCatClientInstructionCollection() + ", hashCode()=" + hashCode() + ", getClass()=" + getClass()
				+ ", toString()=" + super.toString() + "]";
	}
    
}
