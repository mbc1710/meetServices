package com.nielsen.controller.api.testdata;

import org.springframework.http.MediaType;

import java.nio.charset.Charset;

public class ApiControllerTestData {

    private MediaType contentType;

    public ApiControllerTestData() {
        setUp();
    }

    private void setUp() {
        setUpContentType();
    }

    private void setUpContentType() {
        contentType = new MediaType(MediaType.APPLICATION_JSON.getType(),
                MediaType.APPLICATION_JSON.getSubtype(),
                Charset.forName("utf8"));
    }

    public MediaType getContentType() {
        return contentType;
    }

    public void setContentType(MediaType contentType) {
        this.contentType = contentType;
    }
}
