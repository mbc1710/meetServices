export const environment = {
  production: true,

  WS_BASE_URL : "http://localhost:8081/"

};
