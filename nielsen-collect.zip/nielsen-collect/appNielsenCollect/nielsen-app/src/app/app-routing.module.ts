import {NgModule} from '@angular/core';
import {Routes, RouterModule} from "@angular/router";
import {ProductComponent} from "./structure/products/product.component";

import {HeaderComponent} from "./shared/layout/header.component";
import {FooterComponent} from "./shared/layout/footer.component";

const appRoutes: Routes = [
    {path: '', redirectTo: '/structure/products', pathMatch: 'full'},
    {path: '**', redirectTo: '/', pathMatch: 'full'},
    {path: '', component: HeaderComponent, outlet: 'header'},
    {path: '', component: FooterComponent, outlet: 'footer'}
];

@NgModule({
    imports: [
        RouterModule.forRoot(appRoutes, { useHash: false })
    ],
    exports: [
        RouterModule
    ],
    providers: []
})

export class AppRoutingModule {
}
