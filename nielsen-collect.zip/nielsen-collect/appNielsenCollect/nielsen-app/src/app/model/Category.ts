export class CategoryModel {
    id: string;
    name: string;
}