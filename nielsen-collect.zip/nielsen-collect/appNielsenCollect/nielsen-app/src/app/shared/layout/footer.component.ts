import { Component, OnInit } from '@angular/core';

@Component({
    templateUrl: 'footer.component.html',
    styleUrls   : ['footer.component.css'],
    host        : {
      '(window:scroll)' : 'changeWindowEvent($event)',
      '(window:resize)' : 'changeWindowEvent($event)'}
})

export class FooterComponent implements OnInit {

  today: number;

  ngOnInit() {
    this.today = Date.now();
  }

}
