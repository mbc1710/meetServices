import {Component, OnInit, NgZone} from "@angular/core";
import {Router} from "@angular/router";

@Component({
    templateUrl: './structure.component.html',
})

export class StructureComponent implements OnInit {

    ngOnInit(): void {
    }

}

