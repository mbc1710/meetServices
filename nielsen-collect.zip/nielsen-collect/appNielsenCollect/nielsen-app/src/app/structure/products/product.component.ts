import {Component, OnInit, ViewChild} from '@angular/core';
import {Router, ActivatedRoute, Params}   from '@angular/router';

import {ServiceApi} from "../../rest-access/service-api";

import {CategoryModel} from "../../model/Category";

@Component({
    templateUrl: 'product.component.html',
    styleUrls: ['product.component.css'],
    providers: [ServiceApi]
})

export class ProductComponent implements OnInit {

    products : CategoryModel[];
    errorMessage: string;

    constructor(private router: Router,
                private activatedRoute: ActivatedRoute,
                private servicesApi: ServiceApi) {
    }

    ngOnInit(): void {
        this.getProductList();
    }

    getProductList(): void {
        this.servicesApi.executeGetUnique('products/getAllProducts')
            .subscribe(
                category => {
                    this.products = category as CategoryModel[];
                },
                error => {
                    this.errorMessage = error;
                });
    }
}

