import {Routes, RouterModule} from "@angular/router";
import {NgModule} from "@angular/core";

import {ProductComponent} from "./products/product.component";

import {HeaderComponent} from "../shared/layout/header.component";
import {FooterComponent} from "../shared/layout/footer.component";

const routes: Routes = [
    {path: 'structure', children:[
        {path: 'products', component: ProductComponent, pathMatch: 'full'},
        {path: '', component: HeaderComponent, outlet: 'header'},
        {path: '', component: FooterComponent, outlet: 'footer'}
    ]}
];

@NgModule({
    imports: [
        RouterModule.forChild(routes)
    ],
    exports: [
        RouterModule
    ]
})

export class StructureRoutingModule {
}
