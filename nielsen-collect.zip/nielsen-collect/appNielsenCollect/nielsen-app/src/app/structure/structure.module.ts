import { BrowserModule }  from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { StructureRoutingModule } from './structure-routing.module';
import { SharedComponentsModule } from '../shared/shared-components.module';

import { StructureComponent } from './structure.component';
import { ProductComponent } from './products/product.component';


@NgModule({
    imports: [
        BrowserModule,
        CommonModule,
        FormsModule,
        StructureRoutingModule,
        SharedComponentsModule
    ],
    declarations: [
        StructureComponent,
        ProductComponent
    ]
})

export class StructureModule {
}
