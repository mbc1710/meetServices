import { Injectable }    from '@angular/core';
import { Http, Response, Headers, RequestOptions, RequestMethod } from '@angular/http';
import { Observable }    from 'rxjs/Observable';

import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

import { environment }           from '../../environments/environment';

@Injectable()
export class ServiceApi{

  private baseUrl = environment.WS_BASE_URL;

  constructor(
    private http : Http) { 
    }

  executeGetList(operation : string) : Observable<Object[]>{
    //console.log("Entry to executeGetList Method with operation:" + operation);

    return this.http.get(this.baseUrl + operation)
      .map(this.extractData)
      .catch(this.handleError)
  }

  executeGetUnique(operation : string) : Observable<Object>{
    //console.log("Entry to executeGetUnique Method with operation:" + operation);

    return this.http.get(this.baseUrl + operation)
      .map(this.extractData)
      .catch(this.handleError)
  }

  executeCreate(operation : string, objectToSave : Object) : Observable<Object>{
    //console.log("Entry to executeCreate with object: " + JSON.stringify(objectToSave));

    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions( {method: RequestMethod.Post, headers: headers });
    if(objectToSave == null) {
      return this.http.post(this.baseUrl + operation,  null, options)
        .map(this.extractData)
        .catch(this.handleError)
    }else {
      let body = JSON.stringify(objectToSave);
      return this.http.post(this.baseUrl + operation,  body, options)
        .map(this.extractData)
        .catch(this.handleError)
    }

  }

  executeUpdate(operation : string, objectToUpdate : Object) : Observable<Object>{
    //console.log("Entry to executeUpdate Method with operation: "+ operation + " and objectToUpdate: " + JSON.stringify(objectToUpdate));

    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions( {method: RequestMethod.Put, headers: headers });

    if(objectToUpdate == null) {
      return this.http.put(this.baseUrl + operation,  null, options)
        .map(this.extractData)
        .catch(this.handleError)
    }else {
      let body = JSON.stringify(objectToUpdate);
      return this.http.put(this.baseUrl + operation,  body, options)
        .map(this.extractData)
        .catch(this.handleError)
    }
  }

  executeDelete(operation : string) : Observable<Object>{
    //console.log("Entry to executeDelete Method with operation:" + operation);
    return this.http.delete(this.baseUrl + operation)
      .map(this.extractData)
      .catch(this.handleError)

  }

  private extractData(res: Response) {
    let body;
    if(res.text()) {
      body = res.json();
    }

    //console.log(JSON.stringify(body));
    return body || { };
  }

  private handleError (error: Response | any) {
    console.error(error.message || error);
    return Observable.throw(error.message || error);
  }

}
