import { NielsenAppPage } from './app.po';

describe('nielsen-app App', () => {
  let page: NielsenAppPage;

  beforeEach(() => {
    page = new NielsenAppPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!!');
  });
});
