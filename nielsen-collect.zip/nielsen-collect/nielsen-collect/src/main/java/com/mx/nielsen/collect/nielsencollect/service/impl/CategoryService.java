package com.mx.nielsen.collect.nielsencollect.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mx.nielsen.collect.nielsencollect.dao.ICategoryDAO;
import com.mx.nielsen.collect.nielsencollect.entity.Category;
import com.mx.nielsen.collect.nielsencollect.exception.NilsenColletException;

@Service
public class CategoryService implements ICategoryService{

	@Autowired
	ICategoryDAO categoryDao;
	
	@Override
	public List<Category> getAllCategories() throws NilsenColletException{
		List<Category> categories;
		try{
			categories = categoryDao.getAllCategories();
		}catch (Exception e) {
			throw new NilsenColletException(NilsenColletException.ERROR_BD, "Error al consultar en BD " + e.getCause());
		}
		return categories;
	}

	@Override
	public Category getCategoryById(int categoryId) {
		Category category = categoryDao.getCategoryById(categoryId);
		return category;
	}

	@Override
	public void saveCategory(Category cat) {
		categoryDao.createCategory(cat);
	}

	@Override
	public void updateCategory(Category cat) {
		categoryDao.updateCategory(cat);
	}

	@Override
	public void deleteCategory(int categoryId) {
		categoryDao.deleteCategory(categoryId);
	}

}
