package com.mx.nielsen.collect.nielsencollect.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.opencsv.CSVReader;

@RestController
@RequestMapping("/file")
public class FileUpLoadController {
	
	@RequestMapping(value = "uploadFile", method = RequestMethod.POST, produces = "text/plain", consumes= "multipart/form-data")	
	public String uploadFile(@RequestParam("file") MultipartFile file) throws IOException {
//		@RequestParam("file") String file		
		 if (!file.isEmpty()) {
			String nameFile = file.getOriginalFilename();
         	String rootFolder = System.getProperty("user.home");
         	String rutaCarpeta  = "C:\\temp\\crearCarpeta\\";
         	File folder = new File(rutaCarpeta);
         	if (!folder.exists()) {
         		folder.mkdirs();
         		System.out.println("Se crea el directorio para guaradr el archivo. " + folder.getPath());
         	}
            try {            	
                byte[] bytes = file.getBytes();
                BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(new File(folder.getPath()+File.separator+nameFile)));
                stream.write(bytes);
                stream.close();
            } catch (Exception e) {
                return "falla en la carga del archivo " + e.getMessage();
            }
            CSVReader reader = null;
            try {
               reader = new CSVReader(new FileReader(folder.getPath()+nameFile));
               String[] nextLine=null;               
               while ((nextLine = reader.readNext()) != null) {
                  System.out.println(Arrays.toString(nextLine));
               }
               
            } catch (Exception e) {
               System.out.println("Error: "+e.getCause());
            } finally {
               if (null != reader) {
                  reader.close();
               } 
            }
            return "Se guardo el archivo";
//                byte[] fileByte=Base64.decodeBase64(file);
//                new FileOutputStream("c:\\temp\\").write(fileByte);
//                return "success ";            
        } else {
            return "El archivo esta vacio.";
        }
    }	

}
