package com.mx.nielsen.collect.nielsencollect.dao;

import java.io.Serializable;
import java.util.List;

public interface CRUDBaseDao<E> {
	
	List<E> getAll();
	
	E getById(Serializable id);

	E save(E entity);
	
	E update(E entity);

	void delete(Serializable id);

}
