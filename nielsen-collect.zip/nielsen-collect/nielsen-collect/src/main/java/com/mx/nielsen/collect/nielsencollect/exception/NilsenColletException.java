package com.mx.nielsen.collect.nielsencollect.exception;

public class NilsenColletException extends Exception{
	
	private static final long serialVersionUID = -5851662309677083597L;
	
	private int codigoError;
	private String menssage;		
	
	public static final int ERROR_BD = 1;

	public NilsenColletException(int codigoError, String menssage) {
		super();
		this.codigoError = codigoError;
		this.menssage = menssage;
	}

	public NilsenColletException(String message) {
		super(message);
	}

	public int getCodigoError() {
		return codigoError;
	}

	public void setCodigoError(int codigoError) {
		this.codigoError = codigoError;
	}

	public String getMenssage() {
		return menssage;
	}

	public void setMenssage(String menssage) {
		this.menssage = menssage;
	}

}
