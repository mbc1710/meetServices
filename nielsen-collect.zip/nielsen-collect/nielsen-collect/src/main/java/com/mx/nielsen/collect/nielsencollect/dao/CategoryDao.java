package com.mx.nielsen.collect.nielsencollect.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mx.nielsen.collect.nielsencollect.entity.Category;

@Transactional
@Repository
public class CategoryDao implements ICategoryDAO{
	@PersistenceContext	
	private EntityManager entityManager;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Category> getAllCategories() {
		String listC = "SELECT cat FROM Category as cat ORDER BY cat.id ASC";
		return (List<Category>) entityManager.createQuery(listC).getResultList();
	}

	@Override
	public Category getCategoryById(int id) {
		return entityManager.find(Category.class, id);
	}

	@Override
	public void createCategory(Category category) {
		entityManager.persist(category);
	}

	@Override
	public void updateCategory(Category category) {
		Category cat = getCategoryById(category.getId());
		cat.setName(category.getName());
		entityManager.flush();
	}

	@Override
	public void deleteCategory(int articleId) {
		entityManager.remove(getCategoryById(articleId));
	}
}
