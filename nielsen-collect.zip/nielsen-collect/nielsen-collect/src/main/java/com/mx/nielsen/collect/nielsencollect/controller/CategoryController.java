package com.mx.nielsen.collect.nielsencollect.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mx.nielsen.collect.nielsencollect.entity.Category;
import com.mx.nielsen.collect.nielsencollect.exception.NilsenColletException;
import com.mx.nielsen.collect.nielsencollect.service.impl.ICategoryService;

@RestController
@RequestMapping("/products")
public class CategoryController {

	@Autowired
	ICategoryService categoryService;
	
	final static Logger logger = Logger.getLogger(CategoryController.class);
	
	@RequestMapping(value = "allProducts", method = RequestMethod.GET)
	public ResponseEntity<List<Category>> getAllCategories() throws NilsenColletException{
		List<Category> list = categoryService.getAllCategories();
		return new ResponseEntity<List<Category>>(list, HttpStatus.OK);
	}
	
	@RequestMapping(value = "{id}", method = RequestMethod.GET)
	public ResponseEntity<Category> getOneCategory(@PathVariable("id") int id) {
		Category category = categoryService.getCategoryById(id);
		return new ResponseEntity<Category>(category, HttpStatus.OK);
	}
	
	@RequestMapping(value = "create", method = RequestMethod.POST)
	public ResponseEntity<Category> addEmployee(@RequestBody Category category) {
		categoryService.saveCategory(category);
		return new ResponseEntity<Category>(category, HttpStatus.CREATED);
	}
	
	@RequestMapping(value = "update", method = RequestMethod.PUT)
	public ResponseEntity<Category> updateEmployee(@RequestBody Category category) {
		categoryService.updateCategory(category);
		return new ResponseEntity<Category>(category, HttpStatus.OK);
	}
	
	@RequestMapping(value = "delete/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<Category> deleteEmployee(@PathVariable int id) {
		categoryService.deleteCategory(id);
		return new ResponseEntity<Category>(HttpStatus.NO_CONTENT);
	}
}
