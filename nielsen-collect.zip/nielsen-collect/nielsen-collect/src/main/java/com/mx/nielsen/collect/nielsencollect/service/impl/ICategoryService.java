package com.mx.nielsen.collect.nielsencollect.service.impl;

import java.util.List;

import com.mx.nielsen.collect.nielsencollect.entity.Category;
import com.mx.nielsen.collect.nielsencollect.exception.NilsenColletException;

public interface ICategoryService {
	
	List<Category> getAllCategories() throws NilsenColletException;
	Category getCategoryById(int categoryId);
	void saveCategory(Category category);
	void updateCategory(Category category);
	void deleteCategory(int category);

}
