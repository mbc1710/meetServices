package com.mx.nielsen.collect.nielsencollect.dao;

import java.util.List;

import com.mx.nielsen.collect.nielsencollect.entity.Category;

public interface ICategoryDAO{
	
    List<Category> getAllCategories();
    Category getCategoryById(int id);
    void createCategory(Category category);
    void updateCategory(Category category);
    void deleteCategory(int articleId);
	
}
